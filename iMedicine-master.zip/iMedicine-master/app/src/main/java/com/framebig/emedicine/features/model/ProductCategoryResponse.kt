package com.framebig.emedicine.features.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ProductCategoryResponse(
	@field:SerializedName("data")
	val data: List<ProductCategory>? = null
) : Parcelable