package com.framebig.emedicine.model;

/**
 * Created by shamimhossain on 8/25/17.
 */

public enum UserType
{
    Undefined, Patient, Doctor;

    public static UserType getUserTypeFromInteger(Integer type)
    {
        if (type == Patient.ordinal())
        {
            return Patient;
        }
        else if (type == Doctor.ordinal())
        {
            return Doctor;
        }
        else
        {
            return Undefined;
        }
    }

}
