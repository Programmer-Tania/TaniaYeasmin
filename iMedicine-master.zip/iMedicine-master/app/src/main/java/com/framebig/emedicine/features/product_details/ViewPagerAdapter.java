package com.framebig.emedicine.features.product_details;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.framebig.emedicine.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class ViewPagerAdapter extends PagerAdapter
{
    private Context context;
    private List<String> imageURLs;

    ViewPagerAdapter(
            Context context,
            List<String> imageURLs)
    {
        this.context = context;
        this.imageURLs = imageURLs;
    }

    @Override
    public int getCount()
    {
        return imageURLs.size();
    }

    @Override
    public boolean isViewFromObject(
            @NonNull View view,
            @NonNull Object object)
    {
        return view == object;
    }

    @NonNull
    @Override
    public Object instantiateItem(
            @NonNull ViewGroup container,
            int position)
    {

        ImageView imageView = new ImageView(context);
        Picasso.get().load(imageURLs.get(position)).error(R.drawable.image_not_found).placeholder(R.drawable.image_not_found).resize(350, 350).into(imageView);
        container.addView(imageView);
        imageView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(context, FullScreenImageActivity.class);
                intent.putExtra("position", position);
                context.startActivity(intent);
            }
        });
        return imageView;
    }

    @Override
    public void destroyItem(
            @NonNull ViewGroup container,
            int position,
            @NonNull Object object)
    {
        container.removeView((View) object);
    }

}
