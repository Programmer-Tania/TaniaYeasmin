package com.framebig.emedicine.utility;

import android.app.DialogFragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import com.framebig.emedicine.R;

/**
 * Created by shohrab on 6/12/2016.
 */
public class AlertDialogTwoButton extends DialogFragment
{

    int mIcon, mCheckboxVisibility, mTrackingNumber;
    String mTitle, mMessage, mNegativeButtonText, mPositiveButtonText;
    private static Object mReferenceClass;

    //This interface is implemented in the classes where Alertdialog is shown up
    public interface ButtonClickListener
    {
        void onNegativeButtonClick(int trackingNumber);

        void onPositiveButtonClick(int trackingNumber);
    }

    public static AlertDialogTwoButton newInstance(
            Object activity,
            String title,
            String message,
            String negativeButtonText,
            String positiveButtonText,
            int checkboxVisibility,
            int icon,
            int trackingNumber)
    {

        AlertDialogTwoButton f = new AlertDialogTwoButton();

        // Supply num input as an argument.
        Bundle args = new Bundle();
        args.putInt("icon", icon);
        args.putInt("trackingNumber", trackingNumber);
        args.putString("title", title);
        args.putString("message", message);
        args.putInt("checkboxVisibility", checkboxVisibility);
        args.putString("negativeButtonText", negativeButtonText);
        args.putString("positiveButtonText", positiveButtonText);
        mReferenceClass = activity;
        f.setArguments(args);

        return f;
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        mIcon = getArguments().getInt("icon");
        mTitle = getArguments().getString("title");
        mMessage = getArguments().getString("message");
        mNegativeButtonText = getArguments().getString("negativeButtonText");
        mPositiveButtonText = getArguments().getString("positiveButtonText");
        mCheckboxVisibility = getArguments().getInt("checkboxVisibility");
        mTrackingNumber = getArguments().getInt("trackingNumber");
    }

    @Override
    public View onCreateView(
            LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState)
    {

        View alertDlgView = inflater.inflate(R.layout.alertdlg_button_two, container, false);
        getDialog().setCancelable(false);
        getDialog().setCanceledOnTouchOutside(false);

        getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        // Retrieve views from the inflated dialog layout and update their values
        TextViewEx txtViewEx = alertDlgView.findViewById(R.id.alertdlg_TextView);
        txtViewEx.setText(mMessage + "\n", true);

        TextView txtTitle = alertDlgView.findViewById(R.id.alertdlg_txtTitle);
        txtTitle.setText(mTitle);

        ImageView imgIcon = alertDlgView.findViewById(R.id.alertdlg_imgIcon);
        imgIcon.setImageResource(mIcon);

        CheckBox checkBox = alertDlgView.findViewById(R.id.alertdlg_checkbox);
        checkBox.setVisibility(mCheckboxVisibility);

        Button negativeButton = alertDlgView.findViewById(R.id.alertdlg_BtnNegative);
        negativeButton.setText(mNegativeButtonText);
        Button positiveButton = alertDlgView.findViewById(R.id.alertdlg_BtnPositive);
        positiveButton.setText(mPositiveButtonText);

        negativeButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // When button is clicked, call up to owning activity.
                getDialog().dismiss();
                ((ButtonClickListener) mReferenceClass).onNegativeButtonClick(mTrackingNumber);
            }
        });

        positiveButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // When button is clicked, call up to owning activity.
                getDialog().dismiss();
                ((ButtonClickListener) mReferenceClass).onPositiveButtonClick(mTrackingNumber);
            }
        });

        return alertDlgView;
    }
}
