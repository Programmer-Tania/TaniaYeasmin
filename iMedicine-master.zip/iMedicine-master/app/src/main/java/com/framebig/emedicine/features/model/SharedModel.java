package com.framebig.emedicine.features.model;

/**
 * Created by shohrab on 18.03.2018.
 */

public class SharedModel
{

    public String selectedCategoryName;
    public String selectedCategoryId;
    public String selectedProductName;
    public String selectedProductId;

    public SharedModel()
    {
    }

    public String getSelectedCategoryName()
    {
        return selectedCategoryName;
    }

    public void setSelectedCategoryName(String selectedCategoryName)
    {
        this.selectedCategoryName = selectedCategoryName;
    }

    public String getSelectedCategoryId()
    {
        return selectedCategoryId;
    }

    public void setSelectedCategoryId(String selectedCategoryId)
    {
        this.selectedCategoryId = selectedCategoryId;
    }

    public String getSelectedProductName()
    {
        return selectedProductName;
    }

    public void setSelectedProductName(String selectedProductName)
    {
        this.selectedProductName = selectedProductName;
    }

    public String getSelectedProductId()
    {
        return selectedProductId;
    }

    public void setSelectedProductId(String selectedProductId)
    {
        this.selectedProductId = selectedProductId;
    }
}
