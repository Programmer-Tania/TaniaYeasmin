package com.framebig.emedicine.features.model;

public class Phone
{
    private String national_number;

    private String country_prefix;

    private String number;

    public String getNational_number()
    {
        return national_number;
    }

    public void setNational_number(String national_number)
    {
        this.national_number = national_number;
    }

    public String getCountry_prefix()
    {
        return country_prefix;
    }

    public void setCountry_prefix(String country_prefix)
    {
        this.country_prefix = country_prefix;
    }

    public String getNumber()
    {
        return number;
    }

    public void setNumber(String number)
    {
        this.number = number;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [national_number = " + national_number + ", country_prefix = " + country_prefix + ", number = " + number + "]";
    }
}
