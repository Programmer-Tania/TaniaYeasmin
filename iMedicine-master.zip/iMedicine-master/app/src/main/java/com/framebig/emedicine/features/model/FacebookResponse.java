package com.framebig.emedicine.features.model;

public class FacebookResponse
{

    private String id;

    //@SerializedName("application")
    private FacebookApplication application;

    private Phone phone;

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public FacebookApplication getApplication()
    {
        return application;
    }

    public void setApplication(FacebookApplication application)
    {
        this.application = application;
    }

    public Phone getPhone()
    {
        return phone;
    }

    public void setPhone(Phone phone)
    {
        this.phone = phone;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [id = " + id + ", application = " + application + ", phone = " + phone + "]";
    }
}
