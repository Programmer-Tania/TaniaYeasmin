package com.framebig.emedicine.features.order_history

import android.os.Bundle
import android.view.MenuItem
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.framebig.emedicine.R
import com.framebig.emedicine.databinding.ActivityOrderDetailsHistoryBinding
import com.framebig.emedicine.features.BaseActivity
import com.framebig.emedicine.features.model.OrderHistoryResponse
import com.framebig.emedicine.features.model.OrderListModel
import com.framebig.emedicine.utility.MyDividerItemDecoration
import com.framebig.emedicine.utility.ViewModelFactory

class OrderDetailsHistoryActivity : BaseActivity() {
    private lateinit var binding: ActivityOrderDetailsHistoryBinding
    private var orderNo: String? = ""
    private var totalPrice: String? = ""
    private val tag = "OrderHistoryDetail"
    lateinit var viewModel: OrderHistoryDetailsViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_order_details_history)
        setSupportActionBar(binding.toolbar)
        supportActionBar!!.title = "Order Details"
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        orderNo = intent.getStringExtra("orderNo")
        totalPrice = intent.getStringExtra("totalPrice")

        viewModel = ViewModelProviders.of(
                this, ViewModelFactory(OrderHistoryDetailsViewModel(orderNo!!))).get(OrderHistoryDetailsViewModel::class.java)

        binding.content.model = viewModel
        binding.content.recyclerviewOrderDetailsHistory.addItemDecoration(MyDividerItemDecoration(this, MyDividerItemDecoration.VERTICAL_LIST, 6))

        viewModel.orderListModelList.observe(this, Observer {
            binding.content.recyclerviewOrderDetailsHistory.adapter = ProductListHistoryAdapter(it)
            binding.executePendingBindings()
        })

        viewModel.loading.observe(this, Observer {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        })

        viewModel.messaging.observe(this, Observer {
            showToastMessage(it)
        })

        viewModel.order.observe(this, Observer {
            binding.content.tvOrderNo.text = "Order No: " + it.orderNo
            binding.content.tvDate.text = "Order Date: " + it.orderDate
            binding.content.tvStatus.text = it.orderStatus
            binding.content.textViewTotalBill.text = totalPrice
            binding.content.txtDeliveryFeeAmount.text = it.shippingCharge

            getSubTotal(it.productData)
            statusColor(it!!)
        })
    }

    private fun getSubTotal(productData: ArrayList<OrderListModel>?) {
        if (productData != null) {
            var totalBill = 0.00
            for (aProduct in productData) {
                totalBill += aProduct.amount * aProduct.unitSellingCost
            }
            binding.content.txtSubTotalAmount.text = totalBill.toString()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun statusColor(it: OrderHistoryResponse) {
        when {
            it.orderStatus.equals("processing", ignoreCase = true) -> {
                binding.content.tvStatus.setTextColor(ContextCompat.getColor(this, R.color.blue))
            }
            it.orderStatus.equals("shipped", ignoreCase = true) -> {
                binding.content.tvStatus.setTextColor(ContextCompat.getColor(this, R.color.orange))
            }
            it.orderStatus.equals("delivered", ignoreCase = true) -> {
                binding.content.tvStatus.setTextColor(ContextCompat.getColor(this, R.color.green))
            }
            it.orderStatus.equals("cancelled", ignoreCase = true) -> {
                binding.content.tvStatus.setTextColor(ContextCompat.getColor(this, R.color.red))
            }
        }
    }
}
