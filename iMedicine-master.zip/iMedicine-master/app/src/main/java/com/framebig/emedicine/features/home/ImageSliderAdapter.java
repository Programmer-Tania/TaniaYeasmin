package com.framebig.emedicine.features.home;

import android.content.Context;

import androidx.viewpager.widget.PagerAdapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.framebig.emedicine.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ImageSliderAdapter extends PagerAdapter
{

    private ArrayList<String> imageList;
    private LayoutInflater inflater;
    private Context context;

    public ImageSliderAdapter(
            Context context,
            ArrayList<String> imageList)
    {
        this.context = context;
        this.imageList = imageList;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public void destroyItem(
            ViewGroup container,
            int position,
            Object object)
    {
        container.removeView((View) object);
    }

    @Override
    public int getCount()
    {
        return imageList.size();
    }

    @Override
    public Object instantiateItem(
            ViewGroup view,
            int position)
    {
        View myImageLayout = inflater.inflate(R.layout.slide, view, false);
        ImageView myImage = myImageLayout.findViewById(R.id.image);
        myImage.setImageResource(R.drawable.image_not_found);

        Picasso.get().load(imageList.get(position)).error(R.drawable.image_not_found).placeholder(R.drawable.image_not_found).resize(350, 350).into(myImage);

        view.addView(myImageLayout, 0);

        return myImageLayout;
    }

    @Override
    public boolean isViewFromObject(
            View view,
            Object object)
    {
        return view.equals(object);
    }
}