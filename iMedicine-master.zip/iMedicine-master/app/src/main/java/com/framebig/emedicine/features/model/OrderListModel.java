package com.framebig.emedicine.features.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by shohrab on 13.03.2018.
 */

public class OrderListModel
{

    private String orderNo;
    private int productId;
    private double amount;
    private String orderStatus;
    private String size;
    private String color;
    private String paymentDate;
    private String deliveryDate;
    private String orderDate;
    private String billNo;
    private String productName;
    private String imageUrl;
    private String unitName;
    private int response_code;
    private String totalItem;
    private String totalOrderValue;

    public void setOrderNo(String orderNo)
    {
        this.orderNo = orderNo;
    }

    private double unitSellingCost;

    public ArrayList<OrderListModel> getOrderListModelArrayList()
    {
        return orderListModelArrayList;
    }

    public void setOrderListModelArrayList(ArrayList<OrderListModel> orderListModelArrayList)
    {
        this.orderListModelArrayList = orderListModelArrayList;
    }

    @SerializedName("response")
    @Expose
    private ArrayList<OrderListModel> orderListModelArrayList = new ArrayList<>();

    public void setUnitSellingCost(double unitSellingCost)
    {
        this.unitSellingCost = unitSellingCost;
    }

    public String getTotalOrderValue()
    {
        return totalOrderValue;
    }

    public void setTotalOrderValue(String totalOrderValue)
    {
        this.totalOrderValue = totalOrderValue;
    }

    public String getTotalItem()
    {
        return totalItem;
    }

    public void setTotalItem(String totalItem)
    {
        this.totalItem = totalItem;
    }

    public String getProductName()
    {
        return productName;
    }

    public String getUnitName()
    {
        return unitName;
    }

    public String getOrderNo()
    {
        return orderNo;
    }

    public String getColor()
    {
        return color;
    }

    public void setColor(String color)
    {
        this.color = color;
    }

    public String getSize()
    {
        return size;
    }

    public void setSize(String size)
    {
        this.size = size;
    }

    public String getOrderStatus()
    {
        return orderStatus;
    }

    public String getPaymentDate()
    {
        return paymentDate;
    }

    public String getDeliveryDate()
    {
        return deliveryDate;
    }

    public void setDeliveryDate(String deliveryDate)
    {
        this.deliveryDate = deliveryDate;
    }

    public String getOrderDate()
    {
        return orderDate;
    }

    public String getBillNo()
    {
        return billNo;
    }

    public String getImageUrl()
    {
        return imageUrl;
    }

    public int getProductId()
    {
        return productId;
    }

    public double getUnitSellingCost()
    {
        return unitSellingCost;
    }

    public double getAmount()
    {
        return amount;
    }

    public ArrayList<OrderListModel> getOrderList()
    {
        return orderListModelArrayList;
    }

    public int getResponse_code()
    {
        return response_code;
    }
}
