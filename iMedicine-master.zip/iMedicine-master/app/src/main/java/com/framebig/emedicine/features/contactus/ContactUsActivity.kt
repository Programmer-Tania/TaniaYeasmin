package com.framebig.emedicine.features.contactus

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import com.framebig.emedicine.R
import com.framebig.emedicine.databinding.ActivityContactUsBinding
import com.framebig.emedicine.features.BaseActivity
import com.framebig.emedicine.utility.*
import com.squareup.picasso.Picasso

class ContactUsActivity : BaseActivity(), View.OnClickListener {
    var counter = 1
    private val REQUEST_CALL = 1
    private lateinit var binding: ActivityContactUsBinding
    private var latitude: Double = 0.0
    private var longitude: Double = 0.0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_contact_us)
        setSupportActionBar(binding.toolbar)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)

        ApplicationData.SETTINGS_RESPONSE.latitude?.let {
            latitude = it.toDouble()
        }

        ApplicationData.SETTINGS_RESPONSE.longitude?.let {
            longitude = it.toDouble()
        }

        binding.content.email.text = ApplicationData.SETTINGS_RESPONSE.companyEmail
        binding.content.phoneNumber.text = ApplicationData.SETTINGS_RESPONSE.companyPhone
        binding.content.clientName.text = ApplicationData.SETTINGS_RESPONSE.businessOwnerName
        binding.content.location.text = ApplicationData.SETTINGS_RESPONSE.companyAddress
        Picasso.get().load(ApplicationData.getAppIcon()).resize(250, 250).into(binding.content.imageViewAppLogo)
        binding.content.layoutCall.setOnClickListener(this)
        binding.content.layoutEmail.setOnClickListener(this)
        binding.content.layoutLocation.setOnClickListener(this)
        binding.content.contactUsDeveloper.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        when {
            v === binding.content.layoutCall -> {
                makePhoneCall()
            }
            v === binding.content.layoutEmail -> {
                sendMail()
            }
            v === binding.content.layoutLocation -> {
                openBuiltInGoogleMap()
            }
            v === binding.content.contactUsDeveloper -> {
                checkTestingApp()
            }
        }
    }

    private fun checkTestingApp() {
        when {
            counter >= ApplicationData.TESTER_SPACE_COUNT -> {
                LogMe.i("COUNTER", "startTesting")
                /** Developer mode is on  */
                /** Developer mode is on  */
                FrameBigApp.getDefaultSharePreference().putBoolean(PrefsValues.IS_DEVELOPER_MODE_ENABLE, true)
                openCustomDialog()
            }
            counter == ApplicationData.TESTER_SPACE_COUNT - 1 -> {
                showToastMessage("You are 1 Click away from being a tester")
                counter++
            }
            else -> {
                counter++
                LogMe.i("COUNTER", "ONGOING")
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                return true
            }
        }
        return false
    }

    private fun openCustomDialog() {
        val ft = supportFragmentManager.beginTransaction()
        val prev = supportFragmentManager.findFragmentByTag("dialog")
        if (prev != null) {
            ft.remove(prev)
        }
        ft.addToBackStack(null)
        AlertDialogWIthSpinner.newInstance().show(ft, "dialog")
    }

    private fun makePhoneCall() {
        val number = binding.content.phoneNumber.text.toString()
        if (number.length > 0) {
            if (ContextCompat.checkSelfPermission(this,
                            Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CALL_PHONE), REQUEST_CALL)
            } else {
                val dial = "tel:$number"
                startActivity(Intent(Intent.ACTION_CALL, Uri.parse(dial)))
            }
        } else {
            Toast.makeText(this, "Enter Phone Number", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        if (requestCode == REQUEST_CALL) {
            if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                makePhoneCall()
            } else {
                Toast.makeText(this, "Permission DENIED", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun sendMail() {
        val recipientList = binding.content.email.text.toString()
        val recipients = recipientList.split(",").toTypedArray()
        val intent = Intent(Intent.ACTION_SEND)
        intent.putExtra(Intent.EXTRA_EMAIL, recipients)
        intent.type = "message/rfc822"
        startActivity(Intent.createChooser(intent, "Choose an email client"))
    }

    private fun openBuiltInGoogleMap() {
        val uri = "http://maps.google.com/maps?q=loc:$latitude,$longitude"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uri))
        intent.setPackage("com.google.android.apps.maps")
        startActivity(intent)
    }
}