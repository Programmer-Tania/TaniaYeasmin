package com.framebig.emedicine.features.order_history;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.framebig.emedicine.R;
import com.framebig.emedicine.features.model.OrderListModel;
import com.framebig.emedicine.utility.AppUtils;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by shohrab on 15.03.2018.
 */
public class OrderListAdapter extends ArrayAdapter<OrderListModel>
{

    private Context context;
    private ArrayList<OrderListModel> orderList;
    private TextView txtProductTotalPrice, txtOrderNumber, txtOrderStatus, txtOrderDate, textView_total_item;
    private ImageView imgProduct;
    private RecyclerCustomItemClickListener listener;

    public OrderListAdapter(
            Context context,
            ArrayList<OrderListModel> orderList,
            RecyclerCustomItemClickListener listener)
    {
        super(context, R.layout.cart_item, orderList);
        this.context = context;
        this.orderList = orderList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public View getView(
            int position,
            @Nullable View rowView,
            @NonNull ViewGroup parent)
    {

        if (rowView == null)
        {
            LayoutInflater inflater = (LayoutInflater) context.
                    getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            if (inflater != null)
            {
                rowView = inflater.inflate(R.layout.item_order, parent, false);
            }
        }

        if (rowView != null)
        {
            txtProductTotalPrice = rowView.findViewById(R.id.textView_totalProductPrice);
            txtOrderNumber = rowView.findViewById(R.id.textView_order_number);
            txtOrderStatus = rowView.findViewById(R.id.textView_order_status);
            txtOrderDate = rowView.findViewById(R.id.textView_orderDate);
            imgProduct = rowView.findViewById(R.id.imageView_Product);
            textView_total_item = rowView.findViewById(R.id.textView_total_item);
            rowView.setTag(orderList.get(position).getProductName());
        }

        OrderListModel orderListModel = orderList.get(position);
        Picasso.get().load(orderListModel.getImageUrl().isEmpty() ? "null" : orderListModel.getImageUrl()).error(R.drawable.image_not_found).placeholder(R.drawable.image_not_found).resize(350, 350).into(imgProduct);
        txtProductTotalPrice.setText(String.format(context.getString(R.string.total_price), orderListModel.getTotalOrderValue()));

        txtOrderStatus.setText(orderListModel.getOrderStatus());
        txtOrderNumber.setText(String.format(context.getString(R.string.order_no), orderListModel.getOrderNo()));
        textView_total_item.setText("Total Item: " + orderListModel.getTotalItem());

        if (orderListModel.getOrderStatus().equalsIgnoreCase("processing"))
        {
            txtOrderStatus.setTextColor(ContextCompat.getColor(context, R.color.blue));
        }
        else if (orderListModel.getOrderStatus().equalsIgnoreCase("shipped"))
        {
            txtOrderStatus.setTextColor(ContextCompat.getColor(context, R.color.green));
        }
        else if (orderListModel.getOrderStatus().equalsIgnoreCase("delivered"))
        {
            txtOrderStatus.setTextColor(ContextCompat.getColor(context, R.color.green));
        }
        else if (orderListModel.getOrderStatus().equalsIgnoreCase("cancelled"))
        {
            txtOrderStatus.setTextColor(ContextCompat.getColor(context, R.color.red));
        }
        txtOrderDate.setText("Order Date: " + AppUtils.formatDate(orderListModel.getOrderDate()));

        rowView.setOnClickListener(view -> listener.onRowSelected(getItem(position)));
        return rowView;
    }

    public interface RecyclerCustomItemClickListener
    {
        void onRowSelected(OrderListModel contact);
    }

}