package com.framebig.emedicine.utility;

import com.framebig.emedicine.features.cart.delivery_information.PaymentAPIResponse;
import com.framebig.emedicine.features.discounted_products.DiscountResponseItem;
import com.framebig.emedicine.features.model.CartModel;
import com.framebig.emedicine.features.model.ProductModel;
import com.framebig.emedicine.features.model.SettingsResponse;
import com.framebig.emedicine.features.model.SharedModel;
import org.jetbrains.annotations.NotNull;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.inject.Singleton;

public class ApplicationData {
    @Singleton
    public static ArrayList<CartModel> CART_MODEL_LIST = new ArrayList<CartModel>();
    @Singleton
    public static ArrayList<ProductModel> PRODUCT_MODEL_LIST = new ArrayList<ProductModel>();
    @Singleton
    public static List<DiscountResponseItem> DISCOUNT_PRODUCT_LIST = new ArrayList<DiscountResponseItem>();
    @Singleton
    public static ArrayList<ProductModel> FAVOURITE_PRODUCT_MODEL_LIST = new ArrayList<ProductModel>();
    @Singleton
    public static SharedModel SHARED_MODEL = new SharedModel();
    @Singleton
    public static SettingsResponse SETTINGS_RESPONSE = new SettingsResponse();
    @Singleton
    public static PaymentAPIResponse PAYMENT_RESPONSE = new PaymentAPIResponse();
    @Singleton
    public static ProductModel ProductDetails = new ProductModel();

    public static final String IS_A_FAVOURITE_PRODUCT = "FAVOURITE_PRODUCT";
    public static final boolean IS_LOCAL_HOST = false;

    public static final String SESSION_ID = "dfssdfsdfjlkfsd789dshfjds";
    public static final String ACCESS_TOKEN = "dfabcdefghijk_6lkmnlopqr";
    public static final String CURRENCY = "TAKA";
    public static final String FCM_DEFAULT_CHANNEL_ID = "fcm_default_channel_id";
    public static final String PRODUCT_OBJECT = "product";
    public static final String FACEBOOK_FINAL_URL = "https://graph.accountkit.com";
    public static String APP_NAME = getAppName();

    public static final int TESTER_SPACE_COUNT = 10;

    public static final String[] COMPANY_LIST = {"internal", "mrc", "bazarlagbe", "redandgreen", "mrcWholeSale"};
    public static final String[] TESTING_DATABASE_TYPE = {"Production", "Test"};

    public static final int SUCCESS_RESPONSE_CODE = 200;
    public static final int LOGIN_FAILED_RESPONSE_CODE = 450;
    public static final int VERIFICATION_REQUIRED_RESPONSE_CODE = 430;
    public static final int WRONG_VERIFICATION_RESPONSE_CODE = 440;
    public static final int INVALID_LOGIN_ID = 460;
    public static final int ORDER_NUMBER_LENGTH = 8;
    public static final int TRACK_ALERT_NO_INTERNET = 101;
    public static final int TRACK_ALERT_SERVER_PROBLEM = 100;
    public static final int TRACK_ALERT_VERIFICATION_REQUIRED = 200;
    public static final int TRACK_ALERT_WRONG_VERIFICATION = 300;
    public static final int TRACK_ALERT_CORRECT_VERIFICATION = 400;
    public static final int TRACK_ALERT_ORDER_FAILED = 500;
    public static final int TRACK_ALERT_DELETE_ITEM = 600;
    public static final int TRACK_ALERT_LOGIN_REQUIRED = 700;
    public static final int TRACK_ALERT_LOGIN_AS_GUEST_REQUIRED = 800;
    public static final int TRACK_ALERT_NO_STOCK = 900;

    public static int custome_quatity_maxLength = 5;
    public static final int MOBILE_NUMBER_LENGTH = 11;
    public static String UNIT_KILOGRAM = "Kilogram";
    public static final String IS_OPEN_SEARCH_VIEW = "IS_OPEN_SEARCH_VIEW";

    @NotNull
    public static final long PRODUCT_DOWNLOAD_DIFFERENCE_LIMIT = 10800000; // 3 hours; should automated.
    public static final ArrayList<String> paymentMethods = new ArrayList<>();

    public static String getCompanyID() {
        return "Emedicine Corner";
    }

    public static String getAppName() {
        return "";
    }

    public static String getCompanyName() {

        return "";
    }

    public static int getBranchID() {
        return 1;
    }

    public static String geFacebookPageID() {
        return "";
    }

    public static boolean isTestDb() {
        return true;
    }

    public static String getApiBaseUrl() {
        return "https://bdmarket.xyz/admin/";
    }

    public static String getAppIcon() {
        return "";
    }

    public static String hmacDigest(
            String msg,
            String keyString,
            String algo) {
        String digest = null;
        try {
            SecretKeySpec key = new SecretKeySpec((keyString).getBytes(StandardCharsets.UTF_8), algo);
            Mac mac = Mac.getInstance(algo);
            mac.init(key);

            byte[] bytes = mac.doFinal(msg.getBytes(StandardCharsets.US_ASCII));

            StringBuffer hash = new StringBuffer();
            for (int i = 0; i < bytes.length; i++) {
                String hex = Integer.toHexString(0xFF & bytes[i]);
                if (hex.length() == 1) {
                    hash.append('0');
                }
                hash.append(hex);
            }
            digest = hash.toString();
        } catch (InvalidKeyException e) {
        } catch (NoSuchAlgorithmException e) {
        }
        LogMe.i("st::", digest);
        return digest;
    }
}