package com.framebig.emedicine.features.model

import com.google.gson.annotations.SerializedName

data class OrderHistoryResponse(
        @SerializedName("orderNo")
        var orderNo: String? = "",

        @SerializedName("orderStatus")
        var orderStatus: String? = "",

        @SerializedName("productData")
        var productData: ArrayList<OrderListModel>? = ArrayList(),

        @SerializedName("shippingCharge")
        var shippingCharge: String? = "",

        @SerializedName("paymentDate")
        var paymentDate: String? = "",

        @SerializedName("deliveryDate")
        var deliveryDate: String? = "",

        @SerializedName("orderDate")
        var orderDate: String? = "",

        @SerializedName("billNo")
        var billNo: String? = ""
)