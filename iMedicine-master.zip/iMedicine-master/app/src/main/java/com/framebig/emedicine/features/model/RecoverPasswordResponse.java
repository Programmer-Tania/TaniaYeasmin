package com.framebig.emedicine.features.model;

import javax.annotation.Generated;

import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class RecoverPasswordResponse
{

    @SerializedName("response_code")
    private int responseCode;

    @SerializedName("response")
    private Response response;

    @SerializedName("status")
    private String status;

    public void setResponseCode(int responseCode)
    {
        this.responseCode = responseCode;
    }

    public int getResponseCode()
    {
        return responseCode;
    }

    public void setResponse(Response response)
    {
        this.response = response;
    }

    public Response getResponse()
    {
        return response;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

    public String getStatus()
    {
        return status;
    }

    @Override
    public String toString()
    {
        return "RecoverPasswordResponse{" + "response_code = '" + responseCode + '\'' + ",response = '" + response + '\'' + ",status = '" + status + '\'' + "}";
    }
}