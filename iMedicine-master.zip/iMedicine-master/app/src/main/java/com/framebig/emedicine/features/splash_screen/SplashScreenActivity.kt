package com.framebig.emedicine.features.splash_screen

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Window
import android.view.WindowManager
import androidx.databinding.DataBindingUtil
import com.framebig.emedicine.R
import com.framebig.emedicine.databinding.ActivitySplashBinding
import com.framebig.emedicine.features.BaseActivity
import com.framebig.emedicine.features.home.HomeActivity
import com.framebig.emedicine.utility.*
import kotlinx.android.synthetic.main.activity_splash.*

class SplashScreenActivity : BaseActivity() {
    var activity: Activity = this
    private lateinit var binding: ActivitySplashBinding

    public override fun onCreate(savedInstanceState: Bundle?) {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_splash)
        version_name!!.text = "Version: " + AppUtils.getVersionName(applicationContext)
        app_name!!.text = ApplicationData.getAppName()

        val lastUpdate = FrameBigApp.getDefaultSharePreference().getLong(PrefsValues.PRODUCT_UPDATE_CHECK);
        val currentTime = System.currentTimeMillis()

        val difference = currentTime - lastUpdate

        val differeceLimit = ApplicationData.PRODUCT_DOWNLOAD_DIFFERENCE_LIMIT;
        if (difference >= differeceLimit && lastUpdate > 0) {
            LogMe.i("diff", "difference is greater than 6 hours")
            FrameBigApp.getDefaultSharePreference().setLong(PrefsValues.PRODUCT_UPDATE_CHECK, currentTime)
        } else {
            LogMe.i("diff", "difference is less than 6 hours")
        }
        binding.appName.text = ApplicationData.getAppName()

        Handler(Looper.getMainLooper()).postDelayed({
            gotoHomeActivity()
        }, 2500)
    }

    private fun gotoHomeActivity() {
        val intent = Intent(activity, HomeActivity::class.java)
        startActivity(intent)
        finish()
    }
}

