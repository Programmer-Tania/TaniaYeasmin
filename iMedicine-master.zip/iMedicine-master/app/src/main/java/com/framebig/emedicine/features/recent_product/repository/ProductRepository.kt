package com.framebig.emedicine.features.recent_product.repository

import android.content.Context
import com.framebig.emedicine.database.dao.RecentProductDao
import com.framebig.emedicine.database.db.FramebigDatabase
import com.framebig.emedicine.features.model.ProductModel
import com.framebig.emedicine.retrofit.ApiClient
import com.framebig.emedicine.utility.ApplicationData
import com.framebig.emedicine.utility.FrameBigApp
import com.framebig.emedicine.utility.LogMe
import com.framebig.emedicine.utility.PrefsValues
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext

class ProductRepository(val context: Context) {

    var recentProductDao: RecentProductDao

    init {
        val nd = FramebigDatabase.getInstance(context)
        recentProductDao = nd.recentProductDao()
    }

    fun insert(note: ProductModel) {
        recentProductDao.insertProduct(note)
    }

    suspend fun getAllProducts(): List<ProductModel> {
        var list: List<ProductModel> = ArrayList()
        val lastUpdate = FrameBigApp.getDefaultSharePreference().getLong(PrefsValues.PRODUCT_UPDATE_CHECK)
        val currentTime = System.currentTimeMillis()

        val difference = currentTime - lastUpdate
        val differenceLimit = ApplicationData.PRODUCT_DOWNLOAD_DIFFERENCE_LIMIT

        if (difference >= differenceLimit) {
            FrameBigApp.getDefaultSharePreference().setLong(PrefsValues.PRODUCT_UPDATE_CHECK, currentTime)
            try {
                coroutineScope {
                    var productAsync = ApiClient.getApiInterface().
                    getAllProducts(ApplicationData.ACCESS_TOKEN,
                            ApplicationData.getCompanyID(),
                            ApplicationData.isTestDb())
                    val value = async { productAsync }.await()
                    list = value!!.productModelArrayList
                    saveDataToDatabase(list)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            LogMe.i("diff", "difference is greater than 6 hours")
            LogMe.i("diff", "Data comes from Server")

            return list
        } else {
            LogMe.i("diff", "difference is less than 6 hours")
            LogMe.i("diff", "Data comes from Locally")
            return recentProductDao.getAllProducts()
        }
    }

    suspend fun saveDataToDatabase(list: List<ProductModel>) = withContext(Dispatchers.IO) {
        recentProductDao.insertAllProducts(list)
    }
}