package com.framebig.emedicine.features.model;

/**
 * Created by Shihab on 2/22/2018.
 */

public class PlaceOrderResponseModel
{

    /*{
        "response_code": 200,
            "response": "Order is placed successfully.",
            "status": "success"
    }*/

    private int response_code;
    private Response response;
    private String status;

    public int getResponse_code()
    {
        return response_code;
    }

    public void setResponse_code(int response_code)
    {
        this.response_code = response_code;
    }

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

    public class Response
    {

        private int customerId;
        private String fullName;
        private String message;

        public int getCustomerId()
        {
            return customerId;
        }

        public void setCustomerId(int customerId)
        {
            this.customerId = customerId;
        }

        public String getFullName()
        {
            return fullName;
        }

        public void setFullName(String fullName)
        {
            this.fullName = fullName;
        }

        public String getMessage()
        {
            return message;
        }

        public void setMessage(String message)
        {
            this.message = message;
        }
    }
}
