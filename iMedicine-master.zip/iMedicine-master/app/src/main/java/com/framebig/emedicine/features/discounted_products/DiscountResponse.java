package com.framebig.emedicine.features.discounted_products;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.Expose;

public class DiscountResponse implements Serializable
{

    @SerializedName("response_code")
    @Expose
    private int responseCode;
    @SerializedName("response")
    @Expose
    private List<DiscountResponseItem> response = null;
    @SerializedName("status")
    @Expose
    private String status;
    private final static long serialVersionUID = 1221206302945109020L;

    /**
     * No args constructor for use in serialization
     */
    public DiscountResponse()
    {
    }

    /**
     * @param response
     * @param responseCode
     * @param status
     */
    public DiscountResponse(
            int responseCode,
            List<DiscountResponseItem> response,
            String status)
    {
        super();
        this.responseCode = responseCode;
        this.response = response;
        this.status = status;
    }

    public int getResponseCode()
    {
        return responseCode;
    }

    public void setResponseCode(int responseCode)
    {
        this.responseCode = responseCode;
    }

    public List<DiscountResponseItem> getResponse()
    {
        return response;
    }

    public void setResponse(List<DiscountResponseItem> response)
    {
        this.response = response;
    }

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

}