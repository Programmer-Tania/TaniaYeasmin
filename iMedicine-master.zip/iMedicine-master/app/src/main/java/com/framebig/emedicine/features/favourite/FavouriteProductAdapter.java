package com.framebig.emedicine.features.favourite;

import androidx.recyclerview.widget.RecyclerView;

import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.framebig.emedicine.R;
import com.framebig.emedicine.features.model.ProductModel;
import com.framebig.emedicine.utility.ApplicationData;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Shihab on 11/28/2018
 */
public class FavouriteProductAdapter extends RecyclerView.Adapter<FavouriteProductAdapter.MyViewHolder>
{

    private List<ProductModel> favouriteProductModelList;
    private ClickListener clickListener;

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener
    {

        private TextView productName;
        private TextView productPrice;
        private TextView productDiscountedPrice;
        private TextView productPrevPrice;
        private ImageView imageView_Product;
        private ImageView deleteFav;
        private RelativeLayout relative_productInfo;

        public MyViewHolder(View view)
        {

            super(view);

            this.imageView_Product = view.findViewById(R.id.imageView_Product);
            this.productName = view.findViewById(R.id.textView_ProductName);
            this.productPrice = view.findViewById(R.id.textView_totalProductPrice);
            this.productDiscountedPrice = view.findViewById(R.id.textView_discountedProductPrice);
            this.productPrevPrice = view.findViewById(R.id.textView_previousProductPrice);
            this.deleteFav = view.findViewById(R.id.deleteFav);
            this.relative_productInfo = view.findViewById(R.id.relative_productInfo);
            this.deleteFav.setOnClickListener(this);
            this.relative_productInfo.setOnClickListener(this);

        }

        @Override
        public void onClick(View v)
        {
            if (v == deleteFav)
            {
                clickListener.onPositionClicked(getAdapterPosition());
            }
            else if (v == relative_productInfo)
            {
                clickListener.onCellClicked(getAdapterPosition());
            }
        }
    }

    public FavouriteProductAdapter(
            List<ProductModel> favouriteProductModelList,
            ClickListener clickListener)
    {
        this.favouriteProductModelList = favouriteProductModelList;
        this.clickListener = clickListener;
    }

    @Override
    public MyViewHolder onCreateViewHolder(
            ViewGroup parent,
            int viewType)
    {

        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.favourite_item, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(
            MyViewHolder holder,
            int position)
    {

        try
        {
            //            ProductModel productCategoryModel = favouriteProductModelList.get(position);
            ProductModel productCategoryModel = ApplicationData.FAVOURITE_PRODUCT_MODEL_LIST.get(position);

            double discountedPrice = Double.parseDouble(productCategoryModel.getDiscountedPrice());

            holder.productName.setText(productCategoryModel.getProductName());

            if (discountedPrice > 0.0)
            {
                holder.productPrice.setVisibility(View.INVISIBLE);
                holder.productDiscountedPrice.setText(ApplicationData.SETTINGS_RESPONSE.getCurrencySymbol() + " " + discountedPrice);
                holder.productDiscountedPrice.setVisibility(View.VISIBLE);
                holder.productPrevPrice.setText(ApplicationData.SETTINGS_RESPONSE.getCurrencySymbol() + " " + productCategoryModel.getMaxOnlineCost());
                holder.productPrevPrice.setPaintFlags(holder.productPrevPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                holder.productPrevPrice.setVisibility(View.VISIBLE);
            }
            else
            {
                holder.productPrice.setText(ApplicationData.SETTINGS_RESPONSE.getCurrencySymbol() + " " + productCategoryModel.getMaxOnlineCost());
            }

            Picasso.get().load(productCategoryModel.getImageList().get(0)).error(R.drawable.image_not_found).placeholder(R.drawable.image_not_found).resize(350, 350).into(holder.imageView_Product);

            //holder.deleteFav.setOnClickListener(new );
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount()
    {
        //        return favouriteProductModelList.size();
        return ApplicationData.FAVOURITE_PRODUCT_MODEL_LIST.size();
    }
}
