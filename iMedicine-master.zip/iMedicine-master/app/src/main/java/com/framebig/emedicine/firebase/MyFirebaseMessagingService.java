/**
 * Copyright 2016 Google Inc. All Rights Reserved.
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.framebig.emedicine.firebase;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;

import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;

import android.util.Log;

import com.framebig.emedicine.R;
import com.framebig.emedicine.features.home.HomeActivity;
import com.framebig.emedicine.utility.AppUtils;
import com.framebig.emedicine.utility.ApplicationData;
import com.framebig.emedicine.utility.FrameBigApp;
import com.framebig.emedicine.utility.PrefsValues;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class MyFirebaseMessagingService extends FirebaseMessagingService
{

    private static final String TAG = "MyFirebaseMsgService";
    private PrefsValues prefsValues;
    private String mChannelId = ApplicationData.FCM_DEFAULT_CHANNEL_ID;
    private String customerName = "";
    private String emailId = "";
    private String phone = "";
    private String deliveryAddress = "";
    private String billingAddress = "";
    int customerId;

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage)
    {

        String notificationBody = "";
        String notificationTitle = "";

        // Check if message contains a data payload.
        if (remoteMessage.getData().size() > 0)
        {
            notificationBody = remoteMessage.getData().get("body").toString();
            notificationTitle = remoteMessage.getData().get("title").toString();
            customerId = Integer.parseInt(remoteMessage.getData().get("customerId"));
            customerName = remoteMessage.getData().get("customerName");
            emailId = remoteMessage.getData().get("emailId");
            phone = remoteMessage.getData().get("phone");
            deliveryAddress = remoteMessage.getData().get("deliveryAddress");
            billingAddress = remoteMessage.getData().get("billingAddress");
        }
        // Check if message contains a notification payload.
        if (remoteMessage.getNotification() != null)
        {
            Log.i(TAG, "Message Notification Body: " + remoteMessage.getNotification().getBody());
            notificationBody = remoteMessage.getNotification().getBody();
            notificationTitle = remoteMessage.getNotification().getTitle();
        }

        sendPushNotification(notificationTitle, notificationBody);

    }

    private void sendPushNotification(
            String title,
            String body)
    {

        Intent intent = new Intent(this, HomeActivity.class);
        intent.putExtra("menuActivity", "OrderHistoryListActivity");
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_ONE_SHOT);

        NotificationManager mNotificationManager = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {

            if (mNotificationManager != null)
            {
                mNotificationManager.createNotificationChannel(this.getNotificationChannel());
            }
        }

        NotificationCompat.Builder mBuilder =
                new NotificationCompat.Builder(this, mChannelId).setSmallIcon(R.drawable.ic_notification).setTicker(title).setContentTitle(title).setContentText(body).setAutoCancel(true).setLights(0xff0000ff, 300, 1000) // blue color
                .setWhen(System.currentTimeMillis()).setPriority(NotificationCompat.PRIORITY_DEFAULT).setStyle(new NotificationCompat.BigTextStyle().bigText(body)).setContentIntent(pendingIntent).setColor(getResources().getColor(R.color.colorPrimary));

        int NOTIFICATION_ID = 1; // Causes to update the same notification over and over again.
        if (mNotificationManager != null)
        {
            mNotificationManager.notify(NOTIFICATION_ID, mBuilder.build());
        }

        AppUtils.playSound(this, R.raw.mouse_click);

        this.storeCustomerPref();

    }

    @Override
    public void onNewToken(String token)
    {
        super.onNewToken(token);
        prefsValues = FrameBigApp.getDefaultSharePreference();
        prefsValues.setFirebasebaseTokeId(token);
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private NotificationChannel getNotificationChannel()
    {

        Uri soundUri =
                Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://" + getApplicationContext().getPackageName() + "/" + R.raw.mouse_click);

        NotificationChannel nChannel = new NotificationChannel(mChannelId, "My Notifications", NotificationManager.IMPORTANCE_HIGH);
        nChannel.setLightColor(Color.GRAY);
        nChannel.enableLights(true);
        nChannel.setDescription("Channel Description");
        AudioAttributes audioAttributes =
                new AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).setUsage(AudioAttributes.USAGE_NOTIFICATION).build();
        nChannel.setSound(soundUri, audioAttributes);

        return nChannel;
    }

    private void storeCustomerPref()
    {

        prefsValues = FrameBigApp.getDefaultSharePreference();

        prefsValues.setCustomerName(customerName);
        prefsValues.setCustomerId(customerId);
        prefsValues.setCustomerPhone(phone);
        prefsValues.setCustomerEmail(emailId);
        prefsValues.setCustomerDeliveryAddress(deliveryAddress);
        prefsValues.setCustomerBillingAddress(billingAddress);
    }
}
