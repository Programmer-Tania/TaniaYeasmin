package com.framebig.emedicine.features.recent_product.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.framebig.emedicine.R
import com.framebig.emedicine.databinding.ItemRecentProductBinding
import com.framebig.emedicine.features.model.ProductModel
import com.framebig.emedicine.utility.ApplicationData
import com.squareup.picasso.Picasso
import java.util.*

/**
 * Created by Shihab on 06/28/2020
 */
class RecentProductListAdapter(private val listener: RecyclerCustomItemClickListener) : RecyclerView.Adapter<RecentProductListAdapter.MyViewHolder>(), Filterable {

    private var productModelList: ArrayList<ProductModel>? = null
    private var productModelListFilteredList: ArrayList<ProductModel>? = ArrayList()

    fun setProductModelList(productModelList: ArrayList<ProductModel>?) {
        this.productModelList = productModelList
        productModelListFilteredList = productModelList
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val bindingItem = DataBindingUtil.inflate<ItemRecentProductBinding>(LayoutInflater.from(parent.context),
                R.layout.item_recent_product, parent, false)
        return MyViewHolder(bindingItem)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        try {
            val productModel = productModelListFilteredList!![position]
            holder.productBinding.productName.text = productModel.productName
            if (productModel.maxOnlineCost != null) {
                holder.productBinding.productPrice.text = ApplicationData.SETTINGS_RESPONSE.currencySymbol + " " + productModel.maxOnlineCost
            }
            val image = productModel.imageList[0]
            Picasso.get().load(image)
                    .error(R.drawable.image_not_found)
                    .placeholder(R.drawable.image_not_found)
                    .resize(350, 350)
                    .into(holder.productBinding.productImageView)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun getItemCount(): Int {
        return productModelListFilteredList!!.size
    }

    override fun getFilter(): Filter {
        return exampleFilter
    }

    private val exampleFilter: Filter = object : Filter() {
        override fun performFiltering(constraint: CharSequence): FilterResults {
            val filterPattern = constraint.toString()
            productModelListFilteredList = if (filterPattern.isEmpty()) {
                productModelList
            } else {
                val filteredList = ArrayList<ProductModel>()
                for (serviceSubCategory in productModelList!!) {
                    if (serviceSubCategory.productName.toLowerCase().contains(filterPattern)) {
                        filteredList.add(serviceSubCategory)
                    }
                }
                filteredList
            }
            val results = FilterResults()
            results.values = productModelListFilteredList
            return results
        }

        override fun publishResults(constraint: CharSequence, results: FilterResults) {
            productModelListFilteredList = results.values as ArrayList<ProductModel>
            notifyDataSetChanged()
        }
    }

    inner class MyViewHolder(val productBinding: ItemRecentProductBinding) : RecyclerView.ViewHolder(productBinding.root), View.OnClickListener {
        override fun onClick(v: View) {
            listener.getItem(productModelListFilteredList!![adapterPosition])
        }

        init {
            productBinding.root.setOnClickListener(this)
        }
    }

    interface RecyclerCustomItemClickListener {
        fun onRowSelected(position: Int)
        fun getItem(productModel: ProductModel?)
    }
}