package com.framebig.emedicine.database.dao

import androidx.room.*
import com.framebig.emedicine.features.model.ProductModel

@Dao
interface RecentProductDao {

    @Insert
    fun insertProduct(productModel: ProductModel)

    @Update
    fun updateProduct(productModel: ProductModel)

    @Delete
    fun delete(productModel: ProductModel)

    @Query("SELECT * FROM product")
    suspend fun getAllProducts(): List<ProductModel>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllProducts(productList: List<ProductModel>)

}