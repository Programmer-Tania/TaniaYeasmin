package com.framebig.emedicine.features.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class CurrentStockResponse implements Serializable
{

    @SerializedName("response_code")
    @Expose
    private int responseCode;

    @SerializedName("response")
    @Expose
    private ResponseModel response = null;

    @SerializedName("status")
    @Expose
    private String status;
    private final static long serialVersionUID = 1221206302945109020L;

    /**
     * No args constructor for use in serialization
     */
    public CurrentStockResponse()
    {
    }

    /**
     * @param response
     * @param responseCode
     * @param status
     */
    public CurrentStockResponse(
            int responseCode,
            ResponseModel response,
            String status)
    {
        super();
        this.responseCode = responseCode;
        this.response = response;
        this.status = status;
    }

    public int getResponseCode()
    {
        return responseCode;
    }

    public void setResponseCode(int responseCode)
    {
        this.responseCode = responseCode;
    }

    public ResponseModel getResponse()
    {
        return response;
    }

    public void setResponse(ResponseModel response)
    {
        this.response = response;
    }

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

    public class ResponseModel {
        @SerializedName("currentStock")
        @Expose
        String currentStock;

        public String getCurrentStock()
        {
            return currentStock;
        }

        public void setCurrentStock(String currentStock)
        {
            this.currentStock = currentStock;
        }
    }
}