package com.framebig.emedicine.features.cart.delivery_information;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.appcompat.widget.Toolbar;

import android.view.MenuItem;

import com.framebig.emedicine.R;
import com.framebig.emedicine.features.BaseActivity;
import com.framebig.emedicine.utility.AlertDialogOneButton;
import com.framebig.emedicine.utility.LogMe;

public class DeliveryInformationActivity extends BaseActivity implements ChangeAddressFragment.OnUpdateListener,
        AlertDialogOneButton.OnOkButtonClickListener
{

    private static final String TAG = "delievaryActivity";
    FragmentManager fragmentManager;
    DelivaryFragment delivaryFragment;
    OnSendMessage onSendMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_information);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getSupportActionBar().setTitle(R.string.checkout);

        delivaryFragment = DelivaryFragment.newInstance();
        addFragment(R.id.fragment_place, delivaryFragment);

        fragmentManager = getSupportFragmentManager();
        fragmentManager.addOnBackStackChangedListener(new FragmentManager.OnBackStackChangedListener()
        {
            @Override
            public void onBackStackChanged()
            {
                LogMe.i(TAG, "onBackStackChanged count: " + fragmentManager.getBackStackEntryCount());
            }
        });
    }

    void replaceFragment(
            int placeHolderId,
            Fragment fragment)
    {
        //String name = fragment.get
        //FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(placeHolderId, fragment);
        fragmentTransaction.addToBackStack("");
        fragmentTransaction.commit();
    }

    void addFragment(
            int placeHolderId,
            Fragment fragment)
    {

        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.add(placeHolderId, fragment);
        fragmentTransaction.addToBackStack("");
        fragmentTransaction.commit();
    }

    @Override
    public void onBackPressed()
    {
        if (fragmentManager.getBackStackEntryCount() > 1) fragmentManager.popBackStackImmediate();
        else
        {

            //super.onBackPressed();
            this.finish();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {

        if (item.getItemId() == android.R.id.home)
        {
            //NavUtils.navigateUpFromSameTask(this);
            if (fragmentManager.getBackStackEntryCount() > 1) fragmentManager.popBackStackImmediate();
            else
            {

                //super.onBackPressed();
                this.finish();
            }

            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void getAddressUpdate(String fullAddress)
    {
        //showToastMessage("" + fullAddress);
        onSendMessage.sendMessage();
    }

    void updateAddress(OnSendMessage onSendMessage)
    {
        this.onSendMessage = onSendMessage;
    }

    @Override
    public void onOkButtonClick(int trackingNumber)
    {

        getSupportFragmentManager().popBackStack();
    }

    public interface OnSendMessage
    {
        void sendMessage();
    }

    //    public void popOffSubscreens() {
    //        while (subscreensOnTheStack > 0) {
    //            fragments.popBackStackImmediate();
    //        }
    //    }

}
