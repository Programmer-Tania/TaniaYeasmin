package com.framebig.emedicine.features.favourite;

import com.framebig.emedicine.features.model.ProductModel;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class GetFavouriteResponse
{

    //private FavResponse[] response;
    private String status;
    private int response_code;

    @SerializedName("response")
    @Expose
    private ArrayList<ProductModel> productModelArrayList = new ArrayList<>();

    //    public FavResponse[] getResponse ()
    //    {
    //        return response;
    //    }
    //
    //    public void setResponse (FavResponse[] response)
    //    {
    //        this.response = response;
    //    }

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

    public int getResponse_code()
    {
        return response_code;
    }

    public void setResponse_code(int response_code)
    {
        this.response_code = response_code;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [response = " + ", status = " + status + ", response_code = " + response_code + "]";
    }

    public ArrayList<ProductModel> getProductModelArrayList()
    {
        return productModelArrayList;
    }

    public void setProductModelArrayList(ArrayList<ProductModel> productModelArrayList)
    {
        this.productModelArrayList = productModelArrayList;
    }
}
