package com.framebig.emedicine.features.home;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.framebig.emedicine.R;
import com.framebig.emedicine.features.model.ProductCategory;

import java.util.List;

/**
 * Created by Shihab on 1/28/2016.
 */
public class ProductCategoryAdapter extends RecyclerView.Adapter<ProductCategoryAdapter.MyViewHolder> {

    private List<ProductCategory> productCategoryModelList;
    private static final int LIST_ITEM = 0;
    public static final int GRID_ITEM = 1;
    public static boolean isSwitchView;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView productDescription;
        private ImageView categoryImage;
        private TextView totalProducts;
        private Context context;

        public MyViewHolder(
                View view,
                Context context) {

            super(view);
            this.categoryImage = view.findViewById(R.id.imageView);
            this.productDescription = view.findViewById(R.id.category_description);
            this.totalProducts = view.findViewById(R.id.total_products);
            this.context = context;
        }
    }

    public ProductCategoryAdapter(List<ProductCategory> productCategoryModelList) {
        this.productCategoryModelList = productCategoryModelList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(
            ViewGroup parent,
            int viewType) {
        View itemView;
        if (viewType == LIST_ITEM) {
            itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.product_category_list, null);
        } else {
            itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.product_category_cardview, null);
        }
        return new MyViewHolder(itemView, parent.getContext());
    }

    @Override
    public void onBindViewHolder(
            MyViewHolder holder,
            int position) {

        try {
            ProductCategory productCategoryModel = productCategoryModelList.get(position);
            holder.productDescription.setText(productCategoryModel.getName());
            holder.categoryImage.setImageResource(R.drawable.image_not_found);

            //todo : after getting image
            /*Picasso.get().load(productCategoryModel.getImageList().get(0)).
                    error(R.drawable.image_not_found).placeholder(R.drawable.image_not_found).resize(350, 350).into(holder.categoryImage);*/

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return productCategoryModelList.size();
    }

    @Override
    public int getItemViewType(int position) {
        if (isSwitchView) {
            return LIST_ITEM;
        } else {
            return GRID_ITEM;
        }
    }

    public boolean toggleItemViewType() {
        isSwitchView = !isSwitchView;
        return isSwitchView;
    }
}