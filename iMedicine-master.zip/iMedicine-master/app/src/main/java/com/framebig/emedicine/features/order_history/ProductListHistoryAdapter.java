package com.framebig.emedicine.features.order_history;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.framebig.emedicine.R;
import com.framebig.emedicine.features.model.OrderListModel;
import com.framebig.emedicine.utility.ApplicationData;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by Shihab on 1/28/2016.
 */
public class ProductListHistoryAdapter extends RecyclerView.Adapter<ProductListHistoryAdapter.MyViewHolder>
{

    private ArrayList<OrderListModel> productModelListFilteredList;

    public class MyViewHolder extends RecyclerView.ViewHolder
    {
        private TextView productName, productPrice, quantity;
        private ImageView productImage;

        public MyViewHolder(View view)
        {
            super(view);
            this.productImage = view.findViewById(R.id.imageView_Product);
            this.productName = view.findViewById(R.id.textView_product_name);
            this.productPrice = view.findViewById(R.id.textView_totalProductPrice);
            this.quantity = view.findViewById(R.id.textView_quantity);
        }
    }

    public ProductListHistoryAdapter(ArrayList<OrderListModel> product_list)
    {
        this.productModelListFilteredList = product_list;
    }

    @Override
    public MyViewHolder onCreateViewHolder(
            ViewGroup parent,
            int viewType)
    {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product_history, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(
            MyViewHolder holder,
            int position)
    {

        try
        {
            OrderListModel productModel = productModelListFilteredList.get(position);
            holder.productName.setText(productModel.getProductName());
            holder.quantity.setText("Quantity: " + productModel.getAmount());
            holder.productPrice.setText(productModel.getUnitSellingCost() + " " + ApplicationData.SETTINGS_RESPONSE.getCurrency());
            String image = productModel.getImageUrl();
            Picasso.get().load(image).error(R.drawable.image_not_found).placeholder(R.drawable.image_not_found).resize(350, 350).into(holder.productImage);

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount()
    {
        return productModelListFilteredList.size();
    }
}