package com.framebig.emedicine.features.model;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SettingsResponse implements Serializable
{

    @SerializedName("defaultLayout")
    @Expose
    private String defaultLayout;

    @SerializedName("categoryPageImageSlider")
    @Expose
    private boolean categoryPageImageSlider;

    @SerializedName("guestCustomerId")
    @Expose
    private int guestCustomerId;

    @SerializedName("latitude")
    @Expose
    private String latitude;

    @SerializedName("guestCustomer")
    @Expose
    private boolean guestCustomer;

    @SerializedName("primaryColor")
    @Expose
    private String primaryColor;

    @SerializedName("businessName")
    @Expose
    private String businessName;

    @SerializedName("deliveryCharge")
    @Expose
    private String deliveryCharge;

    @SerializedName("onlineBranchId")
    @Expose
    private int onlineBranchId;

    @SerializedName("customQuantity")
    @Expose
    private boolean customQuantity;

    @SerializedName("appIcon")
    @Expose
    private String appIcon = "";

    @SerializedName("companyEmail")
    @Expose
    private String companyEmail;

    @SerializedName("companyPhone")
    @Expose
    private String companyPhone;

    @SerializedName("orderCancellation")
    @Expose
    private boolean orderCancellation;

    @SerializedName("currency")
    @Expose
    private String currency;

    @SerializedName("ascentColor")
    @Expose
    private String ascentColor;

    @SerializedName("pushNotification")
    @Expose
    private boolean pushNotification;

    @SerializedName("longitude")
    @Expose
    private String longitude;

    @SerializedName("companyLogo")
    @Expose
    private String companyLogo;

    @SerializedName("returnPolicy")
    @Expose
    private String returnPolicy;

    @SerializedName("currencySymbol")
    @Expose
    private String currencySymbol;

    @SerializedName("businessOwnerName")
    @Expose
    private String businessOwnerName;

    @SerializedName("bkashNumber")
    @Expose
    private String bkashNumber;

    @SerializedName("mhPrice")
    @Expose
    private boolean mhPrice;

    @SerializedName("primaryColorDark")
    @Expose
    private String primaryColorDark;

    @SerializedName("mhImage")
    @Expose
    private boolean mhImage;

    @SerializedName("companyAddress")
    @Expose
    private String companyAddress;

    @SerializedName("companyWebsite")
    @Expose
    private String companyWebsite;

    @SerializedName("mhStock")
    @Expose
    private boolean mhStock;

    @SerializedName("displayStock")
    @Expose
    private boolean displayStock;

    @SerializedName("stockRestriction")
    @Expose
    private boolean stockRestriction;

    @SerializedName("mhProductDescription")
    @Expose
    private boolean mhProductDescription;

    @SerializedName("facebookPageId")
    @Expose
    private String facebookPageId;

    private final static long serialVersionUID = 1083999423377118064L;

    /**
     * No args constructor for use in serialization
     */
    public SettingsResponse()
    {
    }

    /**
     * @param defaultLayout
     * @param categoryPageImageSlider
     * @param guestCustomerId
     * @param latitude
     * @param guestCustomer
     * @param primaryColor
     * @param businessName
     * @param deliveryCharge
     * @param onlineBranchId
     * @param customQuantity
     * @param appIcon
     * @param companyEmail
     * @param companyPhone
     * @param orderCancellation
     * @param currency
     * @param ascentColor
     * @param pushNotification
     * @param longitude
     * @param companyLogo
     * @param returnPolicy
     * @param currencySymbol
     * @param businessOwnerName
     * @param bkashNumber
     * @param mhPrice
     * @param primaryColorDark
     * @param mhImage
     * @param companyAddress
     * @param companyWebsite
     * @param mhStock
     * @param mhProductDescription
     * @param facebookPageId
     */
    public SettingsResponse(
            String defaultLayout,
            boolean categoryPageImageSlider,
            int guestCustomerId,
            String latitude,
            boolean guestCustomer,
            String primaryColor,
            String businessName,
            String deliveryCharge,
            int onlineBranchId,
            boolean customQuantity,
            String appIcon,
            String companyEmail,
            String companyPhone,
            boolean orderCancellation,
            String currency,
            String ascentColor,
            boolean pushNotification,
            String longitude,
            String companyLogo,
            String returnPolicy,
            String currencySymbol,
            String businessOwnerName,
            String bkashNumber,
            boolean mhPrice,
            String primaryColorDark,
            boolean mhImage,
            String companyAddress,
            String companyWebsite,
            boolean mhStock,
            boolean mhProductDescription,
            String facebookPageId)
    {
        super();
        this.defaultLayout = defaultLayout;
        this.categoryPageImageSlider = categoryPageImageSlider;
        this.guestCustomerId = guestCustomerId;
        this.latitude = latitude;
        this.guestCustomer = guestCustomer;
        this.primaryColor = primaryColor;
        this.businessName = businessName;
        this.deliveryCharge = deliveryCharge;
        this.onlineBranchId = onlineBranchId;
        this.customQuantity = customQuantity;
        this.appIcon = appIcon;
        this.companyEmail = companyEmail;
        this.companyPhone = companyPhone;
        this.orderCancellation = orderCancellation;
        this.currency = currency;
        this.ascentColor = ascentColor;
        this.pushNotification = pushNotification;
        this.longitude = longitude;
        this.companyLogo = companyLogo;
        this.returnPolicy = returnPolicy;
        this.currencySymbol = currencySymbol;
        this.businessOwnerName = businessOwnerName;
        this.bkashNumber = bkashNumber;
        this.mhPrice = mhPrice;
        this.primaryColorDark = primaryColorDark;
        this.mhImage = mhImage;
        this.companyAddress = companyAddress;
        this.companyWebsite = companyWebsite;
        this.mhStock = mhStock;
        this.mhProductDescription = mhProductDescription;
        this.facebookPageId = facebookPageId;
    }

    public String getDefaultlayout()
    {
        return defaultLayout;
    }

    public void setDefaultlayout(String defaultLayout)
    {
        this.defaultLayout = defaultLayout;
    }

    public boolean getCategoryPageImageSlider()
    {
        return categoryPageImageSlider;
    }

    public void setCategoryPageImageSlider(boolean categoryPageImageSlider)
    {
        this.categoryPageImageSlider = categoryPageImageSlider;
    }

    public int getGuestCustomerId()
    {
        return guestCustomerId;
    }

    public void setGuestCustomerId(int guestCustomerId)
    {
        this.guestCustomerId = guestCustomerId;
    }

    public String getLatitude()
    {
        return latitude;
    }

    public void setLatitude(String latitude)
    {
        this.latitude = latitude;
    }

    public boolean getGuestCustomer()
    {
        return guestCustomer;
    }

    public void setGuestCustomer(boolean guestCustomer)
    {
        this.guestCustomer = guestCustomer;
    }

    public String getPrimaryColor()
    {
        return primaryColor;
    }

    public void setPrimaryColor(String primaryColor)
    {
        this.primaryColor = primaryColor;
    }

    public String getBusinessName()
    {
        return businessName;
    }

    public void setBusinessName(String businessName)
    {
        this.businessName = businessName;
    }

    public String getDeliveryCharge()
    {
        return deliveryCharge;
    }

    public void setDeliveryCharge(String deliveryCharge)
    {
        this.deliveryCharge = deliveryCharge;
    }

    public int getOnlineBranchId()
    {
        return onlineBranchId;
    }

    public void setOnlineBranchId(int onlineBranchId)
    {
        this.onlineBranchId = onlineBranchId;
    }

    public boolean getCustomQuantity()
    {
        return customQuantity;
    }

    public void setCustomQuantity(boolean customQuantity)
    {
        this.customQuantity = customQuantity;
    }

    public String getAppIcon()
    {
        return appIcon;
    }

    public void setAppIcon(String appIcon)
    {
        this.appIcon = appIcon;
    }

    public String getCompanyEmail()
    {
        return companyEmail;
    }

    public void setCompanyEmail(String companyEmail)
    {
        this.companyEmail = companyEmail;
    }

    public String getCompanyPhone()
    {
        return companyPhone;
    }

    public void setCompanyPhone(String companyPhone)
    {
        this.companyPhone = companyPhone;
    }

    public boolean getOrderCancellation()
    {
        return orderCancellation;
    }

    public void setOrderCancellation(boolean orderCancellation)
    {
        this.orderCancellation = orderCancellation;
    }

    public String getCurrency()
    {
        return currency;
    }

    public void setCurrency(String currency)
    {
        this.currency = currency;
    }

    public String getAscentColor()
    {
        return ascentColor;
    }

    public void setAscentColor(String ascentColor)
    {
        this.ascentColor = ascentColor;
    }

    public boolean getPushNotification()
    {
        return pushNotification;
    }

    public void setPushNotification(boolean pushNotification)
    {
        this.pushNotification = pushNotification;
    }

    public String getLongitude()
    {
        return longitude;
    }

    public void setLongitude(String longitude)
    {
        this.longitude = longitude;
    }

    public String getCompanyLogo()
    {
        return companyLogo;
    }

    public void setCompanyLogo(String companyLogo)
    {
        this.companyLogo = companyLogo;
    }

    public String getReturnPolicy()
    {
        return returnPolicy;
    }

    public void setReturnPolicy(String returnPolicy)
    {
        this.returnPolicy = returnPolicy;
    }

    public String getCurrencySymbol()
    {
        return currencySymbol;
    }

    public void setCurrencySymbol(String currencySymbol)
    {
        this.currencySymbol = currencySymbol;
    }

    public String getBusinessOwnerName()
    {
        return businessOwnerName;
    }

    public void setBusinessOwnerName(String businessOwnerName)
    {
        this.businessOwnerName = businessOwnerName;
    }

    public String getBkashNumber()
    {
        return bkashNumber;
    }

    public void setBkashNumber(String bkashNumber)
    {
        this.bkashNumber = bkashNumber;
    }

    public boolean getMhPrice()
    {
        return mhPrice;
    }

    public void setMhPrice(boolean mhPrice)
    {
        this.mhPrice = mhPrice;
    }

    public String getPrimaryColorDark()
    {
        return primaryColorDark;
    }

    public void setPrimaryColorDark(String primaryColorDark)
    {
        this.primaryColorDark = primaryColorDark;
    }

    public boolean getMhImage()
    {
        return mhImage;
    }

    public void setMhImage(boolean mhImage)
    {
        this.mhImage = mhImage;
    }

    public String getCompanyAddress()
    {
        return companyAddress;
    }

    public void setCompanyAddress(String companyAddress)
    {
        this.companyAddress = companyAddress;
    }

    public String getCompanyWebsite()
    {
        return companyWebsite;
    }

    public void setCompanyWebsite(String companyWebsite)
    {
        this.companyWebsite = companyWebsite;
    }

    public boolean getMhStock()
    {
        return mhStock;
    }

    public void setMhStock(boolean mhStock)
    {
        this.mhStock = mhStock;
    }

    public boolean getMhProductDescription()
    {
        return mhProductDescription;
    }

    public void setMhProductDescription(boolean mhProductDescription)
    {
        this.mhProductDescription = mhProductDescription;
    }

    public String getFacebookPageId()
    {
        return facebookPageId;
    }

    public void setFacebookPageId(String facebookPageId)
    {
        this.facebookPageId = facebookPageId;
    }

    public boolean isDisplayStock()
    {
        return displayStock;
    }

    public void setDisplayStock(boolean displayStock)
    {
        this.displayStock = displayStock;
    }

    public boolean isStockRestriction()
    {
        return stockRestriction;
    }

    public void setStockRestriction(boolean stockRestriction)
    {
        this.stockRestriction = stockRestriction;
    }
}