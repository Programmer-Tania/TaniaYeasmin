package com.framebig.emedicine.features.home;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.framebig.emedicine.R;
import com.framebig.emedicine.features.BaseActivity;
import com.framebig.emedicine.features.best_selling.BestSellingProductsActivity;
import com.framebig.emedicine.features.cart.cart_item.CartActivity;
import com.framebig.emedicine.features.change_password.ChangePasswordActivity;
import com.framebig.emedicine.features.contactus.ContactUsActivity;
import com.framebig.emedicine.features.discounted_products.DiscountedProductListActivity;
import com.framebig.emedicine.features.favourite.FavouriteProductActivity;
import com.framebig.emedicine.features.model.ProductCategory;
import com.framebig.emedicine.features.model.ProductCategoryModel;
import com.framebig.emedicine.features.model.ProductCategoryResponse;
import com.framebig.emedicine.features.model.SettingsModel;
import com.framebig.emedicine.features.order_history.OrderHistoryListActivity;
import com.framebig.emedicine.features.product_list.ProductListActivity;
import com.framebig.emedicine.features.profile.UserProfileActivity;
import com.framebig.emedicine.features.recent_product.RecentProductActivity;
import com.framebig.emedicine.features.sign_in.SignInActivity;
import com.framebig.emedicine.features.sign_up.SignUpActivity;
import com.framebig.emedicine.listener.RecyclerTouchListener;
import com.framebig.emedicine.retrofit.ApiClient;
import com.framebig.emedicine.utility.AlertDialogTwoButton;
import com.framebig.emedicine.utility.AppUtils;
import com.framebig.emedicine.utility.ApplicationData;
import com.framebig.emedicine.utility.Connectivity;
import com.framebig.emedicine.utility.FrameBigApp;
import com.framebig.emedicine.utility.ItemOffsetDecoration;
import com.framebig.emedicine.utility.LogMe;
import com.framebig.emedicine.utility.PrefsValues;
import com.framebig.emedicine.utility.RecyclerType;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeActivity extends BaseActivity implements NavigationView.OnNavigationItemSelectedListener, AlertDialogTwoButton.ButtonClickListener {

    private TextView txtViewCount;
    private TextView textViewCustomerName;
    private String TAG = "HomeActivity";
    private RecyclerView recyclerCategory;
    private ProductCategoryAdapter categoryAdapter;
    private HomeActivity homeActivity;
    private List<ProductCategory> productCategories;
    private PrefsValues prefsValues;
    private ImageView iv_search;
    private FloatingActionButton fab_list;
    private FloatingActionButton fab_grid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        homeActivity = this;

        Toolbar toolbar = findViewById(R.id.toolbar_home);
        setSupportActionBar(toolbar);

        prefsValues = FrameBigApp.getDefaultSharePreference();
        View notifications = findViewById(R.id.notifications);
        txtViewCount = notifications.findViewById(R.id.txtCount);
        notifications.setOnClickListener(v -> goToCartActivity());
        fab_list = findViewById(R.id.fab_switch_list);
        fab_grid = findViewById(R.id.fab_switch_grid);
        fab_grid.setOnClickListener(v -> switchLayout());
        fab_list.setOnClickListener(v -> switchLayout());

        iv_search = findViewById(R.id.iv_search);
        iv_search.setOnClickListener(view -> {
            goToAllProductActivity(true);
        });

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        View headerView = navigationView.getHeaderView(0);

        textViewCustomerName = headerView.findViewById(R.id.nav_header_user_name);
        TextView textViewCurrentTime = headerView.findViewById(R.id.nav_header_textView_current_time);
        ImageView navImageView = headerView.findViewById(R.id.nav_imageView);
        TextView textViewClient = headerView.findViewById(R.id.nav_header_client);
        TextView textViewDatabase = headerView.findViewById(R.id.nav_database);
        TextView txtviewnav_developer_mode = headerView.findViewById(R.id.nav_developer_mode);

        if (FrameBigApp.getDefaultSharePreference().getBoolean(PrefsValues.IS_DEVELOPER_MODE_ENABLE)) {

            textViewClient.setText("" + ApplicationData.getCompanyName() + " : " + ApplicationData.getCompanyID());
            textViewDatabase.setText("Test DataBase: " + ApplicationData.isTestDb());

        } else {
            textViewClient.setVisibility(View.INVISIBLE);
            textViewDatabase.setVisibility(View.INVISIBLE);
            txtviewnav_developer_mode.setVisibility(View.INVISIBLE);
        }

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");
        String currentDate = sdf.format(new Date());

        if (prefsValues.getCustomerId() != 0) {
            textViewCustomerName.setText("Welcome " + FrameBigApp.getDefaultSharePreference().getCustomerName() + "!");
        } else {
            textViewCustomerName.setText("Welcome !");
        }

        textViewCurrentTime.setText(currentDate);
        hideNavigationMenu(navigationView);
        if (ApplicationData.SETTINGS_RESPONSE != null) {
            if (ApplicationData.getAppIcon().length() > 0) {
                Picasso.get().load(ApplicationData.getAppIcon()).resize(150, 150).placeholder(R.mipmap.ic_launcher).into(navImageView);
            }
        }

        init();
    }

    private void switchLayout() {

        if (fab_grid.getVisibility() == View.VISIBLE) {
            fab_grid.setVisibility(View.INVISIBLE);
            fab_list.setVisibility(View.VISIBLE);
        } else if (fab_list.getVisibility() == View.VISIBLE) {
            fab_list.setVisibility(View.INVISIBLE);
            fab_grid.setVisibility(View.VISIBLE);
        }
        boolean isSwitched = categoryAdapter.toggleItemViewType();
        recyclerCategory.setLayoutManager(isSwitched ? new LinearLayoutManager(this) : new GridLayoutManager(this, 2));
        categoryAdapter.notifyDataSetChanged();
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.home, menu);
        LogMe.i(TAG, "onCreateOptionsMenu called");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.nav_update_profile) {

            Intent orderListIntent = new Intent(HomeActivity.this, UserProfileActivity.class);
            startActivity(orderListIntent);

        } else if (id == R.id.nav_order_history) {

            Intent orderListIntent = new Intent(HomeActivity.this, OrderHistoryListActivity.class);
            startActivity(orderListIntent);

        } else if (id == R.id.nav_favorite) {

            Intent orderListIntent = new Intent(HomeActivity.this, FavouriteProductActivity.class);
            startActivity(orderListIntent);

        } else if (id == R.id.nav_chat_with_us) {

            goToFacebookChat();

        } else if (id == R.id.nav_all_products) {

            goToAllProductActivity(false);
            //            showToastMessage("Coming soon...");

        } else if (id == R.id.nav_new_items) {

            showToastMessage("Coming soon...");

        } else if (id == R.id.nav_offers) {

            Intent offerListIntent = new Intent(HomeActivity.this, DiscountedProductListActivity.class);
            startActivity(offerListIntent);

        } else if (id == R.id.nav_best_selling) {

            Intent offerListIntent = new Intent(HomeActivity.this, BestSellingProductsActivity.class);
            startActivity(offerListIntent);

        } else if (id == R.id.nav_contact_us) {

            Intent orderListIntent = new Intent(HomeActivity.this, ContactUsActivity.class);
            startActivity(orderListIntent);

        } else if (id == R.id.nav_help) {

        } else if (id == R.id.nav_update_or_rate_us) {

            openPlayStore();

        } else if (id == R.id.nav_log_in) {

            Intent signInActivityIntent = new Intent(HomeActivity.this, SignInActivity.class);
            startActivity(signInActivityIntent);

        } else if (id == R.id.nav_register) {

            Intent signUpActivityIntent = new Intent(HomeActivity.this, SignUpActivity.class);
            startActivity(signUpActivityIntent);

        } else if (id == R.id.nav_change_password) {

            startActivity(new Intent(HomeActivity.this, ChangePasswordActivity.class));

        } else if (id == R.id.nav_log_out) {

            FrameBigApp.getDefaultSharePreference().clearSharedPref(PrefsValues.LOGIN_ID);
            FrameBigApp.getDefaultSharePreference().clearSharedPref(PrefsValues.CUSTOMER_NAME);
            FrameBigApp.getDefaultSharePreference().clearSharedPref(PrefsValues.CUSTOMER_ID);
            FrameBigApp.getDefaultSharePreference().clearSharedPref(PrefsValues.CUSTOMER_PHONE);
            FrameBigApp.getDefaultSharePreference().clearSharedPref(PrefsValues.CUSTOMER_DELIVERY_ADDRESS);
            ApplicationData.CART_MODEL_LIST.clear();

            Intent signInActivityIntent = new Intent(HomeActivity.this, SignInActivity.class);
            startActivity(signInActivityIntent);
            this.finish();
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void goToAllProductActivity(boolean isOpenSearchView) {
        Intent productListIntent = new Intent(HomeActivity.this, RecentProductActivity.class);
        productListIntent.putExtra(ApplicationData.IS_OPEN_SEARCH_VIEW, isOpenSearchView);
        startActivity(productListIntent);
    }

    private void goToFacebookChat() {
        // To launch facebook app let urlString = "fb://page/your_fb_page_id"
        //        Uri uri = Uri.parse("fb://page/" + ApplicationData.geFacebookPageID());
        Uri uri = Uri.parse("fb-messenger://user/" + ApplicationData.geFacebookPageID());
        Intent toMessenger = new Intent(Intent.ACTION_VIEW, uri);
        try {
            startActivity(toMessenger);
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(homeActivity, "Please Install Messenger Apps", Toast.LENGTH_LONG).show();
        }
    }

    private void openPlayStore() {
        final String appPackageName = getPackageName();
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
        } catch (android.content.ActivityNotFoundException anfe) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
        }
    }

    private void init() {

        ApplicationData.PRODUCT_MODEL_LIST.clear();

        recyclerCategory = findViewById(R.id.recyclerview_category);
        recyclerCategory.setHasFixedSize(true);

        ItemOffsetDecoration itemDecoration = new ItemOffsetDecoration(this, R.dimen.sixteen_dp);
        recyclerCategory.addItemDecoration(itemDecoration);

        categoryAdapter.isSwitchView = false;
        recyclerCategory.setLayoutManager(new GridLayoutManager(this, 2));
        fab_grid.setVisibility(View.INVISIBLE);
        fab_list.setVisibility(View.VISIBLE);

        recyclerCategory.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), recyclerCategory,
                new RecyclerTouchListener.ClickListener() {
                    @Override
                    public void onClick(
                            View view,
                            int position) {
                        goToProductListActivity(position);
                    }

                    @Override
                    public void onLongClick(
                            View view,
                            int position) {

                    }
                }));

        recyclerCategory.setNestedScrollingEnabled(false);
        getProductCategory();
    }

    private void goToProductListActivity(int position) {
        Intent intent = new Intent(HomeActivity.this, ProductListActivity.class);
        intent.putExtra("categoryId", "" + productCategories.get(position).getId());
        intent.putExtra("categoryName", productCategories.get(position).getName());

        ApplicationData.SHARED_MODEL.setSelectedCategoryName(productCategories.get(position).getName());
        ApplicationData.SHARED_MODEL.setSelectedCategoryId("" + productCategories.get(position).getId());

        startActivity(intent);

    }

    private void goToCartActivity() {

        if (ApplicationData.CART_MODEL_LIST.size() > 0) {
            if (isUserLoggedIn() || prefsValues.getisGuestCustomer()) {
                Intent cartActivityIntent = new Intent(this, CartActivity.class);
                startActivity(cartActivityIntent);
            } else {
                AppUtils.customDialogTwoButtons(this, this, getString(R.string.checkout), getString(R.string.alert_login_as_guest_required_message)
                        , View.GONE, getString(R.string.log_in), getString(R.string.continue_as_guest), R.drawable.vector_info_alertdialog,
                        ApplicationData.TRACK_ALERT_LOGIN_AS_GUEST_REQUIRED);
            }
        } else {
            showToastMessage(getString(R.string.toast_empty_cart));
        }

    }

    private boolean isUserLoggedIn() {

        String loginId = prefsValues.getLoginId();
        if (loginId.isEmpty()) {
            return false;
        }
        return true;
    }

    private void setProductCategoryAdapter(List<ProductCategory> productCategories) {
        categoryAdapter = new ProductCategoryAdapter(productCategories);
        recyclerCategory.setAdapter(categoryAdapter);
        categoryAdapter.notifyDataSetChanged();
    }

    private void getProductCategory() {
        try {
            if (Connectivity.isConnected(homeActivity)) {

                showProgressDialog();

                ApiClient.getApiInterface().getProductCategory(ApplicationData.ACCESS_TOKEN,
                        ApplicationData.getCompanyID(),
                        ApplicationData.isTestDb()).enqueue(new Callback<ProductCategoryResponse>() {
                    @Override
                    public void onResponse(
                            Call<ProductCategoryResponse> call,
                            Response<ProductCategoryResponse> response) {
                        try {
                            if (response.isSuccessful()) {
                                ProductCategoryResponse productCategoryModel = response.body();

                                if (productCategoryModel.getData().size() > 0) {
                                    productCategories = productCategoryModel.getData();
                                    LogMe.i(TAG, "" + productCategories.size());
                                    setProductCategoryAdapter(productCategories);
                                } else {
                                    fab_grid.setVisibility(View.INVISIBLE);
                                    fab_list.setVisibility(View.INVISIBLE);
                                    showToastMessage("No Data Found!!");
                                }
                            } else {
                               // showToastMessage("" + productCategoryModel.getResponse_code());
                            }

                            hideProgressDialog();
                        } catch (Exception e) {
                            e.printStackTrace();
                            hideProgressDialog();
                        }
                    }

                    @Override
                    public void onFailure(
                            Call<ProductCategoryResponse> call,
                            Throwable t) {

                        hideProgressDialog();
                    }
                });

            } else {
                AppUtils.customDialogTwoButtons(this, this, getString(R.string.alert_no_internet_title),
                        getString(R.string.alert_no_interner_message), View.GONE, getString(R.string.alert_no_internet_exit),
                        getString(R.string.alert_no_internet_retry), R.drawable.vector_info_alertdialog, ApplicationData.TRACK_ALERT_NO_INTERNET);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onNegativeButtonClick(int trackingNumber) {
        switch (trackingNumber) {
            case ApplicationData.TRACK_ALERT_LOGIN_AS_GUEST_REQUIRED:
                Intent signInActivityIntent = new Intent(HomeActivity.this, SignInActivity.class);
                startActivity(signInActivityIntent);
                this.finish();
                break;
            case ApplicationData.TRACK_ALERT_NO_INTERNET:
                this.finishAffinity();
                break;
            default:
                break;
        }
    }

    @Override
    public void onPositiveButtonClick(int trackingNumber) {
        switch (trackingNumber) {
            case ApplicationData.TRACK_ALERT_NO_INTERNET:
                getProductCategory();
                break;
            case ApplicationData.TRACK_ALERT_LOGIN_AS_GUEST_REQUIRED:
                prefsValues.setCustomerId(0);
                prefsValues.setIsGuestCustomer(true);
                Intent cartActivityIntent = new Intent(this, CartActivity.class);
                startActivity(cartActivityIntent);
                this.finish();
                break;
            default:
                break;
        }
    }

    private void hideNavigationMenu(NavigationView navigationView) {

        String loginId = FrameBigApp.getDefaultSharePreference().getLoginId();

        Menu menu = navigationView.getMenu();
        MenuItem menuItem;

        if (loginId.isEmpty()) {

            menuItem = menu.findItem(R.id.nav_order_history);
            if (menuItem != null) {
                menuItem.setVisible(false);
            }

            menuItem = menu.findItem(R.id.nav_all_products);
            if (menuItem != null) {
                menuItem.setVisible(false);
            }
            menuItem = menu.findItem(R.id.nav_favorite);
            if (menuItem != null) {
                menuItem.setVisible(false);
            }

            menuItem = menu.findItem(R.id.nav_chat_with_us);
            if (menuItem != null) {
                menuItem.setVisible(false);
            }

            menuItem = menu.findItem(R.id.nav_change_password);
            if (menuItem != null) {
                menuItem.setVisible(false);
            }

            menuItem = menu.findItem(R.id.nav_log_out);
            if (menuItem != null) {
                menuItem.setVisible(false);
            }

            menuItem = menu.findItem(R.id.nav_update_profile);
        } else {

            menuItem = menu.findItem(R.id.nav_register);
            if (menuItem != null) {
                menuItem.setVisible(false);
            }

            menuItem = menu.findItem(R.id.nav_log_in);

        }
        if (menuItem != null) {
            menuItem.setVisible(false);
        }
    }

    @Override
    protected void onResume() {

        LogMe.i(TAG, "onResume called");

        runOnUiThread(() -> {
            int count = ApplicationData.CART_MODEL_LIST.size();
            LogMe.i(TAG, "COUNT: " + count);
            if (txtViewCount != null) {
                if (count == 0) txtViewCount.setVisibility(View.GONE);
                else {
                    txtViewCount.setVisibility(View.VISIBLE);
                    txtViewCount.setText("" + count);
                    // supportInvalidateOptionsMenu();
                }
            }
        });

        if (prefsValues.getisGuestCustomer()) {
            textViewCustomerName.setText("Welcome as Guest Customer !!");
        }
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private void getSettings() {
        try {
            if (Connectivity.isConnected(homeActivity)) {
                showProgressDialog();
                ApiClient.getApiInterface().getSettings(
                        ApplicationData.getCompanyID(),
                        ApplicationData.ACCESS_TOKEN,
                        ApplicationData.isTestDb()).enqueue(new Callback<SettingsModel>() {

                    @Override
                    public void onResponse(
                            Call<SettingsModel> call,
                            Response<SettingsModel> response) {
                        if (response.body().getResponseCode() == 200) {
                            SettingsModel settingsModel = response.body();
                            ApplicationData.SETTINGS_RESPONSE = settingsModel.getResponse();
                            hideProgressDialog();
                        }
                    }

                    @Override
                    public void onFailure(
                            Call<SettingsModel> call,
                            Throwable t) {

                    }
                });
            } else {
                AppUtils.customDialogTwoButtons(this, this, getString(R.string.alert_no_internet_title),
                        getString(R.string.alert_no_interner_message), View.GONE, getString(R.string.alert_no_internet_exit),
                        getString(R.string.alert_no_internet_retry), R.drawable.vector_info_alertdialog, ApplicationData.TRACK_ALERT_NO_INTERNET);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}