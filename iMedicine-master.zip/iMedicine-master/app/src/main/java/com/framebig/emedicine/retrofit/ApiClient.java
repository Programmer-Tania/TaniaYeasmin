package com.framebig.emedicine.retrofit;

import com.framebig.emedicine.utility.ApplicationData;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;

import com.facebook.stetho.okhttp3.StethoInterceptor;

import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient
{

    private static Retrofit retrofit = null;
    private static ApiInterface apiInterface = null;
    private static ApiInterface apiInterfaceFacebook;
    private static Retrofit retrofitForFacebook = null;

    public static Retrofit getClient()
    {

        final OkHttpClient okHttpClient = new OkHttpClient.Builder().readTimeout(60, TimeUnit.SECONDS).connectTimeout(60, TimeUnit.SECONDS).build();

        if (retrofit == null)
        {
            retrofit =
                    new Retrofit.Builder().baseUrl(ApplicationData.getApiBaseUrl()).addConverterFactory(GsonConverterFactory.create()).client(okHttpClient).build();
        }
        return retrofit;
    }

    public static ApiInterface getApiInterface()
    {

        if (apiInterface == null)
        {
            retrofit =
                    new Retrofit.Builder().baseUrl(ApplicationData.getApiBaseUrl()).addConverterFactory(GsonConverterFactory.create()).client(getOkHttpClient(getHttpLoggingInterceptor())).build();

            apiInterface = retrofit.create(ApiInterface.class);
        }
        return apiInterface;
    }

    private static HttpLoggingInterceptor getHttpLoggingInterceptor()
    {
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        // set your desired log level
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);
        return logging;
    }

    private static OkHttpClient getOkHttpClient(HttpLoggingInterceptor logging)
    {
        return new OkHttpClient.Builder().readTimeout(120, TimeUnit.SECONDS).
                writeTimeout(120, TimeUnit.SECONDS).connectTimeout(120, TimeUnit.SECONDS).addInterceptor(logging).addNetworkInterceptor(new StethoInterceptor()).build();
    }

    public static ApiInterface getRxClient()
    {
        if (apiInterface == null)
        {
            retrofit =
                    new Retrofit.Builder().baseUrl(ApplicationData.getApiBaseUrl()).addCallAdapterFactory(RxJava2CallAdapterFactory.create()).addConverterFactory(GsonConverterFactory.create()).build();

            apiInterface = retrofit.create(ApiInterface.class);

        }
        return apiInterface;
    }

    public static ApiInterface getApiClientForFaceBook()
    {
        if (apiInterfaceFacebook == null)
        {
            retrofitForFacebook =
                    new Retrofit.Builder().baseUrl(ApplicationData.FACEBOOK_FINAL_URL).addConverterFactory(GsonConverterFactory.create()).build();

            apiInterfaceFacebook = retrofitForFacebook.create(ApiInterface.class);
        }
        return apiInterfaceFacebook;
    }

}