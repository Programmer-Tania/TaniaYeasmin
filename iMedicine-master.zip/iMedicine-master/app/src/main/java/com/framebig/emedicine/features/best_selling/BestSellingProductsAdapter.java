package com.framebig.emedicine.features.best_selling;

import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.framebig.emedicine.R;
import com.framebig.emedicine.features.model.ProductModel;
import com.framebig.emedicine.utility.ApplicationData;
import com.framebig.emedicine.utility.CustomerType;
import com.framebig.emedicine.utility.FrameBigApp;
import com.framebig.emedicine.utility.PrefsValues;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by Shihab on 1/28/2016.
 */
public class BestSellingProductsAdapter extends RecyclerView.Adapter<BestSellingProductsAdapter.MyViewHolder> implements Filterable
{

    private ArrayList<ProductModel> productModelList;
    private ArrayList<ProductModel> productModelListFilteredList;
    private RecyclerCustomItemClickListener listener;
    private boolean isRetailCustomer;
    private static final int LIST_ITEM = 0;
    public static final int GRID_ITEM = 1;
    public static boolean isSwitchView;

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener
    {

        private TextView productName, productPrice, productDiscountedPrice, productPrevPrice;
        private ImageView productImage, discountTagImage;

        public MyViewHolder(View view)
        {
            super(view);
            this.productImage = view.findViewById(R.id.product_imageView);
            this.discountTagImage = view.findViewById(R.id.product_discount_tag);

            this.productName = view.findViewById(R.id.product_Name);
            this.productPrice = view.findViewById(R.id.product_price);
            this.productDiscountedPrice = view.findViewById(R.id.product_discounted_price);
            this.productPrevPrice = view.findViewById(R.id.product_prev_price);
            view.setOnClickListener(this);
        }

        @Override
        public void onClick(View v)
        {
            listener.getItem(productModelListFilteredList.get(getAdapterPosition()));
        }
    }

    public void setProductModelList(ArrayList<ProductModel> productModelList)
    {
        this.productModelList = productModelList;
        notifyDataSetChanged();
    }

    public BestSellingProductsAdapter(
            ArrayList<ProductModel> product_list,
            RecyclerCustomItemClickListener listener)
    {
        this.productModelList = product_list;
        this.productModelListFilteredList = product_list;
        this.listener = listener;
        isRetailCustomer =
                FrameBigApp.getDefaultSharePreference().getStringWithDefault(PrefsValues.CUSTOMER_TYPE, CustomerType.retail.toString()).equalsIgnoreCase(CustomerType.retail.toString());
    }

    @Override
    public MyViewHolder onCreateViewHolder(
            ViewGroup parent,
            int viewType)
    {
        View itemView;
        if (viewType == LIST_ITEM)
        {
            itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product_list, null);
        }
        else
        {
            itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product_cardview, null);
        }
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(
            MyViewHolder holder,
            int position)
    {

        try
        {
            ProductModel productModel = productModelListFilteredList.get(position);
            holder.productName.setText(productModel.getProductName());
            double discountedPrice = Double.parseDouble(productModel.getDiscountedPrice());

            if (isRetailCustomer)
            {
                if (discountedPrice > 0.0)
                {
                    holder.productPrice.setVisibility(View.GONE);
                    holder.productPrevPrice.setVisibility(View.VISIBLE);
                    holder.productDiscountedPrice.setVisibility(View.VISIBLE);
                    holder.discountTagImage.setVisibility(View.VISIBLE);
                    holder.productDiscountedPrice.setText(ApplicationData.SETTINGS_RESPONSE.getCurrencySymbol() + " " + productModel.getDiscountedPrice());
                    holder.productPrevPrice.setText(ApplicationData.SETTINGS_RESPONSE.getCurrencySymbol() + " " + productModel.getMaxRetailCost());
                    holder.productPrevPrice.setPaintFlags(holder.productPrevPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                }
                else
                {
                    holder.productPrice.setVisibility(View.VISIBLE);
                    holder.discountTagImage.setVisibility(View.GONE);
                    holder.productPrevPrice.setVisibility(View.GONE);
                    holder.productDiscountedPrice.setVisibility(View.GONE);
                    holder.productPrice.setText(ApplicationData.SETTINGS_RESPONSE.getCurrencySymbol() + " " + productModel.getMaxRetailCost());
                }
            }
            else
            {
                if (discountedPrice > 0.0)
                {
                    holder.productPrice.setVisibility(View.GONE);
                    holder.productDiscountedPrice.setText(ApplicationData.SETTINGS_RESPONSE.getCurrencySymbol() + " " + productModel.getDiscountedPrice());
                    holder.productDiscountedPrice.setVisibility(View.VISIBLE);
                    holder.productPrevPrice.setText(ApplicationData.SETTINGS_RESPONSE.getCurrencySymbol() + " " + productModel.getMaxWholeSaleCost());
                    holder.productPrevPrice.setPaintFlags(holder.productPrevPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                    holder.productPrevPrice.setVisibility(View.VISIBLE);
                    holder.discountTagImage.setVisibility(View.VISIBLE);
                }
                else
                {
                    holder.productPrice.setText(ApplicationData.SETTINGS_RESPONSE.getCurrencySymbol() + " " + productModel.getMaxWholeSaleCost() +
                            " ");
                    holder.discountTagImage.setVisibility(View.GONE);
                }
            }

            String image = productModel.getImageList().get(0);
            Picasso.get().load(image).error(R.drawable.image_not_found).placeholder(R.drawable.image_not_found).resize(350, 350).into(holder.productImage);

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemViewType(int position)
    {
        if (isSwitchView)
        {
            return LIST_ITEM;
        }
        else
        {
            return GRID_ITEM;
        }
    }

    public boolean toggleItemViewType()
    {
        isSwitchView = !isSwitchView;
        return isSwitchView;
    }

    @Override
    public int getItemCount()
    {
        return productModelListFilteredList.size();
    }

    @Override
    public Filter getFilter()
    {
        return exampleFilter;
    }

    private Filter exampleFilter = new Filter()
    {
        @Override
        protected FilterResults performFiltering(CharSequence constraint)
        {

            String filterPattern = constraint.toString();

            if (filterPattern.isEmpty())
            {
                productModelListFilteredList = productModelList;
            }
            else
            {

                ArrayList<ProductModel> filteredList = new ArrayList<>();
                for (ProductModel serviceSubCategory : productModelList)
                {
                    if (serviceSubCategory.getProductName().toLowerCase().contains(filterPattern))
                    {
                        filteredList.add(serviceSubCategory);
                    }
                }
                productModelListFilteredList = filteredList;
            }

            FilterResults results = new FilterResults();
            results.values = productModelListFilteredList;
            return results;
        }

        @Override
        protected void publishResults(
                CharSequence constraint,
                FilterResults results)
        {
            productModelListFilteredList = (ArrayList<ProductModel>) results.values;
            notifyDataSetChanged();
        }

    };

    public interface RecyclerCustomItemClickListener
    {
        void onRowSelected(int position);

        void getItem(ProductModel productModel);
    }
}
