package com.framebig.emedicine.features.order_history;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.MutableLiveData;

import com.framebig.emedicine.R;
import com.framebig.emedicine.databinding.ActivityOrderListBinding;
import com.framebig.emedicine.features.BaseActivity;
import com.framebig.emedicine.features.model.OrderListModel;
import com.framebig.emedicine.retrofit.ApiClient;
import com.framebig.emedicine.utility.ApplicationData;
import com.framebig.emedicine.utility.Connectivity;
import com.framebig.emedicine.utility.FrameBigApp;
import com.framebig.emedicine.utility.PrefsValues;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OrderHistoryListActivity extends BaseActivity implements OrderListAdapter.RecyclerCustomItemClickListener
{

    private ArrayList<OrderListModel> orderList;
    private PrefsValues prefsValues;
    private ActivityOrderListBinding binding;
    private OrderListAdapter orderListAdapter;
    MutableLiveData<OrderListModel> liveData = new MutableLiveData<>();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_order_list);
        setSupportActionBar(binding.toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(R.string.order_history);
        prefsValues = FrameBigApp.getDefaultSharePreference();
        showOrders();
    }

    private void setOrderAdapter(ArrayList<OrderListModel> orderList)
    {
        orderListAdapter = new OrderListAdapter(this, orderList, this);
        binding.contentLayout.listViewOrderListContent.setAdapter(orderListAdapter);
        orderListAdapter.notifyDataSetChanged();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        if (item.getItemId() == android.R.id.home)
        {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showOrders()
    {
        try
        {
            if (Connectivity.isConnected(OrderHistoryListActivity.this))
            {
                showProgressDialog();
                ApiClient.getApiInterface().getOrders(ApplicationData.ACCESS_TOKEN,
                        ApplicationData.SESSION_ID,
                        ApplicationData.getCompanyID(),
                        prefsValues.getCustomerId(),
                        ApplicationData.isTestDb()).enqueue(new Callback<OrderListModel>()
                {
                    @Override
                    public void onResponse(
                            Call<OrderListModel> call,
                            Response<OrderListModel> response)
                    {
                        hideProgressDialog();
                        OrderListModel orderListModel = response.body();
                        if (orderListModel != null)
                        {
                            if (orderListModel.getResponse_code() == 200 && orderListModel.getOrderList().size() > 0)
                            {
                                orderList = orderListModel.getOrderList();
                                setOrderAdapter(orderList);
                            }
                            else
                            {
                                binding.contentLayout.textViewEmptyCart.setVisibility(View.VISIBLE);
                            }
                        }
                    }

                    @Override
                    public void onFailure(
                            Call<OrderListModel> call,
                            Throwable t)
                    {
                        hideProgressDialog();
                        showToastMessage("" + t.getLocalizedMessage());
                    }
                });
            }
            else
            {
                showToastMessage("No Internet Connection");
            }
        }
        catch (Exception e)
        {
            showToastMessage("" + e.getLocalizedMessage());
            e.printStackTrace();
        }
    }

    @Override
    public void onRowSelected(OrderListModel orderDetail)
    {
        Intent intent = new Intent(this, OrderDetailsHistoryActivity.class);
        intent.putExtra("orderNo", orderDetail.getOrderNo());
        intent.putExtra("totalPrice", orderDetail.getTotalOrderValue());
        startActivity(intent);
    }
}