package com.framebig.emedicine.features.favourite;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.framebig.emedicine.R;
import com.framebig.emedicine.features.BaseActivity;
import com.framebig.emedicine.features.model.FavouriteResponse;
import com.framebig.emedicine.features.model.ProductModel;
import com.framebig.emedicine.features.product_details.ProductDetailsActivity;
import com.framebig.emedicine.retrofit.ApiClient;
import com.framebig.emedicine.utility.AlertDialogTwoButton;
import com.framebig.emedicine.utility.AppUtils;
import com.framebig.emedicine.utility.ApplicationData;
import com.framebig.emedicine.utility.Connectivity;
import com.framebig.emedicine.utility.FrameBigApp;
import com.framebig.emedicine.utility.MyDividerItemDecoration;
import com.framebig.emedicine.utility.PrefsValues;
import com.google.gson.Gson;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.framebig.emedicine.utility.ApplicationData.SESSION_ID;

public class FavouriteProductActivity extends BaseActivity implements AlertDialogTwoButton.ButtonClickListener
{
    private FavouriteProductAdapter favouriteProductAdapter;
    private RecyclerView recyclerview_fav_product;
    private FavouriteProductActivity favouriteProductActivity;
    private String TAG = FavouriteProductActivity.class.getSimpleName();
    private TextView textView_emptyCart;
    private PrefsValues prefsValues;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourite_product);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        favouriteProductActivity = this;
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        recyclerview_fav_product = findViewById(R.id.recyclerview_fav_product);
        textView_emptyCart = findViewById(R.id.textView_emptyCart);
        recyclerview_fav_product.setLayoutManager(new LinearLayoutManager(this));
        recyclerview_fav_product.addItemDecoration(new MyDividerItemDecoration(this, DividerItemDecoration.VERTICAL, 16));

        prefsValues = FrameBigApp.getDefaultSharePreference();

        getFavouriteProducts();
    }

    private void getFavouriteProducts()
    {
        try
        {
            if (Connectivity.isConnected(this))
            {

                showProgressDialog();
                ApiClient.getApiInterface().getFavoriteProduct(
                        ApplicationData.ACCESS_TOKEN, SESSION_ID,
                        String.valueOf(prefsValues.getCustomerId()),
                        ApplicationData.getCompanyID(),
                        ApplicationData.isTestDb()
                ).enqueue(new Callback<GetFavouriteResponse>()
                {
                    @Override
                    public void onResponse(
                            Call<GetFavouriteResponse> call,
                            Response<GetFavouriteResponse> response)
                    {
                        try
                        {
                            hideProgressDialog();
                            GetFavouriteResponse productResponse = response.body();
                            if (productResponse.getResponse_code() == ApplicationData.SUCCESS_RESPONSE_CODE)
                            {

                                ApplicationData.FAVOURITE_PRODUCT_MODEL_LIST = productResponse.getProductModelArrayList();
                                favouriteProductAdapter = new FavouriteProductAdapter(
                                        ApplicationData.FAVOURITE_PRODUCT_MODEL_LIST,
                                        new ClickListener()
                                        {
                                            @Override
                                            public void onPositionClicked(int position)
                                            {
                                                //showToastMessage("delete clicked..." + position);

                                                AppUtils.customDialogTwoButtons(favouriteProductActivity, favouriteProductActivity,
                                                        getString(R.string.alert_favourite_product_item_title),
                                                        getString(R.string.alert_favourite_product_message), View.GONE,
                                                        getString(R.string.alert_cancel_button), getString(R.string.alert_yes_button),
                                                        R.drawable.vector_info_alertdialog, position
                                                );
                                            }

                                            @Override
                                            public void onCellClicked(int position)
                                            {
                                                //showToastMessage("onCellClicked ..." + position);
                                                goToProductDetailsUI(position);
                                            }
                                        }
                                );
                                recyclerview_fav_product.setAdapter(favouriteProductAdapter);
                                if (ApplicationData.FAVOURITE_PRODUCT_MODEL_LIST.size() < 1)
                                {
                                    textView_emptyCart.setVisibility(View.VISIBLE);
                                }
                            }
                            else
                            {
                                showToastMessage("Status :" + productResponse.getStatus());
                                textView_emptyCart.setVisibility(View.VISIBLE);
                            }
                        }
                        catch (Exception e)
                        {
                            e.printStackTrace();
                        }

                    }

                    @Override
                    public void onFailure(
                            Call<GetFavouriteResponse> call,
                            Throwable t)
                    {
                        hideProgressDialog();
                    }
                });

            }
            else
            {
                showToastMessage("No Internet Connection");
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    private void goToProductDetailsUI(int position)
    {
        Intent intent = new Intent(favouriteProductActivity, ProductDetailsActivity.class);
        Gson gson = new Gson();

        String object = gson.toJson(ApplicationData.FAVOURITE_PRODUCT_MODEL_LIST.get(position));
        intent.putExtra(ApplicationData.PRODUCT_OBJECT, object);
        intent.putExtra(ApplicationData.IS_A_FAVOURITE_PRODUCT, true);
        ApplicationData.SHARED_MODEL.setSelectedProductId(String.valueOf(ApplicationData.FAVOURITE_PRODUCT_MODEL_LIST.get(position).getProductId()));
        startActivity(intent);
    }

    @Override
    public void onNegativeButtonClick(int trackingNumber)
    {
    }

    @Override
    public void onPositiveButtonClick(int position)
    {
        ProductModel productModel = ApplicationData.FAVOURITE_PRODUCT_MODEL_LIST.get(position);
        deleteFavouriteProduct(productModel.getProductId(), position);
    }

    private void deleteFavouriteProduct(
            int ProductId,
            final int position)
    {

        try
        {
            if (Connectivity.isConnected(this))
            {

                showProgressDialog();

                ApiClient.getApiInterface().deleteFavoriteProduct(ApplicationData.ACCESS_TOKEN, "" + prefsValues.getCustomerId(), "" + ProductId,
                        ApplicationData.isTestDb()
                ).enqueue(new Callback<FavouriteResponse>()
                {
                    @Override
                    public void onResponse(
                            Call<FavouriteResponse> call,
                            Response<FavouriteResponse> response)
                    {

                        hideProgressDialog();
                        //LogMe.i(TAG, "" + response.body().toString());
                        FavouriteResponse productResponse = response.body();
                        if (productResponse.getResponse_code() == ApplicationData.SUCCESS_RESPONSE_CODE)
                        {

                            ApplicationData.FAVOURITE_PRODUCT_MODEL_LIST.remove(position);
                            favouriteProductAdapter.notifyDataSetChanged();
                            showToastMessage("Successfully Deleted");
                            if (ApplicationData.FAVOURITE_PRODUCT_MODEL_LIST.size() < 1)
                            {
                                textView_emptyCart.setVisibility(View.VISIBLE);
                            }

                        }
                        else
                        {
                            showToastMessage("Status: " + productResponse.getStatus());
                        }
                    }

                    @Override
                    public void onFailure(
                            Call<FavouriteResponse> call,
                            Throwable t)
                    {
                        hideProgressDialog();
                    }
                });

            }
            else
            {
                showToastMessage("No Internet Connection");
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

}