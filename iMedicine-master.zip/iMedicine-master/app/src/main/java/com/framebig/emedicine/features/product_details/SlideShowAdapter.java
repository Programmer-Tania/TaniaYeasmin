package com.framebig.emedicine.features.product_details;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.bumptech.glide.Glide;
import com.framebig.emedicine.R;
import com.github.chrisbanes.photoview.PhotoView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import java.util.List;

public class SlideShowAdapter extends PagerAdapter
{

    private Context context;
    private List<String> imageURLs;
    LayoutInflater inflater;

    public SlideShowAdapter(
            Context context,
            List<String> imageURLs)
    {
        this.context = context;
        this.imageURLs = imageURLs;
    }

    @Override
    public int getCount()
    {
        return imageURLs.size();
    }

    @Override
    public boolean isViewFromObject(
            @NonNull View view,
            @NonNull Object o)
    {
        return (view == (LinearLayout) o);
    }

    public SlideShowAdapter()
    {
        super();
    }

    @NonNull
    @Override
    public Object instantiateItem(
            @NonNull ViewGroup container,
            int position)
    {
        inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.slideshow_layout, container, false);
        PhotoView photoView = (PhotoView) view.findViewById(R.id.imageView_id);
        Glide.with(context).load(imageURLs.get(position)).into(photoView);
        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem(
            @NonNull ViewGroup container,
            int position,
            @NonNull Object object)
    {
        container.removeView((LinearLayout) object);
    }
}
