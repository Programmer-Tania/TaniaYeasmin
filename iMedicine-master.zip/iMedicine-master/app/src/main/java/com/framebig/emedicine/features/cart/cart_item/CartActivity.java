package com.framebig.emedicine.features.cart.cart_item;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.framebig.emedicine.R;
import com.framebig.emedicine.databinding.ActivityCartBinding;
import com.framebig.emedicine.features.BaseActivity;
import com.framebig.emedicine.features.cart.delivery_information.DeliveryInformationActivity;
import com.framebig.emedicine.features.cart.delivery_information.PaymentAPIResponse;
import com.framebig.emedicine.features.model.CartModel;
import com.framebig.emedicine.retrofit.ApiClient;
import com.framebig.emedicine.utility.AlertDialogTwoButton;
import com.framebig.emedicine.utility.AppUtils;
import com.framebig.emedicine.utility.ApplicationData;
import com.framebig.emedicine.utility.Connectivity;
import com.framebig.emedicine.utility.MyDividerItemDecoration;
import com.framebig.emedicine.utility.SwipeToDeleteCallback;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CartActivity extends BaseActivity implements CartContract, AlertDialogTwoButton.ButtonClickListener
{

    private ActivityCartBinding binding;
    private CartModel cartModelForDelete;
    private int cartModelPosition;
    private CartRecyclerAdapter recyclerAdapter;
    private String currencySymbol = ApplicationData.SETTINGS_RESPONSE.getCurrencySymbol();
    private double deliveryCharge = Double.parseDouble(ApplicationData.SETTINGS_RESPONSE.getDeliveryCharge());

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_cart);
        setSupportActionBar(binding.toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(R.string.cart_item);

        showCartItem();

        binding.content.txtDeliveryFeeAmount.setText(currencySymbol + " " + deliveryCharge);
        binding.content.textViewCartCurrency.setText("" + currencySymbol);
        getPaymentMethods();

        //enableSwipeToDeleteAndUndo();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.menu_next, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.menuItem_next:
                if (ApplicationData.CART_MODEL_LIST.size() < 1)
                {
                    showToastMessage(getString(R.string.toast_empty_cart));
                }
                else
                {
                    Intent deliveryInfoIntent = new Intent(this, DeliveryInformationActivity.class);
                    startActivity(deliveryInfoIntent);
                }
                break;
            case android.R.id.home:
                onBackPressed();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void decreaseAmount(
            CartModel cartModel,
            int position)
    {
        double existingAmount = ApplicationData.CART_MODEL_LIST.get(position).getSalesAmount();
        ApplicationData.CART_MODEL_LIST.get(position).setSalesAmount(existingAmount - 1);
        showTotalBill();
    }

    @Override
    public void increaseAmount(
            CartModel cartModel,
            int position)
    {
        double existingAmount = ApplicationData.CART_MODEL_LIST.get(position).getSalesAmount();
        double currentStock = ApplicationData.CART_MODEL_LIST.get(position).getCurrentStock();
        if (existingAmount + 1 > currentStock && ApplicationData.SETTINGS_RESPONSE.isStockRestriction())
        {
            showToastMessage("You can order maximum " + currentStock + " " + ApplicationData.CART_MODEL_LIST.get(position).getUnitName());
            return;
        }
        ApplicationData.CART_MODEL_LIST.get(position).setSalesAmount(existingAmount + 1);
        showTotalBill();
    }

    @Override
    public void deleteCartItem(CartModel cartModel)
    {
        cartModelForDelete = cartModel;
        AppUtils.customDialogTwoButtons(CartActivity.this, CartActivity.this, getString(R.string.alert_delete_cart_item_title),
                getString(R.string.alert_delete_cart_item_message), View.GONE, getString(R.string.alert_cancel_button),
                getString(R.string.alert_yes_button), R.drawable.vector_info_alertdialog, ApplicationData.TRACK_ALERT_DELETE_ITEM);
    }

    @Override
    public void onPositiveButtonClick(int trackingNumber)
    {
        ApplicationData.CART_MODEL_LIST.remove(cartModelForDelete);
        showTotalBill();
        if (ApplicationData.CART_MODEL_LIST.size() < 1)
        {
            binding.content.textViewEmptyCart.setVisibility(View.VISIBLE);
            binding.content.textViewTotalBill.setText("0");
        }
    }

    @Override
    public void onNegativeButtonClick(int trackingNumber)
    {
        //ApplicationData.CART_MODEL_LIST.add(cartModelPosition, cartModelForDelete);
        showTotalBill();
        binding.content.recyclerViewCartContent.scrollToPosition(cartModelPosition);
    }

    private void showTotalBill()
    {

        double totalBill = 0.00;

        for (CartModel cartModel : ApplicationData.CART_MODEL_LIST)
        {
            totalBill = totalBill + (cartModel.getSalesAmount() * cartModel.getUnitSellingPrice());
        }

        double bill_with_delivery_free = totalBill + deliveryCharge;
        binding.content.textViewTotalBill.setText(Double.toString(bill_with_delivery_free));
        binding.content.txtSubTotalAmount.setText(currencySymbol + " " + totalBill);

        recyclerAdapter.notifyDataSetChanged();
    }

    private void showCartItem()
    {

        if (ApplicationData.CART_MODEL_LIST.size() > 0)
        {
            recyclerAdapter = new CartRecyclerAdapter(this, ApplicationData.CART_MODEL_LIST);

            binding.content.recyclerViewCartContent.setLayoutManager(new LinearLayoutManager(this));
            binding.content.recyclerViewCartContent.addItemDecoration(new MyDividerItemDecoration(this, DividerItemDecoration.VERTICAL, 8));
            binding.content.recyclerViewCartContent.setAdapter(recyclerAdapter);
            showTotalBill();
        }
        else
        {
            showToastMessage(getString(R.string.toast_something_went_wrong));
        }
    }

    private void enableSwipeToDeleteAndUndo()
    {
        SwipeToDeleteCallback swipeToDeleteCallback = new SwipeToDeleteCallback(this)
        {
            @Override
            public void onSwiped(
                    @NonNull RecyclerView.ViewHolder viewHolder,
                    int position)
            {

                cartModelPosition = position;
                cartModelForDelete = ApplicationData.CART_MODEL_LIST.get(cartModelPosition);
                AppUtils.customDialogTwoButtons(CartActivity.this, CartActivity.this, getString(R.string.alert_delete_cart_item_title),
                        getString(R.string.alert_delete_cart_item_message), View.GONE, getString(R.string.alert_cancel_button),
                        getString(R.string.alert_yes_button), R.drawable.vector_info_alertdialog, ApplicationData.TRACK_ALERT_DELETE_ITEM);
            }
        };

        ItemTouchHelper itemTouchhelper = new ItemTouchHelper(swipeToDeleteCallback);
        itemTouchhelper.attachToRecyclerView(binding.content.recyclerViewCartContent);
    }

    private void getPaymentMethods()
    {
        try
        {
            if (Connectivity.isConnected(this))
            {
                ApiClient.getApiInterface().getPaymentMethods(ApplicationData.getCompanyID(), ApplicationData.ACCESS_TOKEN, ApplicationData.isTestDb()).enqueue(new Callback<PaymentAPIResponse>()
                {
                    @Override
                    public void onResponse(
                            Call<PaymentAPIResponse> call,
                            Response<PaymentAPIResponse> response)
                    {
                        try
                        {
                            ApplicationData.PAYMENT_RESPONSE = response.body();
                            ApplicationData.paymentMethods.clear();
                            for (int i = 0; i < ApplicationData.PAYMENT_RESPONSE.getResponse().size(); i++)
                            {
                                ApplicationData.paymentMethods.add(ApplicationData.PAYMENT_RESPONSE.getResponse().get(i).getPaymentMethodName());
                            }
                        }
                        catch (Exception e)
                        {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onFailure(
                            Call<PaymentAPIResponse> call,
                            Throwable t)
                    {
                    }
                });
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}