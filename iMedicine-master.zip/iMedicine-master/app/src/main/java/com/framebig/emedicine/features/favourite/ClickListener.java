package com.framebig.emedicine.features.favourite;

public interface ClickListener
{
    void onPositionClicked(int position);

    void onCellClicked(int position);
    //void onCellClicked(int position);
}
