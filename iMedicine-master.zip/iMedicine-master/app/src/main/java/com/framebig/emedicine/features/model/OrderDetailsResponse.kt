package com.framebig.emedicine.features.model

import com.google.gson.annotations.SerializedName

data class OrderDetailsResponse(
        @SerializedName("response_code")
        var responseCode: Int = 0,

        @SerializedName("response")
        var response: OrderHistoryResponse? = null,

        @SerializedName("status")
        var status: String? = ""
)