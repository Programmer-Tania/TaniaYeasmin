package com.framebig.emedicine.features.cart.delivery_information;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

import com.framebig.emedicine.R;
import com.framebig.emedicine.databinding.FragmentDelivaryBinding;
import com.framebig.emedicine.features.cart.order_confirmation.OrderConfirmationActivity;
import com.framebig.emedicine.features.model.CartModel;
import com.framebig.emedicine.features.model.PlaceOrderResponseModel;
import com.framebig.emedicine.retrofit.ApiClient;
import com.framebig.emedicine.utility.AlertDialogOneButton;
import com.framebig.emedicine.utility.AppUtils;
import com.framebig.emedicine.utility.ApplicationData;
import com.framebig.emedicine.utility.Connectivity;
import com.framebig.emedicine.utility.DatePickerListener;
import com.framebig.emedicine.utility.FrameBigApp;
import com.framebig.emedicine.utility.LogMe;
import com.framebig.emedicine.utility.PrefsValues;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DelivaryFragment extends Fragment implements AlertDialogOneButton.OnOkButtonClickListener, DeliveryInformationActivity.OnSendMessage,
        View.OnClickListener {

    private FragmentDelivaryBinding binding;
    private String TAG = DeliveryInformationActivity.class.getName();
    private PrefsValues prefsValues;
    private double totalBill = 0.00;
    private double totalVat = 0.00;
    private String shippingMethod = "Normal";
    private DatePickerListener datePickerListener = new DatePickerListener();
    private Spinner spin;

    public DelivaryFragment() {
    }

    public static DelivaryFragment newInstance() {
        DelivaryFragment fragment = new DelivaryFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public View onCreateView(
            LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState) {

        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_delivary, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(
            @NonNull View view,
            @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        datePickerListener = AppUtils.getInitialDateInPicker();
        prefsValues = FrameBigApp.getDefaultSharePreference();
        setHasOptionsMenu(true);

        ((DeliveryInformationActivity) getActivity()).updateAddress(this);
        spin = (Spinner) binding.spinnerPaymentMethod;

        setDataInPaymentSpinner();
        showTotalBill();
        setDataInEditText();
        setCurrency();
        binding.radioButtonExpressShipping.setOnClickListener(this);
        binding.radioButtonNormalShipping.setOnClickListener(this);
        binding.btnChangeDeliveryAddress.setOnClickListener(this);
        binding.imgViewExpectedDeliveryDate.setOnClickListener(this);
        //binding.textViewPaymentDetails.setText("Bkash Payment Number : "+ApplicationData.SETTINGS_RESPONSE.getBkashNumber());
    }

    @Override
    public void onClick(View view) {

        if (view == binding.radioButtonExpressShipping) {
            showExpressDeliveryMessage();
        } else if (view == binding.radioButtonNormalShipping) {
            showNormalDeliveryMessage();
        } else if (view == binding.btnChangeDeliveryAddress) {
            changeDelivaryAddress();
        } else if (view == binding.imgViewExpectedDeliveryDate) {
            openDateDatePicker();
        }
    }

    private void setCurrency() {
        binding.textViewCurrency.setText(getActivity().getString(R.string.currency_name));
    }

    @Override
    public void onResume() {
        super.onResume();
        setDataInEditText();
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    private void setDataInEditText() {
        binding.txtCustomerName.setText("Customer Name : " + prefsValues.getCustomerName());
        binding.txtMobile.setText("Mobile No : " + prefsValues.getCustomerPhone());
        binding.txtDeliveryAddress.setText("Delivery Address : " + prefsValues.getCustomerDeliveryAddress());
    }

    public void changeDelivaryAddress() {
        ((DeliveryInformationActivity) getActivity()).
                replaceFragment(R.id.fragment_place, ChangeAddressFragment.newInstance());
    }

    public void openDateDatePicker() {
        DatePickerDialog d = new DatePickerDialog(getActivity(), trnDatePickerListener, datePickerListener.getYear(), datePickerListener.getMonth()
                , datePickerListener.getDay());

        d.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
        d.show();
    }

    public void setPaymentDescription(int position) {
        binding.textViewPaymentDetails.setText(ApplicationData.PAYMENT_RESPONSE.getResponse().get(position).getDetails());
    }

    public void showNormalDeliveryMessage() {
        binding.textViewShippingMethodDescription.setText(R.string.normal_shipping_description);
        shippingMethod = "Normal";
    }

    private void setDataInPaymentSpinner() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, ApplicationData.paymentMethods);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(adapter);
        spin.setSelection(0);
        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(
                    AdapterView<?> parent,
                    View view,
                    int position,
                    long id) {
                setPaymentDescription(position);
                spin.setSelection(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void showTotalBill() {

        totalBill = 0.00;
        for (CartModel cartModel : ApplicationData.CART_MODEL_LIST) {
            totalBill = totalBill + (cartModel.getSalesAmount() * cartModel.getUnitSellingPrice());
        }

        double totalBillWithDelivery = totalBill + Double.parseDouble(ApplicationData.SETTINGS_RESPONSE.getDeliveryCharge());
        binding.tvTotalBill.setText(Double.toString(totalBillWithDelivery));

    }

    private void placeOrder() {

        try {
            if (!isCheckFieldValue()) {
                if (Connectivity.isConnected(getActivity())) {

                    ((DeliveryInformationActivity) getActivity()).showProgressDialog();

                    ApiClient.getApiInterface().placeOrder(ApplicationData.ACCESS_TOKEN,
                            ApplicationData.SESSION_ID,
                            ApplicationData.getCompanyID(),
                            ApplicationData.getBranchID(),
                            prefsValues.getCustomerId(),
                            AppUtils.randInt(0, 9, ApplicationData.ORDER_NUMBER_LENGTH)
                            , "" + makeOrderList(), Double.toString(totalBill), "0",
                            prefsValues.getCustomerName() + "\n" + prefsValues.getCustomerDeliveryAddress() + "\nPhone: " + prefsValues.getString(PrefsValues.CUSTOMER_PHONE),
                            "", binding.editTextExpectedDeliveryDate.getText().toString(),
                            binding.spinnerPaymentMethod.getSelectedItem().toString(),
                            shippingMethod, ApplicationData.SETTINGS_RESPONSE.getDeliveryCharge(),
                            ApplicationData.SETTINGS_RESPONSE.getGuestCustomer(),
                            ApplicationData.isTestDb()).enqueue(new Callback<PlaceOrderResponseModel>() {
                        @Override
                        public void onResponse(
                                Call<PlaceOrderResponseModel> call,
                                Response<PlaceOrderResponseModel> response) {

                            try {
                                ((DeliveryInformationActivity) getActivity()).hideProgressDialog();
                                PlaceOrderResponseModel placeOrderResponseModel = response.body();
                                if (placeOrderResponseModel != null && placeOrderResponseModel.getResponse_code() == ApplicationData.SUCCESS_RESPONSE_CODE) {

                                    Intent orderConfirmationIntent = new Intent(getActivity(), OrderConfirmationActivity.class);
                                    startActivity(orderConfirmationIntent);
                                    getActivity().finish();

                                } else {

                                    ((DeliveryInformationActivity) getActivity()).showToastMessage(getString(R.string.order_not_placed) + ". Code: "
                                            + placeOrderResponseModel.getResponse_code());
                                            /*AppUtils.customDialogOneButton(
                                                    getActivity(),
                                                    getActivity(),
                                                    getString(R.string.alert_order_failed_title),
                                                    String.format(getString(R.string.alert_order_failed_message),
                                                            placeOrderResponseModel.getResponse_code()),
                                                    View.GONE,
                                                    getString(R.string.alert_ok_button),
                                                    R.drawable.vector_info_alertdialog,
                                                    ApplicationData.TRACK_ALERT_ORDER_FAILED
                                            );*/
                                }

                            } catch (Exception e) {
                                // TODO send exception message to firebase
                                LogMe.e(TAG, e.toString());
                            }
                        }

                        @Override
                        public void onFailure(
                                Call<PlaceOrderResponseModel> call,
                                Throwable t) {

                            ((DeliveryInformationActivity) getActivity()).hideProgressDialog();
                            AppUtils.customDialogOneButton(getActivity(), getActivity(), getString(R.string.alert_server_down_title),
                                    getString(R.string.alert_server_down_message), View.GONE, getString(R.string.alert_ok_button),
                                    R.drawable.vector_info_alertdialog, ApplicationData.TRACK_ALERT_SERVER_PROBLEM);
                        }
                    });
                } else {
                    ((DeliveryInformationActivity) getActivity()).showToastMessage(getString(R.string.no_internet_connection));
                }
            } else {
                ((DeliveryInformationActivity) getActivity()).showToastMessage(getString(R.string.enter_delivery_data_correctly));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean isCheckFieldValue() {
        boolean errorValue = false;
        String deliveryAddress = binding.txtDeliveryAddress.getText().toString().replace("Delivery Address : ", "");
        String mobile = binding.txtMobile.getText().toString().replace("Mobile No : ", "");
        String customerName = binding.txtCustomerName.getText().toString().replace("Customer Name : ", "");
        if (deliveryAddress.isEmpty()) {
            binding.txtDeliveryAddress.setError("Please give full address");
            errorValue = true;
        } else if (mobile.isEmpty()) {
            binding.txtMobile.setError("Please enter a valid Mobile Number");
            errorValue = true;
        } else if (customerName.isEmpty()) {
            binding.txtCustomerName.setError("Please give a contact person's name");
            errorValue = true;
        }
        return errorValue;
    }

    private String makeOrderList() {

        try {

            String message;
            JSONObject json = new JSONObject();
            JSONArray array = new JSONArray();
            for (CartModel cartModel : ApplicationData.CART_MODEL_LIST) {
                JSONObject item = new JSONObject();
                item.put("productId", cartModel.getProductId());
                item.put("amount", Double.toString(cartModel.getSalesAmount()));
                item.put("unitBCost", Double.toString(cartModel.getUnitBuyingPrice()));
                item.put("unitSCost", Double.toString(cartModel.getUnitSellingPrice()));
                item.put("colorId", cartModel.getColorId());
                item.put("sizeId", cartModel.getSizeId());

                array.put(item);
            }
            json.put("orderItems", array);

            message = json.toString();
            LogMe.i(TAG, "" + message);

            String encodedJsonString = URLEncoder.encode(json.toString(), "UTF-8");
            return encodedJsonString;
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }

    }

    @Override
    public void onOkButtonClick(int trackingNumber) {

    }

    private DatePickerDialog.OnDateSetListener trnDatePickerListener = new DatePickerDialog.OnDateSetListener() {

        // when dialog box is closed, below method will be called.
        public void onDateSet(
                DatePicker view,
                int selectedYear,
                int selectedMonth,
                int selectedDay) {
            datePickerListener.setYear(selectedYear);
            datePickerListener.setMonth(selectedMonth);
            datePickerListener.setDay(selectedDay);

            binding.editTextExpectedDeliveryDate.setText(new StringBuilder()
                    // Month is 0 based, just add 1
                    .append(datePickerListener.getDay()).append("/").append(datePickerListener.getMonth() + 1).append("/").append(datePickerListener.getYear()).append(" "));
        }

    };

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void sendMessage() {
    }

    public void showExpressDeliveryMessage() {
        binding.textViewShippingMethodDescription.setText(R.string.express_shipping_description);
        shippingMethod = "Express";
    }

    @Override
    public void onCreateOptionsMenu(
            Menu menu,
            MenuInflater inflater) {
        inflater.inflate(R.menu.menu_confirm_order, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.menuItem_confirm_order:
                if (binding.editTextExpectedDeliveryDate.getText().toString().isEmpty()) {
                    ((DeliveryInformationActivity) getActivity()).showToastMessage(getActivity().
                            getString(R.string.choose_expected_delivery_date));

                    return true;
                }
                this.placeOrder();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

}