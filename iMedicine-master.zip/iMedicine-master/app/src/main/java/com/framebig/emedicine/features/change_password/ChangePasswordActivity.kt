package com.framebig.emedicine.features.change_password

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.appcompat.widget.Toolbar
import androidx.databinding.DataBindingUtil
import com.framebig.emedicine.R
import com.framebig.emedicine.databinding.ActivityChangePasswordBinding
import com.framebig.emedicine.features.BaseActivity
import com.framebig.emedicine.retrofit.ApiClient
import com.framebig.emedicine.utility.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ChangePasswordActivity : BaseActivity(), View.OnClickListener {
    private var activity: ChangePasswordActivity? = null
    private var prefsValues: PrefsValues? = null
    lateinit var binding: ActivityChangePasswordBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_change_password)
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        activity = this
        prefsValues = FrameBigApp.getDefaultSharePreference()
        binding.content.btnChangePassword.setOnClickListener(this)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    fun updatePassword() {
        if (binding.content.passwordChangeEdNewPassord.text.toString().equals(binding.content.passwordChangeEdNewPassordRepeat.text.toString())) {
            changePassword(binding!!.content.passwordChangeEdNewPassord.text.toString())
        } else {
            showToastMessage("Password Not Matched")
        }
    }

    private fun changePassword(password: String?) {
        try {
            if (Connectivity.isConnected(activity)) {
                showProgressDialog()
                ApiClient.getApiInterface().changeCustomerPassword(
                        ApplicationData.ACCESS_TOKEN,
                        "" + prefsValues!!.customerId, password, ApplicationData.isTestDb())!!.enqueue(object : Callback<ChangePasswordResponse?> {

                    override fun onResponse(p0: Call<ChangePasswordResponse?>, response: Response<ChangePasswordResponse?>) {
                        hideProgressDialog()
                        val changePassResponse = response.body()
                        if (changePassResponse!!.response_code == 200) {
                            showToastMessage(changePassResponse.response.msg)
                        } else {
                            showToastMessage("" + changePassResponse.response_code)
                        }
                    }

                    override fun onFailure(call: Call<ChangePasswordResponse?>, t: Throwable) {
                        hideProgressDialog()
                    }
                })
            } else {
                showToastMessage("No Internet Connection")
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onClick(view: View) {
        if (view == binding.content.btnChangePassword) {
            updatePassword()
        }
    }
}