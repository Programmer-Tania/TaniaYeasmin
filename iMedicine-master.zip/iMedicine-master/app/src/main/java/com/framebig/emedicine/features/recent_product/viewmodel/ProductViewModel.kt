package com.framebig.emedicine.features.recent_product.viewmodel

import android.content.Context
import androidx.databinding.ObservableBoolean
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.framebig.emedicine.features.model.ProductModel
import com.framebig.emedicine.features.recent_product.repository.ProductRepository
import kotlinx.coroutines.launch

class ProductViewModel(val context: Context) : ViewModel() {

    var repository: ProductRepository = ProductRepository(context)
    var loading = ObservableBoolean(false)
    val dataList = MutableLiveData<List<ProductModel>>()

    fun fetchProduct(since: Long) = viewModelScope.launch {
        loading.set(true)
        val data = repository.getAllProducts()
        dataList.postValue(data)
        loading.set(false)
    }
}