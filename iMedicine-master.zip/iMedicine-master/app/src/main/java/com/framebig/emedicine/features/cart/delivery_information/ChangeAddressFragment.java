package com.framebig.emedicine.features.cart.delivery_information;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

import com.framebig.emedicine.R;
import com.framebig.emedicine.databinding.FragmentChangeAddressBinding;
import com.framebig.emedicine.utility.AppUtils;
import com.framebig.emedicine.utility.ApplicationData;
import com.framebig.emedicine.utility.FrameBigApp;
import com.framebig.emedicine.utility.PrefsValues;

public class ChangeAddressFragment extends Fragment implements View.OnClickListener
{

    FragmentChangeAddressBinding binding;
    PrefsValues prefsValues;
    OnUpdateListener updateListener;

    public ChangeAddressFragment()
    {
    }

    public static ChangeAddressFragment newInstance(/*String param1, String param2*/)
    {
        ChangeAddressFragment fragment = new ChangeAddressFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        if (getArguments() != null)
        {
        }
    }

    @Override
    public View onCreateView(
            LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState)
    {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_change_address, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(
            @NonNull View view,
            @Nullable Bundle savedInstanceState)
    {
        super.onViewCreated(view, savedInstanceState);
        prefsValues = FrameBigApp.getDefaultSharePreference();
        setDataInEditText();
        binding.buttonUpdate.setOnClickListener(this);
    }

    private void setDataInEditText()
    {
        binding.txtFieldAddress.setText(prefsValues.getCustomerDeliveryAddress());
        binding.textfieldDeleivaryContactPerson.setText(prefsValues.getCustomerName());
        binding.textFieldMobileNumber.setText(prefsValues.getCustomerPhone());
        // binding.txtArea.setText(prefsValues.getString(PrefsValues.CUSTOMER_AREA));
    }

    @Override
    public void onAttach(Context context)
    {
        super.onAttach(context);
        if (context instanceof OnUpdateListener)
        {
            updateListener = (OnUpdateListener) context;
        }
        else
        {
            throw new RuntimeException(context.toString() + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach()
    {
        super.onDetach();
    }

    @Override
    public void onClick(View v)
    {
        if (v == binding.buttonUpdate)
        {
            updateButtonClicked();
        }
    }

    public interface OnUpdateListener
    {
        void getAddressUpdate(String fullData);
    }

    private boolean isCheckFieldValue()
    {
        boolean errorValue = false;
        if (TextUtils.isEmpty(binding.textfieldDeleivaryContactPerson.getText().toString()))
        {
            binding.textfieldDeleivaryContactPerson.setError("Please give Contact Person.");
            binding.textfieldDeleivaryContactPerson.requestFocus();
            errorValue = true;
        }
        else if (TextUtils.isEmpty(binding.textFieldMobileNumber.getText().toString()))
        {
            binding.textFieldMobileNumber.setError("Please give your mobile number");
            binding.textFieldMobileNumber.requestFocus();
            errorValue = true;
        }
        else if (TextUtils.getTrimmedLength(binding.textFieldMobileNumber.getText().toString()) < ApplicationData.MOBILE_NUMBER_LENGTH)
        {
            binding.textFieldMobileNumber.setError("Mobile number is not valid!");
            binding.textFieldMobileNumber.requestFocus();
            errorValue = true;
        }
        else if (TextUtils.isEmpty(binding.txtFieldAddress.getText().toString()))
        {
            binding.txtFieldAddress.setError("Please set your address correctly.");
            binding.txtFieldAddress.requestFocus();
            errorValue = true;
        }
        return errorValue;
    }

    public void updateButtonClicked()
    {

        if (!isCheckFieldValue())
        {
            try
            {
                prefsValues.setCustomerDeliveryAddress(binding.txtFieldAddress.getText().toString());
                prefsValues.setCustomerName(binding.textfieldDeleivaryContactPerson.getText().toString());
                prefsValues.setCustomerPhone(binding.textFieldMobileNumber.getText().toString());
                //  prefsValues.putString(PrefsValues.CUSTOMER_AREA, binding.txtArea.getText().toString());

                AppUtils.hideKeyboard(getActivity());
                AppUtils.customDialogOneButton(getActivity(), getContext(), getActivity().getString(R.string.alert_sucess_address_title),
                        getActivity().getString(R.string.alert_sucess_address_message), View.GONE,
                        getActivity().getString(R.string.alert_ok_button), R.drawable.vector_info_alertdialog, 1);

                String FullData = "test";
                updateListener.getAddressUpdate(FullData);

            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }

    }
}
