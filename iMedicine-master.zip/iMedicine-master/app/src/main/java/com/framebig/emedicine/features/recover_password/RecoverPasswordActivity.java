package com.framebig.emedicine.features.recover_password;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.databinding.DataBindingUtil;

import com.framebig.emedicine.R;
import com.framebig.emedicine.databinding.ActivityRecoverPasswordBinding;
import com.framebig.emedicine.features.BaseActivity;
import com.framebig.emedicine.features.model.RecoverPasswordResponse;
import com.framebig.emedicine.retrofit.ApiClient;
import com.framebig.emedicine.utility.AlertDialogOneButton;
import com.framebig.emedicine.utility.AppUtils;
import com.framebig.emedicine.utility.ApplicationData;
import com.framebig.emedicine.utility.Connectivity;
import com.framebig.emedicine.utility.LogMe;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RecoverPasswordActivity extends BaseActivity implements AlertDialogOneButton.OnOkButtonClickListener
{

    private final String TAG = getClass().getName();
    private ActivityRecoverPasswordBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_recover_password);
        setSupportActionBar(binding.toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        binding.content.submitButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                callPasswordRecoveryApi();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case android.R.id.home:
                onBackPressed();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void callPasswordRecoveryApi()
    {

        String loginId = binding.content.edtForgetPassLoginId.getText().toString();
        String fullName = binding.content.edtForgetPassFullName.getText().toString();

        if (loginId.isEmpty() || fullName.isEmpty())
        {
            showToastMessage("Enter login id and your full name please.");
            return;
        }

        try
        {
            if (Connectivity.isConnected(RecoverPasswordActivity.this))
            {

                AppUtils.hideKeyboard(RecoverPasswordActivity.this);
                showProgressDialog();

                ApiClient.getApiInterface().resetCustomerLoginPassword(ApplicationData.ACCESS_TOKEN, loginId, fullName, ApplicationData.isTestDb()).enqueue(new Callback<RecoverPasswordResponse>()
                {
                    @Override
                    public void onResponse(
                            Call<RecoverPasswordResponse> call,
                            Response<RecoverPasswordResponse> response)
                    {

                        try
                        {
                            hideProgressDialog();
                            RecoverPasswordResponse responseObj = response.body();

                            if (responseObj != null && responseObj.getResponseCode() == ApplicationData.SUCCESS_RESPONSE_CODE)
                            {

                                AppUtils.customDialogOneButton(RecoverPasswordActivity.this, RecoverPasswordActivity.this, "New Password",
                                        responseObj.getResponse().getMsg(), View.GONE, "Ok", R.drawable.vector_info_alertdialog, 0);

                            }
                            else if (responseObj != null && responseObj.getResponseCode() == ApplicationData.INVALID_LOGIN_ID)
                            {

                                showToastMessage(responseObj.getResponse().getMsg());

                            }
                            else if (responseObj != null && responseObj.getResponseCode() == ApplicationData.VERIFICATION_REQUIRED_RESPONSE_CODE)
                            {

                                showToastMessage(responseObj.getResponse().getMsg());
                            }
                            else
                            {
                                showToastMessage(responseObj.getResponse().getMsg());
                            }

                        }
                        catch (Exception e)
                        {
                            // TODO exception message has to be sent to Firebase
                            LogMe.e(TAG, e.toString());
                        }
                    }

                    @Override
                    public void onFailure(
                            Call<RecoverPasswordResponse> call,
                            Throwable t)
                    {

                        hideProgressDialog();
                        AppUtils.customDialogOneButton(RecoverPasswordActivity.this, RecoverPasswordActivity.this,
                                getString(R.string.alert_server_down_title), getString(R.string.alert_server_down_message), View.GONE,
                                getString(R.string.alert_ok_button), R.drawable.vector_info_alertdialog, ApplicationData.TRACK_ALERT_SERVER_PROBLEM);
                    }
                });
            }
            else
            {
                showToastMessage(getString(R.string.no_internet_connection));
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    @Override
    public void onOkButtonClick(int trackingNumber)
    {
        finish();
    }
}
