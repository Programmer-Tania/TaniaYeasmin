package com.framebig.emedicine.utility;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import androidx.fragment.app.DialogFragment;

import com.framebig.emedicine.R;
import com.framebig.emedicine.enums.ClientEnum;
import com.framebig.emedicine.enums.DatabaseType;

import static com.framebig.emedicine.utility.ApplicationData.COMPANY_LIST;
import static com.framebig.emedicine.utility.ApplicationData.TESTING_DATABASE_TYPE;

/**
 * Created by shohrab on 6/12/2016.
 */
public class AlertDialogWIthSpinner extends DialogFragment {

    private Button button_cancel;
    private Button button_ok;

    PrefsValues prefsValues;

    /**
     * Create a new instance of MyDialogFragment
     */
    public static AlertDialogWIthSpinner newInstance() {

        AlertDialogWIthSpinner f = new AlertDialogWIthSpinner();
        // Supply num input as an argument.
        Bundle args = new Bundle();
        f.setArguments(args);
        return f;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(
            LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState) {

        View alertDlgView = inflater.inflate(R.layout.dialog_testing, container, false);

        final Spinner spinnerClient = alertDlgView.findViewById(R.id.spinner_client);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, COMPANY_LIST);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerClient.setAdapter(adapter);

        final Spinner spinnerDatabase = alertDlgView.findViewById(R.id.spinner_db_version);

        ArrayAdapter<String> baseadapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, TESTING_DATABASE_TYPE);

        baseadapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDatabase.setAdapter(baseadapter);

        button_ok = alertDlgView.findViewById(R.id.button_ok);
        button_cancel = alertDlgView.findViewById(R.id.button_cancel);

        button_ok.setOnClickListener(view -> {

            if (spinnerDatabase.getSelectedItem().equals(DatabaseType.Production.getServerType())) {
                FrameBigApp.getDefaultSharePreference().putBoolean(prefsValues.IS_TEST_DB, false);
            } else {
                FrameBigApp.getDefaultSharePreference().putBoolean(prefsValues.IS_TEST_DB, true);
            }

            if (spinnerClient.getSelectedItem().equals(COMPANY_LIST[0])) {
                FrameBigApp.getDefaultSharePreference().putString(prefsValues.COMPANY_ID, ClientEnum.INTERNAL.getRegistrationID());
                FrameBigApp.getDefaultSharePreference().putString(prefsValues.COMPANY_NAME, ClientEnum.INTERNAL.getCompanyName());
            } else {
                FrameBigApp.getDefaultSharePreference().putString(prefsValues.COMPANY_ID, ClientEnum.MRC.getRegistrationID());
                FrameBigApp.getDefaultSharePreference().putString(prefsValues.COMPANY_NAME, ClientEnum.MRC.getCompanyName());
            }
            getDialog().dismiss();
        });

        button_cancel.setOnClickListener(view -> getDialog().dismiss());
        return alertDlgView;
    }
}
