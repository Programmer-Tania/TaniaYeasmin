package com.framebig.emedicine.features.model;

import javax.annotation.Generated;

import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class Response
{

    @SerializedName("msg")
    private String msg;

    public void setMsg(String msg)
    {
        this.msg = msg;
    }

    public String getMsg()
    {
        return msg;
    }

    @Override
    public String toString()
    {
        return "Response{" + "msg = '" + msg + '\'' + "}";
    }
}