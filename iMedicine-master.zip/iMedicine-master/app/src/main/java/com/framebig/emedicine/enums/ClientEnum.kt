package com.framebig.emedicine.enums

enum class ClientEnum(val companyName: String, val appName: String, val registrationID: String) {
    INTERNAL("internal", "Order App", "767182341102238"),
    MRC("mrc", "MRC Order App", "767182341102238"),
    BAZAR_LAGBE("bazarlagbe", "Bazar Lagbe", "437182341102259"),
    RED_AND_GREEN("redandgreen", "Red And Green", "331087879581892"),
    MRC_WHOLE_SALE("mrcWholeSale", "MRC Wholesale", "276093710210043");
}