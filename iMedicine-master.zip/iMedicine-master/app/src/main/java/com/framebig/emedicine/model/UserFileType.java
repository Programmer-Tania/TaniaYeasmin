package com.framebig.emedicine.model;

/**
 * Created by shamimhossain on 6/3/17.
 */
public enum UserFileType
{
    ProfilePhoto, UserPrescription, UserReport, DoctorPrescription,

    //    public static UserType getFileType(Integer type){
    //    if (type == Patient.ordinal()){
    //        return Patient;
    //    } else if(type == Doctor.ordinal()) {
    //        return Doctor;
    //    } else {
    //        return Undefined;
    //    }
    //}

}
