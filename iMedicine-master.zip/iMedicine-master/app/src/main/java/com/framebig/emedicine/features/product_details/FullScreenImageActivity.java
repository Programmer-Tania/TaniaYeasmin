package com.framebig.emedicine.features.product_details;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

import com.framebig.emedicine.R;
import com.framebig.emedicine.features.model.ProductModel;
import com.framebig.emedicine.utility.ApplicationData;

public class FullScreenImageActivity extends AppCompatActivity
{
    private ViewPager viewPager;
    private SlideShowAdapter adapter;
    private ProductModel productModel;
    private ImageView buttonNext;
    private ImageView buttonPrev;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_screen_image);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        productModel = ApplicationData.ProductDetails;
        getSupportActionBar().setTitle(productModel.getProductName());

        viewPager = (ViewPager) findViewById(R.id.viewPager_id);
        buttonNext = findViewById(R.id.navigate_next);
        buttonPrev = findViewById(R.id.navigate_back);

        adapter = new SlideShowAdapter(this, productModel.getImageList());
        viewPager.setAdapter(adapter);

        int position = getIntent().getExtras().getInt("position");
        viewPager.setCurrentItem(position);

        int imagesNo = productModel.getImageList().size();
        int i = viewPager.getCurrentItem();

        if (i == 0 && imagesNo > 1)
        {
            buttonNext.setVisibility(View.VISIBLE);
            buttonPrev.setVisibility(View.INVISIBLE);
        }
        else if (i == imagesNo - 1 && imagesNo > 1)
        {
            buttonPrev.setVisibility(View.VISIBLE);
            buttonNext.setVisibility(View.INVISIBLE);
        }
        else if (i == 0 && imagesNo == 1)
        {
            buttonNext.setVisibility(View.INVISIBLE);
            buttonPrev.setVisibility(View.INVISIBLE);
        }
        else
        {
            buttonPrev.setVisibility(View.VISIBLE);
            buttonNext.setVisibility(View.VISIBLE);
        }

        buttonNext.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                viewPager.setCurrentItem(viewPager.getCurrentItem() + 1);
            }
        });
        buttonPrev.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                viewPager.setCurrentItem(viewPager.getCurrentItem() - 1);
            }
        });
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener()
        {
            @Override
            public void onPageScrolled(
                    int position,
                    float positionOffset,
                    int positionOffsetPixels)
            {

            }

            @Override
            public void onPageSelected(int position)
            {
                if (position == 0 && imagesNo > 1)
                {
                    buttonNext.setVisibility(View.VISIBLE);
                    buttonPrev.setVisibility(View.INVISIBLE);
                }
                else if (position == imagesNo - 1 && imagesNo > 1)
                {
                    buttonPrev.setVisibility(View.VISIBLE);
                    buttonNext.setVisibility(View.INVISIBLE);
                }
                else
                {
                    buttonPrev.setVisibility(View.VISIBLE);
                    buttonNext.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state)
            {

            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}