package com.framebig.emedicine.features.best_selling;

import com.framebig.emedicine.features.model.ProductModel;

import java.util.List;

public class BestSellingProductResponse{
	private Integer responseCode;
	private List<ProductModel> response;
	private String status;

	public void setResponseCode(Integer responseCode){
		this.responseCode = responseCode;
	}

	public Integer getResponseCode(){
		return responseCode;
	}

	public void setResponse(List<ProductModel> response){
		this.response = response;
	}

	public List<ProductModel> getResponse(){
		return response;
	}

	public void setStatus(String status){
		this.status = status;
	}

	public String getStatus(){
		return status;
	}
}