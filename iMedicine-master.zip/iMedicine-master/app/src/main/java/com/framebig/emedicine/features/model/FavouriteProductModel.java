package com.framebig.emedicine.features.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by User on 1/3/2018.
 */
@Entity
public class FavouriteProductModel
{

    @PrimaryKey(autoGenerate = true)
    private int id;
    private String productName;
    private String productQuantity;
    private ArrayList<String> imageList;
    private String productDescription;
    private String productUnit;
    private int ProductId;
    private String productShotName;
    private String categoryId;
    private String maxOnlineUnitSellingCost;
    private String minOnlineUnitSellingCost;
    private String discountedPrice;
    private int discountedPercentage;
    private int response_code;

    @SerializedName("response")
    @Expose
    private ArrayList<FavouriteProductModel> productModelArrayList = new ArrayList<>();

    public String getProductName()
    {
        return productName;
    }

    public void setProductName(String productName)
    {
        this.productName = productName;
    }

    public String getProductQuantity()
    {
        return productQuantity;
    }

    public void setProductQuantity(String productQuantity)
    {
        this.productQuantity = productQuantity;
    }

    public ArrayList<String> getImageList()
    {
        return imageList;
    }

    public void setImageList(ArrayList<String> imageList)
    {
        this.imageList = imageList;
    }

    public String getProductDescription()
    {
        return productDescription;
    }

    public void setProductDescription(String productDescription)
    {
        this.productDescription = productDescription;
    }

    public String getProductUnit()
    {
        return productUnit;
    }

    public void setProductUnit(String productUnit)
    {
        this.productUnit = productUnit;
    }

    public int getProductId()
    {
        return ProductId;
    }

    public void setProductId(int productId)
    {
        ProductId = productId;
    }

    public String getProductShotName()
    {
        return productShotName;
    }

    public void setProductShotName(String productShotName)
    {
        this.productShotName = productShotName;
    }

    public String getCategoryId()
    {
        return categoryId;
    }

    public void setCategoryId(String categoryId)
    {
        this.categoryId = categoryId;
    }

    public ArrayList<FavouriteProductModel> getProductModelArrayList()
    {
        return productModelArrayList;
    }

    public void setProductModelArrayList(ArrayList<FavouriteProductModel> productModelArrayList)
    {

        this.productModelArrayList = productModelArrayList;
    }

    public int getResponse_code()
    {
        return response_code;
    }

    public void setResponse_code(int response_code)
    {
        this.response_code = response_code;
    }

    public String getMaxOnlineUnitSellingCost()
    {
        return maxOnlineUnitSellingCost;
    }

    public void setMaxOnlineUnitSellingCost(String maxOnlineUnitSellingCost)
    {
        this.maxOnlineUnitSellingCost = maxOnlineUnitSellingCost;
    }

    public String getMinOnlineUnitSellingCost()
    {
        return minOnlineUnitSellingCost;
    }

    public void setMinOnlineUnitSellingCost(String minOnlineUnitSellingCost)
    {
        this.minOnlineUnitSellingCost = minOnlineUnitSellingCost;
    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public String getDiscountedPrice()
    {
        return discountedPrice;
    }

    public void setDiscountedPrice(String discountedPrice)
    {
        this.discountedPrice = discountedPrice;
    }

    public int getDiscountedPercentage()
    {
        return discountedPercentage;
    }

    public void setDiscountedPercentage(int discountedPercentage)
    {
        this.discountedPercentage = discountedPercentage;
    }

}
