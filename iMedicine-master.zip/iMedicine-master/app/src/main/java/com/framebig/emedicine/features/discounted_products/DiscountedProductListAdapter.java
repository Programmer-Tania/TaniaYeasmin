package com.framebig.emedicine.features.discounted_products;

import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.framebig.emedicine.R;
import com.framebig.emedicine.utility.ApplicationData;
import com.framebig.emedicine.utility.CustomerType;
import com.framebig.emedicine.utility.FrameBigApp;
import com.framebig.emedicine.utility.PrefsValues;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class DiscountedProductListAdapter extends RecyclerView.Adapter<DiscountedProductListAdapter.MyViewHolder> implements Filterable
{

    private List<DiscountResponseItem> discountedModelList;
    private List<DiscountResponseItem> discountedModelListFilteredList;
    private RecyclerCustomItemClickListener listener;
    private boolean isRetailCustomer;
    private static final int LIST_ITEM = 0;
    public static final int GRID_ITEM = 1;
    public static boolean isSwitchView;

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener
    {

        private TextView productName, productPrice, productDiscountedPrice, productPrevPrice;
        private ImageView productImage;

        public MyViewHolder(View view)
        {
            super(view);
            this.productImage = view.findViewById(R.id.product_imageView);
            this.productName = view.findViewById(R.id.product_Name);
            this.productPrice = view.findViewById(R.id.product_price);
            this.productDiscountedPrice = view.findViewById(R.id.product_discounted_price);
            this.productPrevPrice = view.findViewById(R.id.product_prev_price);
            view.setOnClickListener(this);
        }

        @Override
        public void onClick(View v)
        {
            listener.getItem(discountedModelListFilteredList.get(getAdapterPosition()));
        }
    }

    public void setProductModelList(List<DiscountResponseItem> productModelList)
    {
        this.discountedModelList = productModelList;
        notifyDataSetChanged();
    }

    public DiscountedProductListAdapter(
            List<DiscountResponseItem> product_list,
            RecyclerCustomItemClickListener listener)
    {
        this.discountedModelList = product_list;
        this.discountedModelListFilteredList = product_list;
        this.listener = listener;
        isRetailCustomer =
                FrameBigApp.getDefaultSharePreference().getStringWithDefault(PrefsValues.CUSTOMER_TYPE, CustomerType.retail.toString()).equalsIgnoreCase(CustomerType.retail.toString());
    }

    @Override
    public MyViewHolder onCreateViewHolder(
            ViewGroup parent,
            int viewType)
    {
        View itemView;
        if (viewType == LIST_ITEM)
        {
            itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product_list, null);
        }
        else
        {
            itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product_cardview, null);
        }
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(
            MyViewHolder holder,
            int position)
    {
        try
        {
            DiscountResponseItem discountResponseItem = discountedModelListFilteredList.get(position);
            holder.productName.setText(discountResponseItem.getProductName());
            double discountedPrice = discountResponseItem.getDiscountedPrice();

            holder.productPrice.setVisibility(View.GONE);
            holder.productPrevPrice.setVisibility(View.VISIBLE);
            holder.productDiscountedPrice.setVisibility(View.VISIBLE);
            holder.productDiscountedPrice.setText(ApplicationData.SETTINGS_RESPONSE.getCurrencySymbol() + " " + discountResponseItem.getDiscountedPrice());
            holder.productPrevPrice.setPaintFlags(holder.productPrevPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);

            if (isRetailCustomer)
            {
                holder.productPrevPrice.setText(ApplicationData.SETTINGS_RESPONSE.getCurrencySymbol() + " " + discountResponseItem.getMaxRetailCost());
            }
            else
            {
                holder.productPrevPrice.setText(ApplicationData.SETTINGS_RESPONSE.getCurrencySymbol() + " " + discountResponseItem.getMaxWholeSaleCost());
            }

            String image = discountResponseItem.getImageList().get(0);
            Picasso.get().load(image).error(R.drawable.image_not_found).placeholder(R.drawable.image_not_found).resize(350, 350).into(holder.productImage);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemViewType(int position)
    {
        if (isSwitchView)
        {
            return LIST_ITEM;
        }
        else
        {
            return GRID_ITEM;
        }
    }

    public boolean toggleItemViewType()
    {
        isSwitchView = !isSwitchView;
        return isSwitchView;
    }

    @Override
    public int getItemCount()
    {
        return discountedModelListFilteredList.size();
    }

    @Override
    public Filter getFilter()
    {
        return exampleFilter;
    }

    private Filter exampleFilter = new Filter()
    {
        @Override
        protected FilterResults performFiltering(CharSequence constraint)
        {
            String filterPattern = constraint.toString();

            if (filterPattern.isEmpty())
            {
                discountedModelListFilteredList = discountedModelList;
            }
            else
            {

                List<DiscountResponseItem> filteredList = new ArrayList<>();
                for (DiscountResponseItem serviceSubCategory : discountedModelList)
                {
                    if (serviceSubCategory.getProductName().toLowerCase().contains(filterPattern))
                    {
                        filteredList.add(serviceSubCategory);
                    }
                }
                discountedModelListFilteredList = filteredList;
            }
            FilterResults results = new FilterResults();
            results.values = discountedModelListFilteredList;
            return results;
        }

        @Override
        protected void publishResults(
                CharSequence constraint,
                FilterResults results)
        {
            discountedModelListFilteredList = (List<DiscountResponseItem>) results.values;
            notifyDataSetChanged();
        }
    };

    public interface RecyclerCustomItemClickListener
    {
        void onRowSelected(int position);

        void getItem(DiscountResponseItem productModel);
    }
}
