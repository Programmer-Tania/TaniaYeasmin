package com.framebig.emedicine.features.cart.delivery_information;

import com.google.gson.annotations.SerializedName;

public class ResponseItem
{

    @SerializedName("discountPercentage")
    private int discountPercentage;

    @SerializedName("details")
    private String details;

    @SerializedName("paymentMethodName")
    private String paymentMethodName;

    public void setDiscountPercentage(int discountPercentage)
    {
        this.discountPercentage = discountPercentage;
    }

    public int getDiscountPercentage()
    {
        return discountPercentage;
    }

    public void setDetails(String details)
    {
        this.details = details;
    }

    public String getDetails()
    {
        return details;
    }

    public void setPaymentMethodName(String paymentMethodName)
    {
        this.paymentMethodName = paymentMethodName;
    }

    public String getPaymentMethodName()
    {
        return paymentMethodName;
    }
}