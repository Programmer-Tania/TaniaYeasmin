package com.framebig.emedicine.features.cart.cart_item;

import com.framebig.emedicine.features.model.CartModel;

/**
 * Created by shohrab on 19.03.2018.
 */

public interface CartContract
{

    void decreaseAmount(
            CartModel cartModel,
            int position);

    void increaseAmount(
            CartModel cartModel,
            int position);

    void deleteCartItem(CartModel cartModel);
}
