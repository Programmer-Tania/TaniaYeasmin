package com.framebig.emedicine.features.sign_in;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.databinding.DataBindingUtil;

import com.framebig.emedicine.R;
import com.framebig.emedicine.databinding.ActivitySignInBinding;
import com.framebig.emedicine.features.BaseActivity;
import com.framebig.emedicine.features.home.HomeActivity;
import com.framebig.emedicine.features.model.LoginResponseModel;
import com.framebig.emedicine.features.recover_password.RecoverPasswordActivity;
import com.framebig.emedicine.features.sign_up.SignUpActivity;
import com.framebig.emedicine.retrofit.ApiClient;
import com.framebig.emedicine.utility.AlertDialogOneButton;
import com.framebig.emedicine.utility.AppUtils;
import com.framebig.emedicine.utility.ApplicationData;
import com.framebig.emedicine.utility.Connectivity;
import com.framebig.emedicine.utility.FrameBigApp;
import com.framebig.emedicine.utility.LogMe;
import com.framebig.emedicine.utility.PrefsValues;

import org.json.JSONObject;

import java.net.URLEncoder;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.framebig.emedicine.utility.PrefsValues.CUSTOMER_TYPE;

public class SignInActivity extends BaseActivity implements AlertDialogOneButton.OnOkButtonClickListener, View.OnClickListener
{

    private String TAG = "SignInActivity";
    private PrefsValues prefsValues;
    ActivitySignInBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_sign_in);

        setSupportActionBar(binding.toolbar);
        getSupportActionBar().setTitle(getString(R.string.log_in));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        prefsValues = FrameBigApp.getDefaultSharePreference();
        binding.content.buttonSignIn.setOnClickListener(this);
        binding.content.textViewForgotPassword.setOnClickListener(this);
        binding.content.textViewRegister.setOnClickListener(this);

        if (savedInstanceState == null)
        {
            Bundle extras = getIntent().getExtras();
            if (extras != null)
            {
                binding.content.editTextLoginId.setText(extras.getString("loginId"));
            }
            else
            {
                binding.content.editTextLoginId.setText(prefsValues.getLoginId());
            }
        }
    }

    public void loginButtonClicked()
    {

        if (binding.content.editTextLoginId.getText().toString().isEmpty())
        {
            showToastMessage(getString(R.string.validation_login_id));
            return;
        }

        if (binding.content.edittextInputPassword.getText().toString().isEmpty())
        {
            showToastMessage(getString(R.string.validation_password));
            return;
        }
        callLoginApi();
    }

    public void forgotPasswordClicked()
    {
        Intent intent = new Intent(SignInActivity.this, RecoverPasswordActivity.class);
        startActivity(intent);
    }

    public void registerClicked()
    {
        Intent signUpIntent = new Intent(SignInActivity.this, SignUpActivity.class);
        startActivity(signUpIntent);
        finish();
    }

    private void callLoginApi()
    {

        final String loginId = binding.content.editTextLoginId.getText().toString();
        final String password = binding.content.edittextInputPassword.getText().toString();
        final String fcmToken = prefsValues.getFirebasebaseTokeId();

        try
        {
            if (Connectivity.isConnected(SignInActivity.this))
            {
                AppUtils.hideKeyboard(SignInActivity.this);

                String loginData = prepareLoginData(loginId, password, ApplicationData.SESSION_ID);
                showProgressDialog();

                ApiClient.getApiInterface().login(ApplicationData.ACCESS_TOKEN, fcmToken, loginData, ApplicationData.isTestDb()).enqueue(new Callback<LoginResponseModel>()
                {
                    @Override
                    public void onResponse(
                            Call<LoginResponseModel> call,
                            Response<LoginResponseModel> response)
                    {

                        try
                        {

                            hideProgressDialog();
                            LoginResponseModel loginResponseModel = response.body();
                            if (loginResponseModel != null && loginResponseModel.getResponse_code() == ApplicationData.SUCCESS_RESPONSE_CODE)
                            {

                                LoginResponseModel.Response responseObj = loginResponseModel.getResponse();
                                storeLoginInPref(loginId, password);

                                storeCustomerPref(responseObj.getFullName(), responseObj.getCustomerId(), responseObj.getPhone(),
                                        responseObj.getBillingAddress(), responseObj.getDeliveryAddress(), responseObj.getEmail(),
                                        responseObj.getCustomerType());

                                gotoLandingActivity();

                            }
                            else if (loginResponseModel != null && loginResponseModel.getResponse_code() == ApplicationData.LOGIN_FAILED_RESPONSE_CODE)
                            {

                                AppUtils.customDialogOneButton(SignInActivity.this, SignInActivity.this,
                                        getString(R.string.alert_login_failed_title), getString(R.string.alert_login_failed_message), View.GONE,
                                        getString(R.string.alert_ok_button), R.drawable.vector_info_alertdialog,
                                        ApplicationData.TRACK_ALERT_SERVER_PROBLEM);
                            }
                            else if (loginResponseModel != null && loginResponseModel.getResponse_code() == ApplicationData.VERIFICATION_REQUIRED_RESPONSE_CODE)
                            {

                                AppUtils.customDialogOneButton(SignInActivity.this, SignInActivity.this,
                                        getString(R.string.alert_verification_required_title),
                                        getString(R.string.alert_verification_required_message), View.GONE, getString(R.string.alert_ok_button),
                                        R.drawable.vector_info_alertdialog, ApplicationData.TRACK_ALERT_VERIFICATION_REQUIRED);
                            }

                        }
                        catch (Exception e)
                        {
                            showToastMessage(e.getMessage());
                            LogMe.e(TAG, e.toString());
                        }
                    }

                    @Override
                    public void onFailure(
                            Call<LoginResponseModel> call,
                            Throwable t)
                    {

                        hideProgressDialog();
                        AppUtils.customDialogOneButton(SignInActivity.this, SignInActivity.this, getString(R.string.alert_server_down_title),
                                getString(R.string.alert_server_down_message), View.GONE, getString(R.string.alert_ok_button),
                                R.drawable.vector_info_alertdialog, ApplicationData.TRACK_ALERT_SERVER_PROBLEM);
                    }
                });
            }
            else
            {
                showToastMessage(getString(R.string.no_internet_connection));
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    private void gotoLandingActivity()
    {
        Intent categoryIntent = new Intent(SignInActivity.this, HomeActivity.class);
        categoryIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(categoryIntent);
        finish();
    }

    private String prepareLoginData(
            String loginId,
            String password,
            String sessionId)
    {

        try
        {

            JSONObject json = new JSONObject();
            json.put("loginId", loginId);
            json.put("password", password);
            json.put("sessionId", sessionId);

            String encodedJsonString = URLEncoder.encode(json.toString(), "UTF-8");
            return encodedJsonString;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return "";
        }
    }

    private void storeLoginInPref(
            String loginId,
            String password)
    {

        prefsValues.setLoginId(loginId);
        prefsValues.setPassword(password);
    }

    private void storeCustomerPref(
            String customerName,
            int customerId,
            String phone,
            String billingAddress,
            String deliveryAddress,
            String email,
            String customerType)
    {

        prefsValues.setCustomerName(customerName);
        prefsValues.setCustomerId(customerId);
        prefsValues.setCustomerPhone(phone);
        prefsValues.setCustomerEmail(email);
        prefsValues.setCustomerDeliveryAddress(deliveryAddress);
        prefsValues.setCustomerBillingAddress(billingAddress);
        prefsValues.putString(CUSTOMER_TYPE, customerType);
        prefsValues.setIsGuestCustomer(false);
    }

    @Override
    public void onOkButtonClick(int trackingNumber)
    {
        switch (trackingNumber)
        {
            case ApplicationData.TRACK_ALERT_VERIFICATION_REQUIRED:
        }
    }

    @Override
    public void onClick(View v)
    {
        if (v == binding.content.buttonSignIn)
        {
            loginButtonClicked();
        }
        else if (v == binding.content.textViewForgotPassword)
        {
            forgotPasswordClicked();
        }
        else if (v == binding.content.textViewRegister)
        {
            registerClicked();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
