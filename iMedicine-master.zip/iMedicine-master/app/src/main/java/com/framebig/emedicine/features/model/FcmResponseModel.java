package com.framebig.emedicine.features.model;

/**
 * Created by Shihab on 2/22/2018.
 */

public class FcmResponseModel
{

    /*{
        "response_code":200,
        "response":"FCM token ID is updated",
        "status":"success"}
    }
    */

    private int response_code;
    private String response;
    private String status;

    public int getResponse_code()
    {
        return response_code;
    }

    public void setResponse_code(int response_code)
    {
        this.response_code = response_code;
    }

    public String getResponse()
    {
        return response;
    }

    public void setResponse(String response)
    {
        this.response = response;
    }

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }
}
