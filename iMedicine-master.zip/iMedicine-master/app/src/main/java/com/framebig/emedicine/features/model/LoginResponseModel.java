package com.framebig.emedicine.features.model;

/**
 * Created by Shihab on 2/22/2018.
 */

public class LoginResponseModel
{

    private int response_code;
    private Response response;
    private String status;

    public Response getResponse()
    {
        return response;
    }

    public void setResponse(Response response)
    {
        this.response = response;
    }

    public int getResponse_code()
    {
        return response_code;
    }

    public void setResponse_code(int response_code)
    {
        this.response_code = response_code;
    }

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

    public class Response
    {

        private int customerId;
        private String fullName;
        private String phone;
        private String deliveryAddress;
        private String billingAddress;
        private String email;
        private String customerType;

        public int getCustomerId()
        {
            return customerId;
        }

        public void setCustomerId(int customerId)
        {
            this.customerId = customerId;
        }

        public String getFullName()
        {
            return fullName;
        }

        public void setFullName(String fullName)
        {
            this.fullName = fullName;
        }

        public String getPhone()
        {
            return phone;
        }

        public void setPhone(String phone)
        {
            this.phone = phone;
        }

        public String getDeliveryAddress()
        {
            return deliveryAddress;
        }

        public void setDeliveryAddress(String deliveryAddress)
        {
            this.deliveryAddress = deliveryAddress;
        }

        public String getBillingAddress()
        {
            return billingAddress;
        }

        public void setBillingAddress(String billingAddress)
        {
            this.billingAddress = billingAddress;
        }

        public String getEmail()
        {
            return email;
        }

        public void setEmail(String email)
        {
            this.email = email;
        }

        public String getCustomerType()
        {
            return customerType;
        }

        public void setCustomerType(String customerType)
        {
            this.customerType = customerType;
        }
    }
}
