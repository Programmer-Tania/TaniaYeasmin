package com.framebig.emedicine.features.model;

/**
 * Created by shohrab on 13.03.2018.
 */

public class CartModel
{

    public String productName, unitName, productShortName, salesDate, bill_no, salesManB, salesmanId, colorName, sizeName, imageUrl;
    public int productId, colorId, sizeId, customerId;
    public double unitSellingPrice, unitBuyingPrice, perItemVat, totalVat, totalSalesAmt, netSalesAmt, salesAmount, currentStock;
    private boolean isQuantityChangable;

    public CartModel()
    {

    }

    public CartModel(
            String product_Name,
            String product_short_name,
            int product_ID,
            String unit_name,
            double sales_Amount,
            double unit_buying_price,
            double unit_selling_price,
            String sales_ManB,
            String salesmanId,
            int color_ID,
            String color_Name,
            int size_ID,
            String size_Name,
            String image_url,
            boolean value,
            double currentStock)
    {

        this.productName = product_Name;
        this.productShortName = product_short_name;
        this.productId = product_ID;
        this.unitName = unit_name;
        this.salesAmount = sales_Amount;
        this.unitBuyingPrice = unit_buying_price;
        this.unitSellingPrice = unit_selling_price;
        this.salesManB = sales_ManB;
        this.salesmanId = salesmanId;
        this.colorId = color_ID;
        this.colorName = color_Name;
        this.sizeId = size_ID;
        this.sizeName = size_Name;
        this.imageUrl = image_url;
        this.isQuantityChangable = value;
        this.currentStock = currentStock;
    }

    public double getTotalVat()
    {
        return totalVat;
    }

    public void setTotalVat(double totalVat)
    {
        this.totalVat = totalVat;
    }

    public double getTotalSalesAmt()
    {
        return totalSalesAmt;
    }

    public void setTotalSalesAmt(double totalSalesAmt)
    {
        this.totalSalesAmt = totalSalesAmt;
    }

    public double getNetSalesAmt()
    {
        return netSalesAmt;
    }

    public void setNetSalesAmt(double netSalesAmt)
    {
        this.netSalesAmt = netSalesAmt;
    }

    public String getSalesDate()
    {
        return salesDate;
    }

    public void setSalesDate(String salesDate)
    {
        this.salesDate = salesDate;
    }

    public String getBill_no()
    {
        return bill_no;
    }

    public void setBill_no(String bill_no)
    {
        this.bill_no = bill_no;
    }

    public String getProductName()
    {
        return productName;
    }

    public int getColorId()
    {
        return colorId;
    }

    public int getSizeId()
    {
        return sizeId;
    }

    public double getSalesAmount()
    {
        return salesAmount;
    }

    public String getColorName()
    {
        return colorName;
    }

    public String getSizeName()
    {
        return sizeName;
    }

    public String getUnitName()
    {
        return unitName;
    }

    public double getUnitSellingPrice()
    {
        return unitSellingPrice;
    }

    public String getImageUrl()
    {
        return imageUrl;
    }

    public void setSalesAmount(double salesAmount)
    {
        this.salesAmount = salesAmount;
    }

    public int getProductId()
    {
        return productId;
    }

    public double getUnitBuyingPrice()
    {
        return unitBuyingPrice;
    }

    public boolean isQuantityChangable()
    {
        return isQuantityChangable;
    }

    public void setQuantityChangable(boolean quantityChangable)
    {
        isQuantityChangable = quantityChangable;
    }

    public double getCurrentStock()
    {
        return currentStock;
    }
}