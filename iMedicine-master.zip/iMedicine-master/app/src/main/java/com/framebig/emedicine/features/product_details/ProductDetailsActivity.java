package com.framebig.emedicine.features.product_details;

import android.content.Intent;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import com.framebig.emedicine.R;
import com.framebig.emedicine.features.BaseActivity;
import com.framebig.emedicine.features.cart.cart_item.CartActivity;
import com.framebig.emedicine.features.model.CartModel;
import com.framebig.emedicine.features.model.CurrentStockResponse;
import com.framebig.emedicine.features.model.FavouriteResponse;
import com.framebig.emedicine.features.model.ProductDetailsResponse;
import com.framebig.emedicine.features.model.ProductModel;
import com.framebig.emedicine.features.sign_in.SignInActivity;
import com.framebig.emedicine.retrofit.ApiClient;
import com.framebig.emedicine.utility.AlertDialogTwoButton;
import com.framebig.emedicine.utility.AppUtils;
import com.framebig.emedicine.utility.ApplicationData;
import com.framebig.emedicine.utility.Connectivity;
import com.framebig.emedicine.utility.CustomerType;
import com.framebig.emedicine.utility.FrameBigApp;
import com.framebig.emedicine.utility.LogMe;
import com.framebig.emedicine.utility.PrefsValues;

import org.jetbrains.annotations.NotNull;

import java.text.DecimalFormat;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.framebig.emedicine.utility.ApplicationData.SESSION_ID;

public class ProductDetailsActivity extends BaseActivity implements View.OnClickListener, AlertDialogTwoButton.ButtonClickListener {

    private String TAG = "Product Details";
    private ProductModel newProductModel = null;
    private ImageView specialOfferImage;
    private TextView product_heading;
    private TextView expandableTextView, product_unit;
    private Button btn_add_to_cart;
    private ImageView btn_increment, btn_decrease;
    private RelativeLayout relative_cart;
    private TextView textView_current_price;
    private TextView textView_discounted_price;
    private TextView textView_previous_price;
    private TextView textView_old_price;
    private TextView textView_discountPercent;
    private TextView textView_total_price;
    private EditText editText_quantity;
    private EditText edit_custom_quantity;
    private ImageView image_favourite;
    private PrefsValues prefsValues;
    private TextView txtViewCount;
    private TextView txtViewProductStock;
    private ProductDetailsActivity productDetailsActivity;
    private boolean isFavouriteProduct = false;
    private RelativeLayout relative_custom_add_amount;
    private CheckBox checkbox_custom_quantity;
    private RelativeLayout relative_add_amount;
    private View notifications;
    private double quantity = 0;
    private double productBuyingPrice = 0;
    private double productPrice = 0;
    private double previousPrice = 0;
    private boolean isRetailCustomer;
    private ViewPager viewPager;
    private ViewPagerAdapter adapter;
    private String productId;
    private LinearLayout sliderDotsPanel;
    private int dotsCount;
    private double currentStock;
    private ImageView[] dots;
    private String CURRENCY_SYMBOL = ApplicationData.SETTINGS_RESPONSE.getCurrencySymbol();
    private boolean isDiscountedProduct = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        productDetailsActivity = this;
        prefsValues = FrameBigApp.getDefaultSharePreference();
        isRetailCustomer =
                prefsValues.getStringWithDefault(PrefsValues.CUSTOMER_TYPE, CustomerType.retail.toString()).equalsIgnoreCase(CustomerType.retail.toString());

        notifications = findViewById(R.id.notifications);
        product_heading = findViewById(R.id.product_heading);
        expandableTextView = findViewById(R.id.expandableTextView);
        product_unit = findViewById(R.id.product_unit);
        txtViewProductStock = findViewById(R.id.product_stock);

        textView_current_price = findViewById(R.id.current_price);
        textView_old_price = findViewById(R.id.old_price);
        textView_discounted_price = findViewById(R.id.discounted_price);
        textView_previous_price = findViewById(R.id.previous_price);
        textView_discountPercent = findViewById(R.id.discount_text);
        specialOfferImage = findViewById(R.id.special_offer_image);

        textView_total_price = findViewById(R.id.total_price);
        relative_cart = findViewById(R.id.relative_add_amount);
        relative_add_amount = findViewById(R.id.relative_add_amount);

        editText_quantity = findViewById(R.id.editText_quantity);
        btn_decrease = findViewById(R.id.btn_decrease);
        btn_increment = findViewById(R.id.btn_increment);
        btn_add_to_cart = findViewById(R.id.btn_add_to_cart);
        image_favourite = findViewById(R.id.image_favourite);
        viewPager = findViewById(R.id.viewPager_product_imagelist);
        txtViewCount = notifications.findViewById(R.id.txtCount);
        sliderDotsPanel = findViewById(R.id.slider_dots);

        checkbox_custom_quantity = findViewById(R.id.checkbox_custom_quantity);
        edit_custom_quantity = findViewById(R.id.edit_custom_quantity);

        textView_discountPercent.setVisibility(View.GONE);
        specialOfferImage.setVisibility(View.GONE);

        notifications.setOnClickListener(this);
        btn_increment.setOnClickListener(this);
        btn_decrease.setOnClickListener(this);
        relative_cart.setOnClickListener(this);
        image_favourite.setOnClickListener(this);
        btn_add_to_cart.setOnClickListener(this);

        productId = ApplicationData.SHARED_MODEL.getSelectedProductId();

        getProductDetails(this.productId);

        image_favourite.setVisibility(View.INVISIBLE);

        if (prefsValues.getCustomerId() != 0) {
            image_favourite.setVisibility(View.VISIBLE);
        }

        if (getIntent().getBooleanExtra(ApplicationData.IS_A_FAVOURITE_PRODUCT, false)) {
            setColorForFav();
        }

        relative_custom_add_amount = findViewById(R.id.relative_custom_add_amount);

        if (ApplicationData.SETTINGS_RESPONSE.getCustomQuantity()) {
            relative_custom_add_amount.setVisibility(View.VISIBLE);
            setCustomLayoutEnabled(false);

            checkbox_custom_quantity.setOnCheckedChangeListener((compoundButton, checked) -> {
                resetQuantitity();
                if (checked) {
                    setCustomLayoutEnabled(true);
                    setLayoutEnabled(false);
                    edit_custom_quantity.requestFocus();
                    AppUtils.showSoftKeBoard(this);
                } else {
                    setCustomLayoutEnabled(false);
                    setLayoutEnabled(true);
                }
            });

            edit_custom_quantity.addTextChangedListener(new TextWatcher() {
                @Override
                public void afterTextChanged(Editable s) {

                }

                @Override
                public void beforeTextChanged(
                        CharSequence s,
                        int start,
                        int count,
                        int after) {

                }

                @Override
                public void onTextChanged(
                        CharSequence s,
                        int start,
                        int before,
                        int count) {

                    try {
                        if (s.length() != 0) {
                            if (quantity < 999) {
                                quantity = Double.parseDouble(s.toString());
                                calculateTotalPrice(quantity);
                            }
                        }

                    } catch (Exception e) {
                        quantity = 0;
                        editText_quantity.setText("0");
                        edit_custom_quantity.setText("");// this is set intentionally.
                        calculateTotalPrice(quantity);
                        e.printStackTrace();
                    }

                }
            });
        } else {
            relative_custom_add_amount.setVisibility(View.GONE);
        }

    }

    void resetQuantitity() {
        quantity = 0;
        editText_quantity.setText("0");
        edit_custom_quantity.setText("");
        calculateTotalPrice(quantity);
    }

    private void setLayoutEnabled(boolean b) {
        for (int i = 0; i < relative_add_amount.getChildCount(); i++) {
            View child = relative_add_amount.getChildAt(i);
            child.setEnabled(b);
        }
    }

    private void setCustomLayoutEnabled(boolean b) {
        for (int i = 0; i < relative_custom_add_amount.getChildCount(); i++) {
            View child = relative_custom_add_amount.getChildAt(i);
            if (child instanceof CheckBox) {
            } else {
                child.setEnabled(b);
            }
        }
    }

    void setColorForFav() {
        setFavouriteProduct(true);
        Drawable drawableCompat = ContextCompat.getDrawable(this, R.drawable.ic_star);
        image_favourite.setImageDrawable(drawableCompat);
    }

    void unSelectToFav() {
        setFavouriteProduct(false);
        Drawable drawableCompat = ContextCompat.getDrawable(this, R.drawable.ic_star_blank);
        image_favourite.setImageDrawable(drawableCompat);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Called when a view has been clicked.
     *
     * @param view The view that was clicked.
     */
    @Override
    public void onClick(View view) {
        if (view == btn_increment) {
            if (quantity < 999) {
                quantity++;
                editText_quantity.setText("" + quantity);
                this.calculateTotalPrice(quantity);
            }

        } else if (view == btn_decrease) {
            if (quantity <= 0) {

            } else {
                quantity--;
                editText_quantity.setText("" + quantity);
            }

            this.calculateTotalPrice(quantity);

        } else if (view == btn_add_to_cart) {
            if (quantity < 1) {
                showToastMessage(getString(R.string.toast_add_quantity));
                return;
            }

            if (productPrice < 1) {
                showToastMessage(getString(R.string.price_not_available));
                return;
            }

            if (quantity > currentStock && ApplicationData.SETTINGS_RESPONSE.isStockRestriction()) {
                if (currentStock < 1)
                    showToastMessage(getString(R.string.out_of_stock));
                else
                    showToastMessage(getString(R.string.out_of_stock_message));
                return;
            }

            this.checkStockAvailability();
        } else if (view == image_favourite) {

            if (isFavouriteProduct()) {
                deleteFavouriteProduct();
            } else {
                setFavouriteProduct();
            }
        } else if (view == notifications) {
            goToCartActivity();
        }
    }

    private void getProductDetails(String productId) {
        try {
            if (Connectivity.isConnected(this)) {
                showProgressDialog();
                ApiClient.getApiInterface().getProductDetails(ApplicationData.getCompanyID(), ApplicationData.ACCESS_TOKEN,
                        ApplicationData.isTestDb(), productId
                ).enqueue(new Callback<ProductDetailsResponse>() {
                    @Override
                    public void onResponse(
                            Call<ProductDetailsResponse> call,
                            Response<ProductDetailsResponse> response) {
                        try {
                            ProductDetailsResponse productModel = response.body();
                            if (productModel.getResponseCode() == ApplicationData.SUCCESS_RESPONSE_CODE) {
                                if (productModel.getProductModelList().size() > 0) {
                                    newProductModel = productModel.getProductModelList().get(0);
                                    setProductData(newProductModel);
                                    ApplicationData.ProductDetails = newProductModel;
                                }
                            } else {
                                showToastMessage("" + productModel.getStatus());
                            }

                            hideProgressDialog();
                        } catch (Exception e) {
                            e.printStackTrace();
                            hideProgressDialog();
                        }
                    }

                    @Override
                    public void onFailure(
                            Call<ProductDetailsResponse> call,
                            Throwable t) {

                        hideProgressDialog();
                    }
                });
            } else {
                AppUtils.customDialogTwoButtons(this, this, getString(R.string.alert_no_internet_title),
                        getString(R.string.alert_no_interner_message), View.GONE, getString(R.string.alert_no_internet_setting),
                        getString(R.string.alert_no_internet_retry), R.drawable.vector_info_alertdialog, ApplicationData.TRACK_ALERT_NO_INTERNET
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void checkStockAvailability() {
        try {
            if (Connectivity.isConnected(getApplicationContext())) {
                showProgressDialog();
                ApiClient.getApiInterface().getCurrentStock(
                        ApplicationData.getCompanyID(),
                        newProductModel.getProductId(),
                        ApplicationData.ACCESS_TOKEN,
                        ApplicationData.isTestDb()
                ).enqueue(new Callback<CurrentStockResponse>() {
                    @Override
                    public void onResponse(
                            @NotNull Call<CurrentStockResponse> call,
                            @NotNull Response<CurrentStockResponse> response) {
                        hideProgressDialog();
                        LogMe.i(TAG, "" + response.body().toString());

                        CurrentStockResponse currentStockResponse = response.body();
                        if (currentStockResponse.getResponseCode() == ApplicationData.SUCCESS_RESPONSE_CODE) {
                            CurrentStockResponse.ResponseModel responseModel = currentStockResponse.getResponse();

                            String c = responseModel.getCurrentStock();

                            if (Double.parseDouble(responseModel.getCurrentStock()) < quantity) {
                                AppUtils.customDialogTwoButtons(productDetailsActivity, productDetailsActivity, getString(R.string.alert_no_stock_balance_title),
                                        getString(R.string.alert_no_stock_balance_msg), View.GONE, getString(R.string.alert_cancel_button),
                                        getString(R.string.alert_refresh_button), R.drawable.vector_info_alertdialog, ApplicationData.TRACK_ALERT_NO_STOCK
                                );
                            } else {
                                initiateAddingProductToCart();
                            }
                        } else {
                            showToastMessage("" + currentStockResponse.getResponseCode());
                        }
                    }

                    @Override
                    public void onFailure(
                            @NotNull Call<CurrentStockResponse> call,
                            @NotNull Throwable t) {
                        hideProgressDialog();
                        t.printStackTrace();
                    }
                });
            } else {
                AppUtils.customDialogTwoButtons(this, this, getString(R.string.alert_no_internet_title),
                        getString(R.string.alert_no_interner_message), View.GONE, getString(R.string.alert_no_internet_exit),
                        getString(R.string.alert_no_internet_retry), R.drawable.vector_info_alertdialog, ApplicationData.TRACK_ALERT_NO_INTERNET
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initiateAddingProductToCart() {
        if (isUserLoggedIn()) {
            this.addProductToCart();

        } else {
            if (ApplicationData.SETTINGS_RESPONSE.getGuestCustomer()) {
                if (prefsValues.getisGuestCustomer()) {
                    if (quantity > 0 && productPrice != 0) {
                        this.addProductToCart();
                    } else {
                        showToastMessage(getString(R.string.toast_add_quantity));
                    }
                } else {
                    AppUtils.customDialogTwoButtons(this, this, getString(R.string.checkout),
                            getString(R.string.alert_login_as_guest_required_message), View.GONE, getString(R.string.log_in),
                            getString(R.string.continue_as_guest), R.drawable.vector_info_alertdialog,
                            ApplicationData.TRACK_ALERT_LOGIN_AS_GUEST_REQUIRED
                    );
                }

            } else {
                AppUtils.customDialogTwoButtons(this, this, getString(R.string.alert_login_required_title),
                        getString(R.string.alert_login_required_message), View.GONE, getString(R.string.alert_cancel_button),
                        getString(R.string.alert_yes_button), R.drawable.vector_info_alertdialog, ApplicationData.TRACK_ALERT_LOGIN_REQUIRED
                );
            }
        }
    }

    private void setProductData(ProductModel newProductModel) {

        if (newProductModel != null) {
            product_heading.setText(newProductModel.getProductName());
            expandableTextView.setText(newProductModel.getProductDescription());
            product_unit.setText(String.format(getString(R.string.selling_unit), newProductModel.getProductUnit()));
            getSupportActionBar().setTitle(newProductModel.getProductName());

            adapter = new ViewPagerAdapter(this, newProductModel.getImageList());
            viewPager.setAdapter(adapter);
            dotsCount = adapter.getCount();
            dots = new ImageView[dotsCount];

            for (int i = 0; i < dotsCount; i++) {
                dots[i] = new ImageView(this);
                dots[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.nonactive_dot));

                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );
                params.setMargins(8, 0, 8, 0);
                sliderDotsPanel.addView(dots[i], params);
            }

            if (dots.length > 1) {
                dots[0].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.active_dot));
            } else {
                sliderDotsPanel.setVisibility(View.GONE);
            }

            viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(
                        int position,
                        float positionOffset,
                        int positionOffsetPixels) {

                }

                @Override
                public void onPageSelected(int position) {
                    for (int i = 0; i < dotsCount; i++) {
                        dots[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.nonactive_dot));
                    }
                    dots[position].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.active_dot));
                }

                @Override
                public void onPageScrollStateChanged(int state) {

                }
            });

            double discountedPrice = Double.parseDouble(newProductModel.getDiscountedPrice());

            if (isRetailCustomer) {
                if (discountedPrice > 0.0) {
                    productPrice = discountedPrice;
                    isDiscountedProduct = true;
                    previousPrice = Double.parseDouble(newProductModel.getMaxRetailCost());
                } else
                    productPrice = Double.parseDouble(newProductModel.getMaxRetailCost());
            } else {
                if (discountedPrice > 0.0) {
                    productPrice = discountedPrice;
                    isDiscountedProduct = true;
                    previousPrice = Double.parseDouble(newProductModel.getMaxWholeSaleCost());
                } else
                    productPrice = Double.parseDouble(newProductModel.getMaxWholeSaleCost());
            }

            if (productPrice != 0) {
                if (isDiscountedProduct) {
                    textView_current_price.setVisibility(View.INVISIBLE);
                    textView_discounted_price.setText(String.format("%s %s", CURRENCY_SYMBOL, productPrice));
                    textView_discounted_price.setVisibility(View.VISIBLE);
                    textView_previous_price.setText(String.format("%s %s", CURRENCY_SYMBOL, previousPrice));
                    textView_previous_price.setPaintFlags(textView_previous_price.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                    textView_previous_price.setVisibility(View.VISIBLE);
                    textView_discountPercent.setText("-" + newProductModel.getDiscountedPercentage() + "%");
                    textView_discountPercent.setVisibility(View.VISIBLE);
                } else {
                    textView_current_price.setText(String.format("%s %s", CURRENCY_SYMBOL, productPrice));
                    textView_discountPercent.setVisibility(View.GONE);
                    specialOfferImage.setVisibility(View.GONE);
                }

            } else {
                textView_current_price.setText(String.format("%s---", CURRENCY_SYMBOL));
            }
            textView_total_price.setText("0.0");

            if (ApplicationData.SETTINGS_RESPONSE.isDisplayStock()) {
                currentStock = Double.parseDouble(newProductModel.getCurrentStock()) - Double.parseDouble(newProductModel.getPendingOrderStock());
                if (currentStock < 1) {
                    txtViewProductStock.setText(R.string.out_of_stock);
                    txtViewProductStock.setTextColor(getResources().getColor(R.color.red));
                } else {
                    txtViewProductStock.setText(String.format("Stock: %s %s", currentStock, newProductModel.getProductUnit()));
                }

            }
            setClientSpecificUi();
        } else {
            showToastMessage(getString(R.string.toast_something_went_wrong));
            finish();
        }
    }

    private void setClientSpecificUi() {
        edit_custom_quantity.setInputType(InputType.TYPE_CLASS_NUMBER);
    }

    private void calculateTotalPrice(double quantity) {
        if (productPrice != 0) {
            double totalPrice = productPrice * quantity;
            textView_total_price.setText(CURRENCY_SYMBOL + " " + getTwoDigitFloatingValue(totalPrice));
        } else {
            showToastMessage("Product price not found");
            return;
        }
    }

    private static String getTwoDigitFloatingValue(double totalPrice) {
        return new DecimalFormat("##.##").format(totalPrice);
    }

    private void addProductToCart() {

        double existingAmount = 0.00;

        String productImageUrl = newProductModel.getImageList().get(0);
        int colorId = 0, sizeId = 0;
        String colorName = "", sizeName = "Medium";

        existingAmount = getExitingAmountFromCart(newProductModel.getProductName(), colorId, sizeId);

        boolean isQuantitiyChangable = true;


        CartModel cartModel = new CartModel(newProductModel.getProductName(), newProductModel.getProductShotName(), newProductModel.getProductId(),
                newProductModel.getProductUnit(), (quantity * 1.00), Double.parseDouble(newProductModel.getMaxBuyingCost()), productPrice, "0.0",
                "00", colorId, colorName, sizeId, sizeName, productImageUrl, isQuantitiyChangable, currentStock
        );

        ApplicationData.CART_MODEL_LIST.add(cartModel);

        showToastMessage(getString(R.string.toast_product_is_added_to_cart));

        updateCartIcon();

    }

    /**
     * This method checks if same product already exists in the cart or not. if exist then it returns
     * existing amount
     *
     * @param productName
     * @param colorId
     * @param sizeId
     * @return existing_amount_in_the_cart
     */

    private double getExitingAmountFromCart(
            String productName,
            int sizeId,
            int colorId) {

        double existingAmount = 0.0;
        int position = -1;
        for (CartModel existingCartModel : ApplicationData.CART_MODEL_LIST) {
            if (productName.equalsIgnoreCase(existingCartModel.getProductName()) && colorId == existingCartModel.getColorId() && sizeId == existingCartModel.getSizeId()) {

                existingAmount = existingCartModel.getSalesAmount();

                ApplicationData.CART_MODEL_LIST.remove(existingCartModel);

                break;
            }
        }

        return existingAmount;
    }

    private boolean isUserLoggedIn() {

        String loginId = prefsValues.getLoginId();
        if (loginId.isEmpty()) {
            return false;
        }
        return true;
    }

    @Override
    public void onNegativeButtonClick(int trackingNumber) {
        switch (trackingNumber) {
            case ApplicationData.TRACK_ALERT_NO_INTERNET:
                this.finishAffinity();
                break;

            case ApplicationData.TRACK_ALERT_LOGIN_AS_GUEST_REQUIRED:
                Intent signInActivityIntent = new Intent(ProductDetailsActivity.this, SignInActivity.class);
                startActivity(signInActivityIntent);
                this.finish();
                break;
            default:
                break;
        }

    }

    @Override
    public void onPositiveButtonClick(int trackingNumber) {
        switch (trackingNumber) {
            case ApplicationData.TRACK_ALERT_LOGIN_AS_GUEST_REQUIRED:
                if (quantity > 0 && productPrice != 0) {
                    this.addProductToCart();
                } else {
                    showToastMessage(getString(R.string.toast_add_quantity));
                }
                prefsValues.setCustomerId(ApplicationData.SETTINGS_RESPONSE.getGuestCustomerId());
                prefsValues.setIsGuestCustomer(true);
                break;
            case ApplicationData.TRACK_ALERT_LOGIN_REQUIRED:
                Intent signInActivityIntent = new Intent(ProductDetailsActivity.this, SignInActivity.class);
                startActivity(signInActivityIntent);
                this.finish();
                break;
            case ApplicationData.TRACK_ALERT_NO_INTERNET:
            case ApplicationData.TRACK_ALERT_NO_STOCK:
                getProductDetails(productId);
                break;

            default:
                break;

        }
    }

    @Override
    protected void onResume() {
        LogMe.i(TAG, "onResume called");

        runOnUiThread(() -> updateCartIcon());

        super.onResume();
    }

    private void updateCartIcon() {
        int count = ApplicationData.CART_MODEL_LIST.size();
        LogMe.i(TAG, "COUNT: " + count);
        if (txtViewCount != null) {
            if (count == 0)
                txtViewCount.setVisibility(View.GONE);
            else {
                txtViewCount.setVisibility(View.VISIBLE);
                txtViewCount.setText("" + count);
            }
        }
    }

    private void goToCartActivity() {
        if (ApplicationData.CART_MODEL_LIST.size() > 0) {
            if (isUserLoggedIn() || prefsValues.getisGuestCustomer()) {
                Intent cartActivityIntent = new Intent(this, CartActivity.class);
                startActivity(cartActivityIntent);
            } else {
                AppUtils.customDialogTwoButtons(this, this, getString(R.string.checkout), getString(R.string.alert_login_as_guest_required_message)
                        , View.GONE, getString(R.string.log_in), getString(R.string.continue_as_guest), R.drawable.vector_info_alertdialog,
                        ApplicationData.TRACK_ALERT_LOGIN_AS_GUEST_REQUIRED
                );
            }
        } else {
            showToastMessage(getString(R.string.toast_empty_cart));
        }
    }

    private void setFavouriteProduct() {

        try {
            if (Connectivity.isConnected(this)) {
                showProgressDialog();
                ApiClient.getApiInterface().setFavouriteProduct(ApplicationData.ACCESS_TOKEN, "" + SESSION_ID,
                        String.valueOf(prefsValues.getCustomerId()), "" + newProductModel.getProductId(), ApplicationData.isTestDb()
                ).enqueue(new Callback<FavouriteResponse>() {
                    @Override
                    public void onResponse(
                            Call<FavouriteResponse> call,
                            Response<FavouriteResponse> response) {
                        hideProgressDialog();
                        FavouriteResponse productResponse = response.body();
                        if (productResponse.getResponse_code() == ApplicationData.SUCCESS_RESPONSE_CODE) {
                            setColorForFav();
                            showToastMessage("Successfully set as Favourite");
                        } else {
                            showToastMessage("" + productResponse.getResponse_code());
                        }
                    }

                    @Override
                    public void onFailure(
                            Call<FavouriteResponse> call,
                            Throwable t) {
                        hideProgressDialog();
                    }
                });

            } else {
                showToastMessage("No Internet Connection");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void deleteFavouriteProduct() {

        try {
            if (Connectivity.isConnected(this)) {

                showProgressDialog();

                ApiClient.getApiInterface().deleteFavoriteProduct(ApplicationData.ACCESS_TOKEN, "" + prefsValues.getCustomerId(),
                        "" + newProductModel.getProductId(), ApplicationData.isTestDb()
                ).enqueue(new Callback<FavouriteResponse>() {
                    @Override
                    public void onResponse(
                            Call<FavouriteResponse> call,
                            Response<FavouriteResponse> response) {

                        hideProgressDialog();
                        FavouriteResponse productResponse = response.body();
                        if (productResponse.getResponse_code() == ApplicationData.SUCCESS_RESPONSE_CODE) {
                            unSelectToFav();
                            showToastMessage("Successfully remove from favourites.");
                        } else {
                            showToastMessage("" + productResponse.getResponse_code());
                        }
                    }

                    @Override
                    public void onFailure(
                            Call<FavouriteResponse> call,
                            Throwable t) {

                        hideProgressDialog();
                    }
                });

            } else {
                showToastMessage("No Internet Connection");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean isFavouriteProduct() {
        return isFavouriteProduct;
    }

    public void setFavouriteProduct(boolean favouriteProduct) {
        isFavouriteProduct = favouriteProduct;
    }
}