package com.framebig.emedicine.model;

/**
 * Created by shamimhossain on 8/25/17.
 */

public enum PlatformType
{
    Unknown, iOS, Android,
}
