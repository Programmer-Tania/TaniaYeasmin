package com.framebig.emedicine.features.recent_product

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.GridLayoutManager
import com.framebig.emedicine.R
import com.framebig.emedicine.databinding.ActivityRecentProductBinding
import com.framebig.emedicine.features.model.ProductModel
import com.framebig.emedicine.features.product_details.ProductDetailsActivity
import com.framebig.emedicine.features.recent_product.adapter.RecentProductListAdapter
import com.framebig.emedicine.features.recent_product.viewmodel.ProductViewModel
import com.framebig.emedicine.utility.AppUtils
import com.framebig.emedicine.utility.ApplicationData
import com.framebig.emedicine.utility.ViewModelFactory
import kotlinx.android.synthetic.main.content_recent_product.*
import java.util.*

class RecentProductActivity : AppCompatActivity(), SearchView.OnQueryTextListener, RecentProductListAdapter.RecyclerCustomItemClickListener {

    private lateinit var productListAdapter: RecentProductListAdapter
    lateinit var bindView: ActivityRecentProductBinding
    lateinit var viewModel: ProductViewModel
    lateinit var searchView: SearchView
    var isOpenSearchView = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bindView = DataBindingUtil.setContentView(this, R.layout.activity_recent_product)
        setSupportActionBar(bindView.toolbar)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)

        isOpenSearchView = intent!!.extras?.get(ApplicationData.IS_OPEN_SEARCH_VIEW) as Boolean

        val numberOfColumns = AppUtils.calculateNoOfColumns(applicationContext)
        recyclerview_recent_product_list.layoutManager = GridLayoutManager(this, numberOfColumns)
        productListAdapter = RecentProductListAdapter(this)
        recyclerview_recent_product_list.adapter = productListAdapter

        val factory = ViewModelFactory(ProductViewModel(this))
        viewModel = ViewModelProviders.of(this, factory).get(ProductViewModel::class.java)
        viewModel.fetchProduct(222)
        viewModel.dataList.observe(this, Observer {
            productListAdapter.setProductModelList(it!! as ArrayList<ProductModel>?)
        })
    }

    override fun getItem(productModel: ProductModel?) {
        goToProductDetailsUI(productModel!!)
    }

    override fun onRowSelected(position: Int) {
    }

    override fun onQueryTextSubmit(s: String?): Boolean {
        productListAdapter.filter.filter(s)
        return false
    }

    override fun onQueryTextChange(s: String?): Boolean {
        productListAdapter.filter.filter(s)
        return false
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_all_product_search, menu)
        val menuItem = menu.findItem(R.id.action_search)
        searchView = menuItem.actionView as SearchView
        val searchManager = getSystemService(Context.SEARCH_SERVICE) as SearchManager
        searchView.setSearchableInfo(searchManager
                .getSearchableInfo(componentName))
        searchView.maxWidth = Int.MAX_VALUE
        searchView.setOnQueryTextListener(this)
        searchView.imeOptions = EditorInfo.IME_ACTION_SEARCH

        if (isOpenSearchView) {
            searchView.setIconifiedByDefault(true);
            searchView.isFocusable = true
            searchView.isIconified = false
            searchView.clearFocus()
            searchView.requestFocusFromTouch()
        }
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                return true
            }
            R.id.action_search -> return super.onOptionsItemSelected(item)
        }
        return super.onOptionsItemSelected(item)
    }

    private fun goToProductDetailsUI(productModel: ProductModel) {
        val intent = Intent(this, ProductDetailsActivity::class.java)

        intent.putExtra("productId", "" + productModel.productId)
        intent.putExtra("productName", productModel.productName)

        ApplicationData.SHARED_MODEL.setSelectedProductName(productModel.productName)
        ApplicationData.SHARED_MODEL.setSelectedProductId(productModel.productId.toString())
        startActivity(intent)
    }
}