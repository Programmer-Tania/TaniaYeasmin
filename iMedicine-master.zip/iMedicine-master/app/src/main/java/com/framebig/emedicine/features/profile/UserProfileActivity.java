package com.framebig.emedicine.features.profile;

import android.app.Activity;
import android.os.Bundle;

import com.google.android.material.textfield.TextInputLayout;

import androidx.appcompat.widget.Toolbar;

import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import com.framebig.emedicine.R;
import com.framebig.emedicine.features.BaseActivity;
import com.framebig.emedicine.features.model.MyProfileUpdateResponse;
import com.framebig.emedicine.retrofit.ApiClient;
import com.framebig.emedicine.utility.AppUtils;
import com.framebig.emedicine.utility.ApplicationData;
import com.framebig.emedicine.utility.Connectivity;
import com.framebig.emedicine.utility.FrameBigApp;
import com.framebig.emedicine.utility.LogMe;
import com.framebig.emedicine.utility.PrefsValues;

import org.json.JSONObject;

import java.net.URLEncoder;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserProfileActivity extends BaseActivity
{

    private TextInputLayout inputLayoutName;
    private TextInputLayout inputLayoutEmail;

    private EditText edtTextLoginId;
    private EditText edtTextFullName;
    private EditText edtTextEmail;
    private EditText edtTextPhoneNumber;
    private EditText editTextDeliveryAddress;
    private EditText editTextBillingAddress;
    private PrefsValues prefsValues;
    private Button btnUpdate;
    private Activity activity;
    private String TAG = getClass().getName();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        initializeUI();
    }

    private void initializeUI()
    {

        activity = this;
        prefsValues = FrameBigApp.getDefaultSharePreference();
        inputLayoutName = findViewById(R.id.input_layout_full_name);
        inputLayoutEmail = findViewById(R.id.input_layout_email);

        edtTextLoginId = findViewById(R.id.edt_profile_loginId);
        edtTextFullName = findViewById(R.id.edt_fullName);
        edtTextEmail = findViewById(R.id.edt_profile_email);
        edtTextPhoneNumber = findViewById(R.id.edt_phone_number);
        editTextDeliveryAddress = findViewById(R.id.editText_deliveryAddress);
        editTextBillingAddress = findViewById(R.id.editText_billingAddress);
        btnUpdate = findViewById(R.id.button_update);

        edtTextLoginId.setText(prefsValues.getLoginId());
        edtTextFullName.setText(prefsValues.getCustomerName());
        edtTextEmail.setText(prefsValues.getCustomerEmail());
        edtTextPhoneNumber.setText(prefsValues.getCustomerPhone());
        editTextBillingAddress.setText(prefsValues.getCustomerBillingAddress());
        editTextDeliveryAddress.setText(prefsValues.getCustomerDeliveryAddress());

        btnUpdate.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                callProfileUpdateAPI();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {

        switch (item.getItemId())
        {
            case android.R.id.home:
                onBackPressed();
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    private class MyTextWatcher implements TextWatcher
    {

        private View view;

        private MyTextWatcher(View view)
        {
            this.view = view;
        }

        public void beforeTextChanged(
                CharSequence charSequence,
                int i,
                int i1,
                int i2)
        {
        }

        public void onTextChanged(
                CharSequence charSequence,
                int i,
                int i1,
                int i2)
        {
        }

        public void afterTextChanged(Editable editable)
        {
            switch (view.getId())
            {
                case R.id.edt_fullName:
                    validateName();
                    break;
                case R.id.edt_profile_email:
                    validateEmail();
                    break;
                case R.id.edt_phone_number:

                    // todo
                    break;
            }
        }
    }

    private void validateName()
    {

    }

    private boolean validateEmail()
    {
        String email = edtTextEmail.getText().toString().trim();

        if (email.isEmpty() || !isValidEmail(email))
        {
            inputLayoutEmail.setError(getString(R.string.err_msg_email));
            requestFocus(inputLayoutEmail);
            return false;
        }
        else
        {
            inputLayoutEmail.setErrorEnabled(false);
        }

        return true;
    }

    private static boolean isValidEmail(String email)
    {
        return !TextUtils.isEmpty(email) && android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    private void requestFocus(View view)
    {
        if (view.requestFocus())
        {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
    }

    private String prepareForRequest(
            String customerId,
            String salutation,
            String fullName,
            String emailId,
            String mobileNo,
            String deliveryAddress,
            String billingAddress)
    {
        try
        {

            JSONObject json = new JSONObject();

            json.put("customerId", customerId);
            json.put("salutation", salutation);
            json.put("fullName", fullName);
            json.put("emailId", emailId);
            json.put("mobileNo", mobileNo);
            json.put("deliveryAddress", deliveryAddress);
            json.put("billingAddress", billingAddress);

            String encodedJsonString = URLEncoder.encode(json.toString(), "UTF-8");
            LogMe.e(TAG, "" + json.toString());
            LogMe.e(TAG, "" + encodedJsonString);

            return encodedJsonString;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return "";
        }
    }

    private void callProfileUpdateAPI()
    {

        try
        {
            if (Connectivity.isConnected(activity))
            {

                showProgressDialog();
                AppUtils.hideKeyboard(activity);

                String profileUpdate = prepareForRequest("" + prefsValues.getCustomerId(), "", edtTextFullName.getText().toString(),
                        edtTextLoginId.getText().toString(), edtTextPhoneNumber.getText().toString(), editTextDeliveryAddress.getText().toString(),
                        editTextBillingAddress.getText().toString());

                ApiClient.getApiInterface().
                        updateCustomerProfile(ApplicationData.ACCESS_TOKEN, profileUpdate, ApplicationData.isTestDb(), ApplicationData.SESSION_ID).enqueue(new Callback<MyProfileUpdateResponse>()
                {
                    @Override
                    public void onResponse(
                            Call<MyProfileUpdateResponse> call,
                            Response<MyProfileUpdateResponse> response)
                    {

                        try
                        {
                            hideProgressDialog();
                            MyProfileUpdateResponse responseObj = response.body();

                            if (responseObj != null && responseObj.getResponseCode() == ApplicationData.SUCCESS_RESPONSE_CODE)
                            {

                                storeCustomerPref(edtTextFullName.getText().toString(), edtTextEmail.getText().toString(),
                                        edtTextPhoneNumber.getText().toString(), editTextBillingAddress.getText().toString(),
                                        editTextDeliveryAddress.getText().toString());
                                showToastMessage(responseObj.getResponse().getMsg());

                            }
                            else if (responseObj != null && responseObj.getResponseCode() == ApplicationData.INVALID_LOGIN_ID)
                            {

                                showToastMessage(responseObj.getResponse().getMsg());

                            }
                            else if (responseObj != null && responseObj.getResponseCode() == ApplicationData.VERIFICATION_REQUIRED_RESPONSE_CODE)
                            {
                                showToastMessage(responseObj.getResponse().getMsg());

                            }
                            else
                            {
                                showToastMessage(responseObj.getResponse().getMsg());
                                Log.e(TAG, responseObj.getResponse().toString());
                            }

                        }
                        catch (Exception e)
                        {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onFailure(
                            Call<MyProfileUpdateResponse> call,
                            Throwable t)
                    {

                        hideProgressDialog();

                    }
                });
            }
            else
            {
                showToastMessage(getString(R.string.no_internet_connection));
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    private void storeCustomerPref(
            String customerName,
            String email,
            String phone,
            String billingAddress,
            String deliveryAddress)
    {

        prefsValues.setCustomerName(customerName);
        prefsValues.setCustomerPhone(phone);
        prefsValues.setCustomerEmail(email);
        prefsValues.setCustomerDeliveryAddress(deliveryAddress);
        prefsValues.setCustomerBillingAddress(billingAddress);

    }
    /*{
        "customerId": "27",
            "salutation": "Mr",
            "fullName": "TestFullName",
            "emailId": "shobuz_iiuc@yahoo.com",
            "mobileNo": "0152106534242",
            "deliveryAddress": "BankTown, Dhaka",
            "billingAddress": "Savar, Dhaka"
    }*/
}
