

package com.framebig.emedicine.features.model;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SettingsModel implements Serializable
{

    @SerializedName("response_code")
    @Expose
    private int responseCode;
    @SerializedName("response")
    @Expose
    private SettingsResponse response;
    @SerializedName("status")
    @Expose
    private String status;
    private final static long serialVersionUID = -4232825097558093914L;

    /**
     * No args constructor for use in serialization
     */
    public SettingsModel()
    {
    }

    /**
     * @param response
     * @param responseCode
     * @param status
     */
    public SettingsModel(
            int responseCode,
            SettingsResponse response,
            String status)
    {
        super();
        this.responseCode = responseCode;
        this.response = response;
        this.status = status;
    }

    public int getResponseCode()
    {
        return responseCode;
    }

    public void setResponseCode(int responseCode)
    {
        this.responseCode = responseCode;
    }

    public SettingsResponse getResponse()
    {
        return response;
    }

    public void setResponse(SettingsResponse response)
    {
        this.response = response;
    }

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

}