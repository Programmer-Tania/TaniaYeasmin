package com.framebig.emedicine.features.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ProductCategory(

	@field:SerializedName("name")
	val name: String? = null,

	@field:SerializedName("bangla_name")
	val banglaName: String? = null,

	@field:SerializedName("id")
	val id: Int? = null,

	@field:SerializedName("slug")
	val slug: String? = null,

	@field:SerializedName("parent_id")
	val parentId: String? = null,

	@field:SerializedName("childs")
	val childs: List<SubCategory>? = null
) : Parcelable