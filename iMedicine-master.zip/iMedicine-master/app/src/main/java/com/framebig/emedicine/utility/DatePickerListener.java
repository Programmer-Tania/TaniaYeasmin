package com.framebig.emedicine.utility;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.Bundle;

import androidx.fragment.app.DialogFragment;

import android.widget.DatePicker;

public class DatePickerListener extends DialogFragment implements DatePickerDialog.OnDateSetListener
{
    public int year, month, day;

    public DatePickerListener()
    {

    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState)
    {

        // Create a new instance of DatePickerDialog and return it
        return new DatePickerDialog(getActivity(), this, this.getYear(), this.getMonth(), this.getDay());
    }

    @Override
    public void onDateSet(
            DatePicker view,
            int year,
            int month,
            int day)
    {
        //		Calendar c = Calendar.getInstance();
        //		c.set(year, month, day);

        this.setYear(year);
        this.setMonth(month);
        this.setDay(day);
    }

    public int getYear()
    {
        return year;
    }

    public void setYear(int year)
    {
        this.year = year;
    }

    public int getMonth()
    {
        return month;
    }

    public void setMonth(int month)
    {
        this.month = month;
    }

    public int getDay()
    {
        return day;
    }

    public void setDay(int day)
    {
        this.day = day;
    }
}
