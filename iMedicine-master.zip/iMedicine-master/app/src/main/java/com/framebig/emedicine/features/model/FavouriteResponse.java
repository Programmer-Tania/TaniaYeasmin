package com.framebig.emedicine.features.model;

public class FavouriteResponse
{

    private Response response;

    private String status;

    private int response_code;

    public Response getResponse()
    {
        return response;
    }

    public void setResponse(Response response)
    {
        this.response = response;
    }

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

    public int getResponse_code()
    {
        return response_code;
    }

    public void setResponse_code(int response_code)
    {
        this.response_code = response_code;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [response = " + response + ", status = " + status + ", response_code = " + response_code + "]";
    }
}