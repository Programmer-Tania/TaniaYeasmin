package com.framebig.emedicine.utility;

import android.content.Context;
import android.graphics.Rect;
import android.view.View;

import com.framebig.emedicine.features.home.ProductCategoryAdapter;
import com.framebig.emedicine.features.product_list.ProductListAdapter;

import androidx.annotation.DimenRes;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ItemOffsetDecoration extends RecyclerView.ItemDecoration
{

    private int mItemOffset;

    public ItemOffsetDecoration(int itemOffset)
    {
        mItemOffset = itemOffset;
    }

    public ItemOffsetDecoration(
            @NonNull Context context,
            @DimenRes int itemOffsetId)
    {
        this(context.getResources().getDimensionPixelSize(itemOffsetId));
    }

    @Override
    public void getItemOffsets(
            Rect outRect,
            View view,
            RecyclerView parent,
            RecyclerView.State state)
    {

        super.getItemOffsets(outRect, view, parent, state);
        int position = parent.getChildAdapterPosition(view);
        int viewType = parent.getAdapter().getItemViewType(position);
        if (viewType == ProductCategoryAdapter.GRID_ITEM || viewType == ProductListAdapter.GRID_ITEM)
        {
            outRect.set(mItemOffset, mItemOffset, mItemOffset, mItemOffset);
        }
        else
        {
            outRect.set(mItemOffset / 2, mItemOffset / 2, mItemOffset / 2, mItemOffset / 2);
        }
    }
}
