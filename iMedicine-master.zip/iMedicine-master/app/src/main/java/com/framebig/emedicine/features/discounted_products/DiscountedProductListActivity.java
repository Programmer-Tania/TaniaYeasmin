package com.framebig.emedicine.features.discounted_products;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;

import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.framebig.emedicine.R;
import com.framebig.emedicine.features.BaseActivity;
import com.framebig.emedicine.features.cart.cart_item.CartActivity;
import com.framebig.emedicine.features.product_details.ProductDetailsActivity;
import com.framebig.emedicine.features.sign_in.SignInActivity;
import com.framebig.emedicine.retrofit.ApiClient;
import com.framebig.emedicine.utility.AlertDialogTwoButton.ButtonClickListener;
import com.framebig.emedicine.utility.AppUtils;
import com.framebig.emedicine.utility.ApplicationData;
import com.framebig.emedicine.utility.Connectivity;
import com.framebig.emedicine.utility.FrameBigApp;
import com.framebig.emedicine.utility.ItemOffsetDecoration;
import com.framebig.emedicine.utility.LogMe;
import com.framebig.emedicine.utility.PrefsValues;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DiscountedProductListActivity extends BaseActivity implements SearchView.OnQueryTextListener,
        DiscountedProductListAdapter.RecyclerCustomItemClickListener, ButtonClickListener
{

    private RecyclerView recyclerview_product_list;
    private DiscountedProductListAdapter discountedProductListAdapter;

    private DiscountedProductListActivity discountedproductListActivity = this;
    private String TAG = DiscountedProductListActivity.class.getSimpleName();
    private TextView txtViewCount;
    private TextView txtEmptyView;
    private PrefsValues prefsValues;
    private FloatingActionButton fab_list;
    private FloatingActionButton fab_grid;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list);
        initializeUI();
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        LogMe.i(TAG, "onResume called");

        runOnUiThread(() -> {
            int count = ApplicationData.CART_MODEL_LIST.size();
            LogMe.i(TAG, "COUNT: " + count);
            if (txtViewCount != null)
            {
                if (count == 0) txtViewCount.setVisibility(View.GONE);
                else
                {
                    txtViewCount.setVisibility(View.VISIBLE);
                    txtViewCount.setText("" + count);
                }
            }
        });
    }

    private void initializeUI()
    {

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        View notifications = findViewById(R.id.notifications);
        txtViewCount = notifications.findViewById(R.id.txtCount);
        notifications.setOnClickListener(v -> goToCartActivity());
        fab_list = findViewById(R.id.fab_switch_list);
        fab_grid = findViewById(R.id.fab_switch_grid);
        fab_grid.setOnClickListener(v -> switchLayout());
        fab_list.setOnClickListener(v -> switchLayout());

        recyclerview_product_list = findViewById(R.id.recyclerview_product_list);
        ItemOffsetDecoration itemDecoration = new ItemOffsetDecoration(this, R.dimen.sixteen_dp);
        recyclerview_product_list.addItemDecoration(itemDecoration);

        if (ApplicationData.SETTINGS_RESPONSE.getDefaultlayout().equalsIgnoreCase("GRID"))
        {
            discountedProductListAdapter.isSwitchView = false;
            recyclerview_product_list.setLayoutManager(new GridLayoutManager(this, 2));
            fab_grid.setVisibility(View.INVISIBLE);
            fab_list.setVisibility(View.VISIBLE);
        }
        else
        {
            discountedProductListAdapter.isSwitchView = true;
            recyclerview_product_list.setLayoutManager(new LinearLayoutManager(this));
            fab_list.setVisibility(View.INVISIBLE);
            fab_grid.setVisibility(View.VISIBLE);
        }

        prefsValues = FrameBigApp.getDefaultSharePreference();

        if (ApplicationData.DISCOUNT_PRODUCT_LIST.size() < 1)
        {
            getDiscountedProductList();
        }
        else
        {
            setProductCategoryAdapter();
        }

        getSupportActionBar().setTitle("Discounted Products");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        txtEmptyView = findViewById(R.id.txtEmptyView);
    }

    private void switchLayout()
    {
        if (fab_grid.getVisibility() == View.VISIBLE)
        {
            fab_grid.setVisibility(View.INVISIBLE);
            fab_list.setVisibility(View.VISIBLE);
        }
        else if (fab_list.getVisibility() == View.VISIBLE)
        {
            fab_list.setVisibility(View.INVISIBLE);
            fab_grid.setVisibility(View.VISIBLE);
        }
        boolean isSwitched = discountedProductListAdapter.toggleItemViewType();
        recyclerview_product_list.setLayoutManager(isSwitched ? new LinearLayoutManager(this) : new GridLayoutManager(this, 2));
        discountedProductListAdapter.notifyDataSetChanged();
    }

    private void goToCartActivity()
    {
        if (ApplicationData.CART_MODEL_LIST.size() > 0)
        {
            if (isUserLoggedIn() || prefsValues.getisGuestCustomer())
            {
                Intent cartActivityIntent = new Intent(this, CartActivity.class);
                startActivity(cartActivityIntent);
            }
            else
            {
                AppUtils.customDialogTwoButtons(this, this, getString(R.string.checkout), getString(R.string.alert_login_as_guest_required_message)
                        , View.GONE, getString(R.string.log_in), getString(R.string.continue_as_guest), R.drawable.vector_info_alertdialog,
                        ApplicationData.TRACK_ALERT_LOGIN_AS_GUEST_REQUIRED);
            }
        }
        else
        {
            showToastMessage(getString(R.string.toast_empty_cart));
        }
    }

    private boolean isUserLoggedIn()
    {
        String loginId = prefsValues.getLoginId();
        if (loginId.isEmpty())
        {
            return false;
        }
        return true;
    }

    private void goToProductDetailsUI(int position)
    {
        Intent intent = new Intent(discountedproductListActivity, ProductDetailsActivity.class);
        Gson gson = new Gson();

        String object = gson.toJson(ApplicationData.PRODUCT_MODEL_LIST.get(position));
        intent.putExtra(ApplicationData.PRODUCT_OBJECT, object);

        startActivity(intent);
    }

    private void goToProductDetailsUI(DiscountResponseItem productModel)
    {
        Intent intent = new Intent(discountedproductListActivity, ProductDetailsActivity.class);
        intent.putExtra("productId", "" + productModel.getProductId());
        intent.putExtra("productName", productModel.getProductName());

        ApplicationData.SHARED_MODEL.setSelectedProductId(String.valueOf(productModel.getProductId()));
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu_service_sub_category, menu);
        MenuItem menuItem = menu.findItem(R.id.action_search);

        SearchView searchView = (SearchView) menuItem.getActionView();

        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);

        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setMaxWidth(Integer.MAX_VALUE);

        searchView.setOnQueryTextListener(this);
        searchView.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case android.R.id.home:
                onBackPressed();
                return true;
            case R.id.action_search:
                return super.onOptionsItemSelected(item);
        }
        return super.onOptionsItemSelected(item);
    }

    private void getDiscountedProductList()
    {
        try
        {
            if (Connectivity.isConnected(discountedproductListActivity))
            {
                showProgressDialog();
                ApiClient.getApiInterface().getDiscountedProducts(
                        ApplicationData.getCompanyID(),
                        ApplicationData.ACCESS_TOKEN,
                        ApplicationData.isTestDb()).enqueue(new Callback<DiscountResponse>()
                {
                    @Override
                    public void onResponse(
                            Call<DiscountResponse> call,
                            Response<DiscountResponse> response)
                    {
                        hideProgressDialog();
                        LogMe.i(TAG, "" + response.body().toString());

                        DiscountResponse discountResponse = response.body();
                        if (discountResponse.getResponseCode() == ApplicationData.SUCCESS_RESPONSE_CODE)
                        {
                            ApplicationData.DISCOUNT_PRODUCT_LIST.clear();
                            ApplicationData.DISCOUNT_PRODUCT_LIST = discountResponse.getResponse();
                            if (ApplicationData.DISCOUNT_PRODUCT_LIST.size() < 1)
                            {
                                txtEmptyView.setVisibility(View.VISIBLE);
                            }

                            setProductCategoryAdapter();
                        }
                        else
                        {
                            showToastMessage("" + discountResponse.getResponseCode());
                        }
                    }

                    @Override
                    public void onFailure(
                            Call<DiscountResponse> call,
                            Throwable t)
                    {
                        hideProgressDialog();
                        t.printStackTrace();
                    }
                });
            }
            else
            {
                AppUtils.customDialogTwoButtons(this, this, getString(R.string.alert_no_internet_title),
                        getString(R.string.alert_no_interner_message), View.GONE, getString(R.string.alert_no_internet_exit),
                        getString(R.string.alert_no_internet_retry), R.drawable.vector_info_alertdialog, ApplicationData.TRACK_ALERT_NO_INTERNET);
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    private void setProductCategoryAdapter()
    {
        discountedProductListAdapter = new DiscountedProductListAdapter(ApplicationData.DISCOUNT_PRODUCT_LIST, this);
        recyclerview_product_list.setAdapter(discountedProductListAdapter);
        discountedProductListAdapter.notifyDataSetChanged();
    }

    @Override
    public boolean onQueryTextSubmit(String s)
    {
        discountedProductListAdapter.getFilter().filter(s);
        return false;
    }

    @Override
    public boolean onQueryTextChange(String s)
    {

        discountedProductListAdapter.getFilter().filter(s);
        return false;
    }

    @Override
    public void onRowSelected(int position)
    {
    }

    @Override
    public void getItem(DiscountResponseItem productModel)
    {
        goToProductDetailsUI(productModel);
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        ApplicationData.DISCOUNT_PRODUCT_LIST.clear();
    }

    @Override
    public void onNegativeButtonClick(int trackingNumber)
    {
        switch (trackingNumber)
        {
            case ApplicationData.TRACK_ALERT_NO_INTERNET:
                this.finishAffinity();
                break;
            case ApplicationData.TRACK_ALERT_LOGIN_AS_GUEST_REQUIRED:
                Intent signInActivityIntent = new Intent(this, SignInActivity.class);
                startActivity(signInActivityIntent);
                this.finish();
                break;
            default:
                break;
        }
    }

    @Override
    public void onPositiveButtonClick(int trackingNumber)
    {
        switch (trackingNumber)
        {
            case ApplicationData.TRACK_ALERT_NO_INTERNET:
                getDiscountedProductList();
                break;
            case ApplicationData.TRACK_ALERT_LOGIN_AS_GUEST_REQUIRED:
                prefsValues.setCustomerId(0);
                prefsValues.setIsGuestCustomer(true);
                Intent cartActivityIntent = new Intent(this, CartActivity.class);
                startActivity(cartActivityIntent);
                this.finish();
                break;
            default:
                break;
        }
    }
}