package com.framebig.emedicine.features.model;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class ProductDetailsResponse
{

    @SerializedName("response_code")
    private int responseCode;

    @SerializedName("response")
    private List<ProductModel> productModelList;

    @SerializedName("status")
    private String status;

    public void setResponseCode(int responseCode)
    {
        this.responseCode = responseCode;
    }

    public int getResponseCode()
    {
        return responseCode;
    }

    public void setProductModelList(List<ProductModel> productModelList)
    {
        this.productModelList = productModelList;
    }

    public List<ProductModel> getProductModelList()
    {
        return productModelList;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

    public String getStatus()
    {
        return status;
    }

    @Override
    public String toString()
    {
        return "ProductDetailsResponse{" + "response_code = '" + responseCode + '\'' + ",response = '" + productModelList + '\'' + ",status = '" + status + '\'' + "}";
    }
}