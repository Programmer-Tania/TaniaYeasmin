package com.framebig.emedicine.features.cart.cart_item;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.framebig.emedicine.R;
import com.framebig.emedicine.features.model.CartModel;
import com.framebig.emedicine.utility.ApplicationData;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class CartRecyclerAdapter extends RecyclerView.Adapter<CartRecyclerAdapter.MyViewHolder>
{

    private ArrayList<CartModel> cartList;
    private CartContract cartContract;

    public CartRecyclerAdapter(
            Context context,
            ArrayList<CartModel> cartList)
    {
        this.cartList = cartList;
        this.cartContract = (CartContract) context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(
            @NonNull ViewGroup viewGroup,
            int i)
    {

        View itemView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cart_item, viewGroup, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(
            @NonNull MyViewHolder myViewHolder,
            final int position)
    {

        final CartModel cartModel = cartList.get(position);
        String productInfo = "";

        String productColor = cartModel.getColorName().length() > 0 ? "Color: " + cartModel.getColorName() + ", " : "";
        String productSize = cartModel.getSizeName().length() > 0 ? "Size: " + cartModel.getSizeName() + ", " : "";

        String productUnit = "Unit: " + cartModel.getUnitName() + ", ";

        String unitPrice = "Price/Unit: " + cartModel.getUnitSellingPrice();

        //productInfo = productInfo + productSize + productColor + productUnit + unitPrice;
        productInfo = productUnit + unitPrice;

        myViewHolder.txtProductName.setText(cartModel.getProductName());
        myViewHolder.txtProductInfo.setText(productInfo);
        Picasso.get().load(cartModel.getImageUrl()).error(R.drawable.image_not_found).placeholder(R.drawable.image_not_found).resize(350, 350).into(myViewHolder.imgProduct);

        myViewHolder.txtQuantity.setText("" + cartModel.getSalesAmount());

        if (!cartModel.isQuantityChangable())
        {
            myViewHolder.relative_amount.setVisibility(View.GONE);
            myViewHolder.textView_quantity_hidden.setText("Quantity: " + cartModel.getSalesAmount() + " " + cartModel.getUnitName());
        }

        setTotalPrice(myViewHolder, cartModel);

        myViewHolder.btnDecrease.setOnClickListener(view -> {
            if (cartModel.getSalesAmount() > 1)
            {
                cartContract.decreaseAmount(cartModel, position);
                setTotalPrice(myViewHolder, cartModel);
            }
            else
            {
                cartContract.deleteCartItem(cartModel);
            }
        });

        myViewHolder.btnIncrease.setOnClickListener(view -> {
            cartContract.increaseAmount(cartModel, position);
            setTotalPrice(myViewHolder, cartModel);
        });

        /*myViewHolder.imgDeleteItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cartContract.deleteCartItem(cartModel);
            }
        });*/
    }

    private String setTotalPrice(
            MyViewHolder myViewHolder,
            CartModel cartModel)
    {
        String totalPrice =
                ApplicationData.SETTINGS_RESPONSE.getCurrencySymbol() + " " + cartModel.getSalesAmount() * cartModel.getUnitSellingPrice();
        myViewHolder.txtProductTotalPrice.setText(totalPrice);
        return totalPrice;
    }

    @Override
    public int getItemCount()
    {
        return cartList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder
    {

        private TextView txtProductName, txtProductInfo, txtProductTotalPrice, txtQuantity, textView_quantity_hidden;
        private ImageView btnDecrease, btnIncrease;
        private ImageView imgProduct, imgDeleteItem;
        private LinearLayout relative_amount;

        public MyViewHolder(@NonNull View itemView)
        {
            super(itemView);

            txtProductName = itemView.findViewById(R.id.textView_ProductName);
            txtProductInfo = itemView.findViewById(R.id.textView_product_info);
            txtProductTotalPrice = itemView.findViewById(R.id.textView_totalProductPrice);
            txtQuantity = itemView.findViewById(R.id.textView_quantity);
            btnDecrease = itemView.findViewById(R.id.btn_decrease);
            btnIncrease = itemView.findViewById(R.id.btn_increase);
            imgProduct = itemView.findViewById(R.id.imageView_Product);
            //imgDeleteItem = itemView.findViewById(R.id.imageView_deleteItem);
            relative_amount = itemView.findViewById(R.id.relative_amount);
            textView_quantity_hidden = itemView.findViewById(R.id.textView_quantity_hidden);
        }
    }

    public void removeItem(int position)
    {
        cartList.remove(position);
        notifyItemRemoved(position);
    }

    public void restoreItem(
            CartModel item,
            int position)
    {
        cartList.add(position, item);
        notifyItemInserted(position);
    }

    public ArrayList<CartModel> getData()
    {
        return cartList;
    }
}
