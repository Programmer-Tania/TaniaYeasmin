package com.framebig.emedicine.utility

enum class RecyclerType {
    GRID,
    LIST
}