package com.framebig.emedicine.database.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.framebig.emedicine.database.dao.RecentProductDao
import com.framebig.emedicine.features.model.DataConverter
import com.framebig.emedicine.features.model.ProductModel
import com.framebig.emedicine.features.model.StringListConverter

@Database(entities = [ProductModel::class], version = 1)
@TypeConverters(DataConverter::class, StringListConverter::class)
abstract class FramebigDatabase : RoomDatabase() {

    abstract fun recentProductDao(): RecentProductDao

    companion object {
        val DATABASE_NAME: String = "framebig_db"
        private var instance: FramebigDatabase? = null

        fun getInstance(context: Context): FramebigDatabase {
            if (instance == null) {
                instance = Room.databaseBuilder(
                        context, FramebigDatabase::class.java, DATABASE_NAME
                ).addCallback(roomCallback).build()
            }
            return instance!!
        }

        private val roomCallback = object : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
            }
        }
    }
}