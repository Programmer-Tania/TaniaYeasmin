package com.framebig.emedicine.model;

/**
 * Created by shamimhossain on 8/25/17.
 */

public enum GenderType
{
    Undefined, Male, Female, Other;

    public static GenderType getGenderTypeFromInteger(Integer value)
    {
        if (value == Undefined.ordinal())
        {
            return Undefined;
        }
        else if (value == Male.ordinal())
        {
            return Male;
        }
        else if (value == Female.ordinal())
        {
            return Female;
        }
        else
        {
            return Other;
        }
    }
}
