package com.framebig.emedicine.utility;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

public class PrefsValues
{

    public static final String MY_SHARED_PREF = "my_shared_pref";
    public static final String LOGIN_ID = "login_id";
    public static final String PASSWORD = "password";
    public static final String CUSTOMER_ID = "customer_id";
    public static final String CUSTOMER_NAME = "customer_name";
    public static final String CUSTOMER_PHONE = "customer_phone";
    public static final String CUSTOMER_DELIVERY_ADDRESS = "customer_delivary_address";
    public static final String CUSTOMER_BILLING_ADDRESS = "customer_billing_address";
    public static final String CUSTOMER_EMAIL = "customer_email";
    public static final String FIREBASE_TOKEN = "firebase_token";
    public static final String CUSTOMER_AREA = "customer_area";
    public static final String CUSTOMER_TYPE = "customer_type";

    public static final String BRANCH_ID = "BRANCH_ID";
    public static final String COMPANY_ID = "COMPANY_ID";
    public static final String COMPANY_NAME = "COMPANY_NAME";
    public static final String IS_TEST_DB = "IS_TEST_DB";
    public static final String IS_DEVELOPER_MODE_ENABLE = "IS_DEVELOPER_MODE_ENABLE";
    public static final String PRODUCT_UPDATE_CHECK = "PRODUCT_UPDATE_CHECK";
    public static final boolean IS_GUEST_CUSTOMER = false;

    public static PrefsValues defaultPreferences = new PrefsValues();

    public PrefsValues()
    {

        mPrefs = FrameBigApp.getApplication().
                getSharedPreferences(ApplicationData.APP_NAME, Context.MODE_PRIVATE);
        // mEditor = mPrefs.edit();
    }

    public static PrefsValues getDefaultPreferences()
    {
        return defaultPreferences;
    }

    private SharedPreferences mPrefs;

    private Context context = null;
    private Activity activity;
    // private SharedPreferences.Editor mEditor;

    public PrefsValues(
            Context context,
            String name,
            int mode)
    {
        mPrefs = context.getSharedPreferences(name, mode);
    }

    public void clearSharedPref(String key)
    {

        // mEditor.remove(key);
        //mEditor.apply();
        mPrefs.edit().remove(key).apply();
    }

    public String getFirebasebaseTokeId()
    {
        return mPrefs.getString(FIREBASE_TOKEN, "");
    }

    public void setFirebasebaseTokeId(String firebaseTokeId)
    {

        mPrefs.edit().putString(FIREBASE_TOKEN, firebaseTokeId).apply();
    }

    public String getLoginId()
    {
        return mPrefs.getString(LOGIN_ID, "");
    }

    public void setLoginId(String loginId)
    {
        mPrefs.edit().putString(LOGIN_ID, loginId).apply();
    }

    public String getPassword()
    {
        return mPrefs.getString(PASSWORD, "");
    }

    public void setPassword(String password)
    {
        mPrefs.edit().putString(PASSWORD, password).apply();
    }

    public int getCustomerId()
    {
        return mPrefs.getInt(CUSTOMER_ID, 0);
    }

    public void setCustomerId(int customerId)
    {
        mPrefs.edit().putInt(CUSTOMER_ID, customerId).apply();
    }

    public boolean getisGuestCustomer()
    {
        return mPrefs.getBoolean(String.valueOf(IS_GUEST_CUSTOMER), Boolean.parseBoolean(""));
    }

    public void setIsGuestCustomer(boolean isGuestCustomer)
    {
        mPrefs.edit().putBoolean(String.valueOf(IS_GUEST_CUSTOMER), isGuestCustomer).apply();
    }

    public String getCustomerName()
    {
        return mPrefs.getString(CUSTOMER_NAME, "");
    }

    public void setCustomerName(String customerName)
    {
        mPrefs.edit().putString(CUSTOMER_NAME, customerName).apply();
    }

    public String getCustomerPhone()
    {
        return mPrefs.getString(CUSTOMER_PHONE, "");
    }

    public void setCustomerPhone(String customerPHONE)
    {
        mPrefs.edit().putString(CUSTOMER_PHONE, customerPHONE).apply();
    }

    public String getCustomerBillingAddress()
    {
        return mPrefs.getString(CUSTOMER_BILLING_ADDRESS, "");
    }

    public void setCustomerBillingAddress(String customerPHONE)
    {
        mPrefs.edit().putString(CUSTOMER_BILLING_ADDRESS, customerPHONE).apply();
    }

    public String getCustomerDeliveryAddress()
    {
        return mPrefs.getString(CUSTOMER_DELIVERY_ADDRESS, "");
    }

    public void setCustomerDeliveryAddress(String deliveryAddress)
    {
        mPrefs.edit().putString(CUSTOMER_DELIVERY_ADDRESS, deliveryAddress).apply();
    }

    public String getCustomerEmail()
    {
        return mPrefs.getString(CUSTOMER_EMAIL, "");
    }

    public void setCustomerEmail(String customerPHONE)
    {
        mPrefs.edit().putString(CUSTOMER_EMAIL, customerPHONE).apply();
    }

    public String getString(String key)
    {
        return mPrefs.getString(key, null);
    }

    public void putString(
            String key,
            String value)
    {
        this.mPrefs.edit().putString(key, value).apply();
    }

    public String getStringWithDefault(
            String key,
            String defaultValue)
    {
        return this.mPrefs.getString(key, defaultValue);
    }

    public long getLong(String key)
    {
        return this.mPrefs.getLong(key, 0);
    }

    public void setLong(
            String key,
            long value)
    {
        this.mPrefs.edit().putLong(key, value).apply();
    }

    public int getIntWithDefault(
            String key,
            int defaultValue)
    {
        return this.mPrefs.getInt(key, defaultValue);
    }

    public void putInteger(
            String key,
            int value)
    {
        this.mPrefs.edit().putInt(key, value).apply();
    }

    public boolean getBoolean(String key)
    {

        return this.mPrefs.getBoolean(key, false);
    }

    public void putBoolean(
            String key,
            boolean value)
    {
        this.mPrefs.edit().putBoolean(key, value).apply();
    }

    private void removeIfValueIsNUll(
            String key,
            Object value)
    {
        if (value == null)
        {
            this.remove(key);
        }
    }

    public void remove(String key)
    {
        this.mPrefs.edit().remove(key).apply();
    }

}