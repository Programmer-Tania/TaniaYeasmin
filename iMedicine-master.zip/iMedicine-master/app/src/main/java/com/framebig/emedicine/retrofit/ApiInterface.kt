package com.framebig.emedicine.retrofit

import com.framebig.emedicine.features.best_selling.BestSellingProductResponse
import com.framebig.emedicine.features.cart.delivery_information.PaymentAPIResponse
import com.framebig.emedicine.features.change_password.ChangePasswordResponse
import com.framebig.emedicine.features.discounted_products.DiscountResponse
import com.framebig.emedicine.features.favourite.GetFavouriteResponse
import com.framebig.emedicine.features.model.*
import retrofit2.Call
import retrofit2.http.*

/**
 * Created by @Shihab on 11/25/2016.
 */
interface ApiInterface {
    @GET("/v1.2/me/")
    fun getPhoneNUmber(
            @Query("access_token") access_token: String?,
            @Query("appsecret_proof") appsecret_proof: String?): Call<FacebookResponse?>?

    @GET("api/category")
    fun getProductCategory(
            @Query("accessToken") accessToken: String?,
            @Query("companyId") companyId: String?,
            @Query("isTestDb") isTestDb: Boolean): Call<ProductCategoryResponse>?

    @GET("productapi/getCategoryWiseProducts?")
    fun getProductListByCategory(
            @Query("accessToken") accessToken: String?,
            @Query("companyId") companyId: String?,
            @Query("categoryId") categoryId: String?,
            @Query("isTestDb") isTestDb: Boolean): Call<ProductModel?>?

    @GET("productapi/getProductDetails?")
    fun getProductDetails(
            @Query("companyId") companyId: String?,
            @Query("accessToken") accessToken: String?,
            @Query("isTestDb") isTestDb: Boolean,
            @Query("productId") productId: String?): Call<ProductDetailsResponse>?

    @GET("orderapi/getOrders?")
    fun getOrders(
            @Query("accessToken") accessToken: String?,
            @Query("sessionId") sessionId: String?,
            @Query("companyId") companyId: String?,
            @Query("customerId") customerId: Int,
            @Query("isTestDb") isTestDb: Boolean): Call<OrderListModel?>?

    @GET("orderapi/getOrderDetails?")
    fun getOrderDetails(
            @Query("accessToken") accessToken: String?,
            @Query("isTestDb") isTestDb: Boolean,
            @Query("sessionId") sessionId: String?,
            @Query("companyId") companyId: String?,
            @Query("customerId") customerId: Int,
            @Query("orderNo") orderNo: String?
    ): Call<OrderDetailsResponse>

    @POST("orderapi/placeOrder")
    fun placeOrder(
            @Query("accessToken") accessToken: String?,
            @Query("sessionId") sessionId: String?,
            @Query("companyId") companyId: String?,
            @Query("branchId") branchId: Int,
            @Query("customerId") customerId: Int,
            @Query("orderNo") orderNo: String?,
            @Query("orderItemList") orderItemList: String?,
            @Query("discountedTotalBill") discountedTotalBill: String?,
            @Query("discountedTotalVat") discountedTotalVat: String?,
            @Query("deliveryAddress") deliveryAddress: String?,
            @Query("billingAddress") billingAddress: String?,
            @Query("expectedDeliveryDate") expectedDeliveryDate: String?,
            @Query("paymentMethod") paymentMethod: String?,
            @Query("shippingMethod") shippingMethod: String?,
            @Query("shippingCharge") shippingCharge: String?,
            @Query("isGuestCustomer") isGuestCustomer: Boolean?,
            @Query("isTestDb") isTestDb: Boolean): Call<PlaceOrderResponseModel>

    @POST("customerapi/login")
    fun login(
            @Query("accessToken") accessToken: String?,
            @Query("fcmToken") fcmToken: String?,
            @Query("loginData") loginData: String?,
            @Query("isTestDb") isTestDb: Boolean): Call<LoginResponseModel>

    @POST("customerapi/registration")
    fun registration(
            @Query("accessToken") accessToken: String?,
            @Query("registrationData") registrationData: String?,
            @Query("isTestDb") isTestDb: Boolean): Call<RegistrationResponseModel>

    @PUT("customerapi/verifyCustomerAuthCode")
    fun verifyCustomerAuthCode(
            @Query("accessToken") accessToken: String?,
            @Query("loginId") loginId: String?,
            @Query("verificationCode") authorizationCode: Int,
            @Query("isTestDb") isTestDb: Boolean): Call<AuthResponseModel>

    @PUT("customerapi/updateFcmToken")
    fun updateFcmTokenForCustomer(
            @Query("accessToken") accessToken: String?,
            @Query("customerId") customerId: Int,
            @Query("fcmTokenId") fcmTokenId: String?,
            @Query("isTestDb") isTestDb: Boolean): Call<FcmResponseModel>

    @PUT("customerapi/updateCustomerProfile")
    fun updateCustomerProfile(
            @Query("accessToken") accessToken: String?,
            @Query("profileData") profileData: String?,
            @Query("isTestDb") isTestDb: Boolean,
            @Query("sessionId") sessionId: String?
    ): Call<MyProfileUpdateResponse?>?

    @PUT("customerapi/resetCustomerLoginPassword")
    fun resetCustomerLoginPassword(
            @Query("accessToken") accessToken: String?,
            @Query("loginId") loginId: String?,
            @Query("fullName") fullName: String?,
            @Query("isTestDb") isTestDb: Boolean): Call<RecoverPasswordResponse?>?

    @PUT("customerapi/changeCustomerPassword")
    fun changeCustomerPassword(
            @Query("accessToken") accessToken: String?,
            @Query("customerId") customerId: String?,
            @Query("newPassword") newPassword: String?,
            @Query("isTestDb") isTestDb: Boolean
    ): Call<ChangePasswordResponse?>?

    @POST("customerapi/setFavoriteProduct")
    fun setFavouriteProduct(
            @Query("accessToken") accessToken: String?,
            @Query("sessionId") sessionId: String?,
            @Query("customerId") customerId: String?,
            @Query("productId") productId: String?,
            @Query("isTestDb") isTestDb: Boolean): Call<FavouriteResponse?>?

    @DELETE("customerapi/deleteFavoriteProduct")
    fun deleteFavoriteProduct(
            @Query("accessToken") accessToken: String?,
            @Query("customerId") customerId: String?,
            @Query("productId") productId: String?,
            @Query("isTestDb") isTestDb: Boolean): Call<FavouriteResponse?>?

    @GET("customerapi/getFavoriteProducts")
    fun getFavoriteProduct(
            @Query("accessToken") accessToken: String?,
            @Query("sessionId") sessionId: String?,
            @Query("customerId") customerId: String?,
            @Query("registrationNo") registrationNo: String?,
            @Query("isTestDb") isTestDb: Boolean): Call<GetFavouriteResponse?>?

    @GET("productapi/getAllProducts")
    suspend fun getAllProducts(
            @Query("accessToken") accessToken: String?,
            @Query("companyId") companyId: String?,
            @Query("isTestDb") isTestDb: Boolean): ProductModel?

    @GET("companyApi/getSettings")
    fun getSettings(
            @Query("companyId") companyId: String?,
            @Query("accessToken") accessToken: String?,
            @Query("isTestDb") isTestDb: Boolean): Call<SettingsModel?>?

    @GET("companyApi/getPaymentMethods")
    fun getPaymentMethods(
            @Query("companyId") companyId: String?,
            @Query("accessToken") accessToken: String?,
            @Query("isTestDb") isTestDb: Boolean): Call<PaymentAPIResponse?>?

    @GET("productapi/getDiscountedProducts")
    fun getDiscountedProducts(
            @Query("companyId") companyId: String?,
            @Query("accessToken") accessToken: String?,
            @Query("isTestDb") isTestDb: Boolean): Call<DiscountResponse?>?

    @GET("productapi/getCurrentStock")
    fun getCurrentStock(
            @Query("companyId") companyId: String?,
            @Query("productId") productId: Int?,
            @Query("accessToken") accessToken: String?,
            @Query("isTestDb") isTestDb: Boolean): Call<CurrentStockResponse?>?

    @GET("productapi/getBestSellingProducts")
    fun getBestSellingProducts(
            @Query("accessToken") accessToken: String?,
            @Query("companyId") companyId: String?,
            @Query("isTestDb") isTestDb: Boolean): Call<BestSellingProductResponse>?
}