package com.framebig.emedicine.features.verifyCustomerAuthCode;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.widget.Toolbar;
import androidx.databinding.DataBindingUtil;

import com.framebig.emedicine.R;
import com.framebig.emedicine.databinding.ActivityCustomerAuthCodeVerificationBinding;
import com.framebig.emedicine.features.BaseActivity;
import com.framebig.emedicine.features.home.HomeActivity;
import com.framebig.emedicine.features.model.AuthResponseModel;
import com.framebig.emedicine.features.sign_in.SignInActivity;
import com.framebig.emedicine.retrofit.ApiClient;
import com.framebig.emedicine.utility.AlertDialogOneButton;
import com.framebig.emedicine.utility.AppUtils;
import com.framebig.emedicine.utility.ApplicationData;
import com.framebig.emedicine.utility.Connectivity;
import com.framebig.emedicine.utility.LogMe;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CustomerAuthVerificationActivity extends BaseActivity implements AlertDialogOneButton.OnOkButtonClickListener, View.OnClickListener
{

    private String TAG = SignInActivity.class.getName();
    private String loginId = null;
    private String parentActivity = null;

    private static final String activitySignUp = "SignUpActivity";
    private static final String activitySignIn = "SignInActivity";

    private ActivityCustomerAuthCodeVerificationBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_customer_auth_code_verification);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setTitle(R.string.verification);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        if (savedInstanceState == null)
        {
            Bundle extras = getIntent().getExtras();
            if (extras == null)
            {
                loginId = null;
                parentActivity = null;
            }
            else
            {
                loginId = extras.getString("loginId");
                parentActivity = extras.getString("parentActivity");
            }
        }
        binding.content.textViewVerificationMessage.setText(String.format(getString(R.string.verification_title_message), loginId));
        binding.content.buttonVerifyAuthCode.setOnClickListener(this);
    }

    public void onClick(View v)
    {
        if (v == binding.content.buttonVerifyAuthCode)
        {
            if (binding.content.editTextVerificationCode.getText().toString().trim().isEmpty())
            {
                showToastMessage(getString(R.string.enter_verification_code));
                return;
            }
            callCustomerAuthVerificationApi();
        }
    }

    private void callCustomerAuthVerificationApi()
    {

        final int verificationCode = Integer.parseInt(binding.content.editTextVerificationCode.getText().toString());

        try
        {
            if (Connectivity.isConnected(CustomerAuthVerificationActivity.this))
            {

                showProgressDialog();

                ApiClient.getApiInterface().verifyCustomerAuthCode(ApplicationData.ACCESS_TOKEN, loginId, verificationCode,
                        ApplicationData.isTestDb()).enqueue(new Callback<AuthResponseModel>()
                {
                    @Override
                    public void onResponse(
                            Call<AuthResponseModel> call,
                            Response<AuthResponseModel> response)
                    {

                        try
                        {

                            hideProgressDialog();

                            AuthResponseModel authResponseModel = response.body();

                            if (authResponseModel != null && authResponseModel.getResponse_code() == ApplicationData.SUCCESS_RESPONSE_CODE)
                            {

                                AppUtils.customDialogOneButton(CustomerAuthVerificationActivity.this, CustomerAuthVerificationActivity.this,
                                        getString(R.string.alert_verification_successful_title),
                                        getString(R.string.alert_verification_successful_message), View.GONE, getString(R.string.alert_ok_button),
                                        R.drawable.vector_info_alertdialog, ApplicationData.TRACK_ALERT_CORRECT_VERIFICATION);
                            }
                            else if (authResponseModel != null && authResponseModel.getResponse_code() == ApplicationData.WRONG_VERIFICATION_RESPONSE_CODE)
                            {

                                AppUtils.customDialogOneButton(CustomerAuthVerificationActivity.this, CustomerAuthVerificationActivity.this,
                                        getString(R.string.alert_verification_failed_title), getString(R.string.alert_verification_failed_message),
                                        View.GONE, getString(R.string.alert_ok_button), R.drawable.vector_info_alertdialog,
                                        ApplicationData.TRACK_ALERT_WRONG_VERIFICATION);
                            }

                        }
                        catch (Exception e)
                        {
                            // TODO sent exception message to firebase
                            LogMe.e(TAG, e.toString());
                        }
                    }

                    @Override
                    public void onFailure(
                            Call<AuthResponseModel> call,
                            Throwable t)
                    {

                        hideProgressDialog();
                        AppUtils.customDialogOneButton(CustomerAuthVerificationActivity.this, CustomerAuthVerificationActivity.this,
                                getString(R.string.alert_server_down_title), getString(R.string.alert_server_down_message), View.GONE,
                                getString(R.string.alert_ok_button), R.drawable.vector_info_alertdialog, ApplicationData.TRACK_ALERT_SERVER_PROBLEM);
                    }
                });
            }
            else
            {
                showToastMessage(getString(R.string.no_internet_connection));
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    @Override
    public void onOkButtonClick(int trackingNumber)
    {

        switch (trackingNumber)
        {

            case ApplicationData.TRACK_ALERT_CORRECT_VERIFICATION:

                if (parentActivity.equalsIgnoreCase(activitySignUp))
                {
                    Intent loginIntent = new Intent(CustomerAuthVerificationActivity.this, SignInActivity.class);
                    startActivity(loginIntent);

                }
                else
                {
                    Intent categoryIntent = new Intent(CustomerAuthVerificationActivity.this, HomeActivity.class);
                    categoryIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(categoryIntent);
                }
                finish();
        }
    }
}
