package com.framebig.emedicine.features.order_history

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.framebig.emedicine.features.model.OrderDetailsResponse
import com.framebig.emedicine.features.model.OrderHistoryResponse
import com.framebig.emedicine.features.model.OrderListModel
import com.framebig.emedicine.retrofit.ApiClient
import com.framebig.emedicine.utility.ApplicationData
import com.framebig.emedicine.utility.FrameBigApp
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class OrderHistoryDetailsViewModel(private val orderNo: String) : ViewModel() {

    var order = MutableLiveData<OrderHistoryResponse>()
    var loading = MutableLiveData<Boolean>()
    var messaging = MutableLiveData<String>()
    var orderListModelList = MutableLiveData<ArrayList<OrderListModel>>()

    init {
        orderDetailsFromServer()
    }

    private fun orderDetailsFromServer() {
        loading.postValue(true)
        ApiClient.getApiInterface().getOrderDetails(ApplicationData.ACCESS_TOKEN,
                ApplicationData.isTestDb(), ApplicationData.SESSION_ID,
                ApplicationData.getCompanyID(),
                FrameBigApp.getDefaultSharePreference().customerId, orderNo).enqueue(object : Callback<OrderDetailsResponse?> {
            override fun onResponse(call: Call<OrderDetailsResponse?>, response: Response<OrderDetailsResponse?>) {
                try {
                    loading.postValue(false)
                    if (response.isSuccessful && response.body() != null) {
                        val orderResponse = response.body()
                        orderListModelList.postValue(orderResponse!!.response!!.productData)
                        order.postValue(orderResponse.response)
                    }
                } catch (e: Exception) {
                    loading.postValue(false)
                    messaging.postValue(e.message)
                }
            }

            override fun onFailure(call: Call<OrderDetailsResponse?>, t: Throwable) {
                loading.postValue(false)
                messaging.postValue(t.message)
            }
        })
    }
}