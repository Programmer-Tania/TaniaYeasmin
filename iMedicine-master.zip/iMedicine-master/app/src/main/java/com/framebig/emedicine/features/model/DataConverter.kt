package com.framebig.emedicine.features.model

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.lang.reflect.Type

class DataConverter {

    @TypeConverter
    fun fromProductModelList(countryLang: ArrayList<ProductModel>?): String? {
        if (countryLang == null) {
            return null
        }
        val gson = Gson()
        val type: Type = object : TypeToken<ArrayList<ProductModel>>() {}.type
        return gson.toJson(countryLang, type)
    }

    @TypeConverter
    fun toProductModelList(countryLangString: String?): ArrayList<ProductModel>? {
        if (countryLangString == null) {
            return null
        }
        val gson = Gson()
        val type: Type = object : TypeToken<ArrayList<ProductModel>?>() {}.type
        return gson.fromJson<ArrayList<ProductModel>>(countryLangString, type)
    }
}