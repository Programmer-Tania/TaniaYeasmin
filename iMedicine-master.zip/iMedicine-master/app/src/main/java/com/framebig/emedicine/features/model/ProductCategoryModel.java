package com.framebig.emedicine.features.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by User on 12/25/2017.
 */

public class ProductCategoryModel
{

    private String categoryName;
    private ArrayList<String> imageList;
    private String categoryId;
    private int totalProduct;
    private int response_code;

    @SerializedName("response")
    @Expose
    ArrayList<ProductCategoryModel> productCategoryModelArrayList = new ArrayList<>();

    public String getCategoryName()
    {
        return categoryName;
    }

    public void setCategoryName(String categoryName)
    {
        this.categoryName = categoryName;
    }

    public void setImageList(ArrayList<String> imageList)
    {
        this.imageList = imageList;
    }

    public ArrayList<String> getImageList()
    {
        return imageList;
    }

    public String getCategoryId()
    {
        return categoryId;
    }

    public void setCategoryId(String categoryId)
    {
        this.categoryId = categoryId;
    }

    public List<ProductCategoryModel> getProductCategoryList()
    {
        return productCategoryModelArrayList;
    }

    public int getResponse_code()
    {
        return response_code;
    }

    public void setResponse_code(int response_code)
    {
        this.response_code = response_code;
    }

    public int getTotalProduct()
    {
        return totalProduct;
    }

    public void setTotalProduct(int totalProduct)
    {
        this.totalProduct = totalProduct;
    }
}
