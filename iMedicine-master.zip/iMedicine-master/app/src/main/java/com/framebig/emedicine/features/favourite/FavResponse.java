package com.framebig.emedicine.features.favourite;

public class FavResponse
{

    private String[] imageList;

    private String isColorMaintained;

    private String isSizeMaintained;

    private String productDescription;

    private String productShotName;

    private String productName;

    private String productUnit;

    private String productId;

    private String discountedPrice;

    public String getDiscountedPrice()
    {
        return discountedPrice;
    }

    public void setDiscountedPrice(String discountedPrice)
    {
        this.discountedPrice = discountedPrice;
    }

    public String[] getImageList()
    {
        return imageList;
    }

    public void setImageList(String[] imageList)
    {
        this.imageList = imageList;
    }

    public String getIsColorMaintained()
    {
        return isColorMaintained;
    }

    public void setIsColorMaintained(String isColorMaintained)
    {
        this.isColorMaintained = isColorMaintained;
    }

    public String getIsSizeMaintained()
    {
        return isSizeMaintained;
    }

    public void setIsSizeMaintained(String isSizeMaintained)
    {
        this.isSizeMaintained = isSizeMaintained;
    }

    public String getProductDescription()
    {
        return productDescription;
    }

    public void setProductDescription(String productDescription)
    {
        this.productDescription = productDescription;
    }

    public String getProductShotName()
    {
        return productShotName;
    }

    public void setProductShotName(String productShotName)
    {
        this.productShotName = productShotName;
    }

    public String getProductName()
    {
        return productName;
    }

    public void setProductName(String productName)
    {
        this.productName = productName;
    }

    public String getProductUnit()
    {
        return productUnit;
    }

    public void setProductUnit(String productUnit)
    {
        this.productUnit = productUnit;
    }

    public String getProductId()
    {
        return productId;
    }

    public void setProductId(String productId)
    {
        this.productId = productId;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [imageList = " + imageList + ", isColorMaintained = " + isColorMaintained + ", isSizeMaintained = " + isSizeMaintained +
                ", productDescription = " + productDescription + ", productShotName = " + productShotName + ", productName = " + productName + ", " +
                "productUnit = " + productUnit + ", productId = " + productId + "]";
    }
}
