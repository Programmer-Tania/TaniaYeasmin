package com.framebig.emedicine.enums

enum class DatabaseType(val serverType: String) {
    Production("Production"),
    Test("Test")
}