package com.framebig.emedicine.utility;

public enum CustomerType
{
    retail, wholesale
}
