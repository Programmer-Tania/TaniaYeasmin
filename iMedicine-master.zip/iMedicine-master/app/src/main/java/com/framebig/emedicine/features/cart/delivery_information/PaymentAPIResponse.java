package com.framebig.emedicine.features.cart.delivery_information;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class PaymentAPIResponse
{

    @SerializedName("response_code")
    private int responseCode;

    @SerializedName("response")
    private List<ResponseItem> response;

    @SerializedName("status")
    private String status;

    public void setResponseCode(int responseCode)
    {
        this.responseCode = responseCode;
    }

    public int getResponseCode()
    {
        return responseCode;
    }

    public void setResponse(List<ResponseItem> response)
    {
        this.response = response;
    }

    public List<ResponseItem> getResponse()
    {
        return response;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

    public String getStatus()
    {
        return status;
    }
}