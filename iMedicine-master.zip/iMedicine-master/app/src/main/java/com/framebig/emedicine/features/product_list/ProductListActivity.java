package com.framebig.emedicine.features.product_list;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;

import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.framebig.emedicine.R;
import com.framebig.emedicine.features.BaseActivity;
import com.framebig.emedicine.features.cart.cart_item.CartActivity;
import com.framebig.emedicine.features.model.ProductModel;
import com.framebig.emedicine.features.product_details.ProductDetailsActivity;
import com.framebig.emedicine.features.sign_in.SignInActivity;
import com.framebig.emedicine.retrofit.ApiClient;
import com.framebig.emedicine.utility.AlertDialogTwoButton.ButtonClickListener;
import com.framebig.emedicine.utility.AppUtils;
import com.framebig.emedicine.utility.ApplicationData;
import com.framebig.emedicine.utility.Connectivity;
import com.framebig.emedicine.utility.FrameBigApp;
import com.framebig.emedicine.utility.ItemOffsetDecoration;
import com.framebig.emedicine.utility.LogMe;
import com.framebig.emedicine.utility.PrefsValues;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProductListActivity extends BaseActivity implements SearchView.OnQueryTextListener, ProductListAdapter.RecyclerCustomItemClickListener
        , ButtonClickListener {

    private RecyclerView recyclerview_product_list;
    private ProductListAdapter productListAdapter;

    private ProductListActivity productListActivity = this;
    private String TAG = ProductListActivity.class.getSimpleName();

    private String categoryId = null, categoryName = null;
    private TextView txtViewCount;
    private TextView txtEmptyView;
    private PrefsValues prefsValues;
    private FloatingActionButton fab_list;
    private FloatingActionButton fab_grid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list);
        initializeUI();
    }

    @Override
    protected void onResume() {
        super.onResume();
        LogMe.i(TAG, "onResume called");

        runOnUiThread(() -> {
            int count = ApplicationData.CART_MODEL_LIST.size();
            LogMe.i(TAG, "COUNT: " + count);
            if (txtViewCount != null) {
                if (count == 0) txtViewCount.setVisibility(View.GONE);
                else {
                    txtViewCount.setVisibility(View.VISIBLE);
                    txtViewCount.setText("" + count);
                }
            }
        });
    }

    private void initializeUI() {

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        View notifications = findViewById(R.id.notifications);
        txtViewCount = notifications.findViewById(R.id.txtCount);
        notifications.setOnClickListener(v -> goToCartActivity());
        fab_list = findViewById(R.id.fab_switch_list);
        fab_grid = findViewById(R.id.fab_switch_grid);
        fab_grid.setOnClickListener(v -> switchLayout());
        fab_list.setOnClickListener(v -> switchLayout());

        recyclerview_product_list = findViewById(R.id.recyclerview_product_list);
        ItemOffsetDecoration itemDecoration = new ItemOffsetDecoration(this, R.dimen.sixteen_dp);
        recyclerview_product_list.addItemDecoration(itemDecoration);

        if (ApplicationData.SETTINGS_RESPONSE.getDefaultlayout().equalsIgnoreCase("GRID")) {
            productListAdapter.isSwitchView = false;
            recyclerview_product_list.setLayoutManager(new GridLayoutManager(this, 2));
            fab_grid.setVisibility(View.INVISIBLE);
            fab_list.setVisibility(View.VISIBLE);
        } else {
            productListAdapter.isSwitchView = true;
            recyclerview_product_list.setLayoutManager(new LinearLayoutManager(this));
            fab_list.setVisibility(View.INVISIBLE);
            fab_grid.setVisibility(View.VISIBLE);
        }

        this.categoryName = (ApplicationData.SHARED_MODEL.getSelectedCategoryName());
        this.categoryId = (ApplicationData.SHARED_MODEL.getSelectedCategoryId());

        prefsValues = FrameBigApp.getDefaultSharePreference();

        if (ApplicationData.PRODUCT_MODEL_LIST.size() < 1) {
            if (this.categoryId == null || this.categoryName == null) {
                showToastMessage(getString(R.string.toast_something_went_wrong));
                finish();
            }
            getProductByCategory();
        } else {
            setProductCategoryAdapter();
        }

        getSupportActionBar().setTitle(this.categoryName);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        txtEmptyView = findViewById(R.id.txtEmptyView);
    }

    private void switchLayout() {
        if (fab_grid.getVisibility() == View.VISIBLE) {
            fab_grid.setVisibility(View.INVISIBLE);
            fab_list.setVisibility(View.VISIBLE);
        } else if (fab_list.getVisibility() == View.VISIBLE) {
            fab_list.setVisibility(View.INVISIBLE);
            fab_grid.setVisibility(View.VISIBLE);
        }
        boolean isSwitched = productListAdapter.toggleItemViewType();
        recyclerview_product_list.setLayoutManager(isSwitched ? new LinearLayoutManager(this) : new GridLayoutManager(this, 2));
        productListAdapter.notifyDataSetChanged();
        /*        // int numberOfColumns = AppUtils.calculateNoOfColumns(getApplicationContext());
        //        //    recyclerview_product_list.addItemDecoration(new GridSpacingItemDecoration(numberOfColumns, 8, true));
        //        //  recyclerview_product_list.setLayoutManager(new GridLayoutManager(this, numberOfColumns));
        //        // recyclerview_product_list.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        //recyclerview_product_list.setLayoutManager(new LinearLayoutManager(this));*/
    }

    private void goToCartActivity() {
        if (ApplicationData.CART_MODEL_LIST.size() > 0) {
            if (isUserLoggedIn() || prefsValues.getisGuestCustomer()) {
                Intent cartActivityIntent = new Intent(this, CartActivity.class);
                startActivity(cartActivityIntent);
            } else {
                AppUtils.customDialogTwoButtons(this, this, getString(R.string.checkout), getString(R.string.alert_login_as_guest_required_message)
                        , View.GONE, getString(R.string.log_in), getString(R.string.continue_as_guest), R.drawable.vector_info_alertdialog,
                        ApplicationData.TRACK_ALERT_LOGIN_AS_GUEST_REQUIRED);
            }
        } else {
            showToastMessage(getString(R.string.toast_empty_cart));
        }
    }

    private boolean isUserLoggedIn() {

        String loginId = prefsValues.getLoginId();
        if (loginId.isEmpty()) {
            return false;
        }
        return true;
    }

    private void goToProductDetailsUI(int position) {

        Intent intent = new Intent(productListActivity, ProductDetailsActivity.class);
        Gson gson = new Gson();

        String object = gson.toJson(ApplicationData.PRODUCT_MODEL_LIST.get(position));
        intent.putExtra(ApplicationData.PRODUCT_OBJECT, object);

        startActivity(intent);

    }

    private void goToProductDetailsUI(ProductModel productModel) {

        Intent intent = new Intent(productListActivity, ProductDetailsActivity.class);
        intent.putExtra("productId", "" + productModel.getProductId());
        intent.putExtra("productName", productModel.getProductName());

        ApplicationData.SHARED_MODEL.setSelectedProductName(productModel.getProductName());
        ApplicationData.SHARED_MODEL.setSelectedProductId(String.valueOf(productModel.getProductId()));
        /* Gson gson = new Gson();
        String object = gson.toJson(productModel)
        intent.putExtra(ApplicationData.PRODUCT_OBJECT, object); */

        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_service_sub_category, menu);
        MenuItem menuItem = menu.findItem(R.id.action_search);

        SearchView searchView = (SearchView) menuItem.getActionView();

        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);

        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setMaxWidth(Integer.MAX_VALUE);

        searchView.setOnQueryTextListener(this);
        searchView.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            case R.id.action_search:
                return super.onOptionsItemSelected(item);
        }
        return super.onOptionsItemSelected(item);
    }

    private void getProductByCategory() {

        try {
            if (Connectivity.isConnected(productListActivity)) {
                showProgressDialog();
                ApiClient.getApiInterface().getProductListByCategory(
                        ApplicationData.ACCESS_TOKEN,
                        ApplicationData.getCompanyID(),
                        categoryId,
                        ApplicationData.isTestDb()).enqueue(new Callback<ProductModel>() {
                    @Override
                    public void onResponse(
                            Call<ProductModel> call,
                            Response<ProductModel> response) {

                        hideProgressDialog();
                        LogMe.i(TAG, "" + response.body().toString());

                        ProductModel productResponse = response.body();
                        if (productResponse.getResponse_code() == ApplicationData.SUCCESS_RESPONSE_CODE) {

                            ApplicationData.PRODUCT_MODEL_LIST.clear();
                            ApplicationData.PRODUCT_MODEL_LIST = productResponse.getProductModelArrayList();
                            LogMe.e(TAG, "ProductModel: " + ApplicationData.PRODUCT_MODEL_LIST.size());
                            if (ApplicationData.PRODUCT_MODEL_LIST.size() < 1) {
                                txtEmptyView.setVisibility(View.VISIBLE);
                            }

                            setProductCategoryAdapter();

                        } else {

                            showToastMessage("" + productResponse.getResponse_code());
                        }
                    }

                    @Override
                    public void onFailure(
                            Call<ProductModel> call,
                            Throwable t) {

                        hideProgressDialog();
                    }
                });

            } else {
                AppUtils.customDialogTwoButtons(this, this, getString(R.string.alert_no_internet_title),
                        getString(R.string.alert_no_interner_message), View.GONE, getString(R.string.alert_no_internet_exit),
                        getString(R.string.alert_no_internet_retry), R.drawable.vector_info_alertdialog, ApplicationData.TRACK_ALERT_NO_INTERNET);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setProductCategoryAdapter() {
        productListAdapter = new ProductListAdapter(ApplicationData.PRODUCT_MODEL_LIST, this);
        recyclerview_product_list.setAdapter(productListAdapter);
        productListAdapter.notifyDataSetChanged();
    }

    @Override
    public boolean onQueryTextSubmit(String s) {
        productListAdapter.getFilter().filter(s);
        return false;
    }

    @Override
    public boolean onQueryTextChange(String s) {

        productListAdapter.getFilter().filter(s);
        return false;
    }

    @Override
    public void onRowSelected(int position) {
        //goToProductDetailsUI(position);
    }

    @Override
    public void getItem(ProductModel productModel) {
        goToProductDetailsUI(productModel);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ApplicationData.PRODUCT_MODEL_LIST.clear();
    }

    @Override
    public void onNegativeButtonClick(int trackingNumber) {
        switch (trackingNumber) {
            case ApplicationData.TRACK_ALERT_NO_INTERNET:
                this.finishAffinity();
                break;
            case ApplicationData.TRACK_ALERT_LOGIN_AS_GUEST_REQUIRED:
                Intent signInActivityIntent = new Intent(this, SignInActivity.class);
                startActivity(signInActivityIntent);
                this.finish();
                break;
            default:
                break;
        }
    }

    @Override
    public void onPositiveButtonClick(int trackingNumber) {

        switch (trackingNumber) {
            case ApplicationData.TRACK_ALERT_NO_INTERNET:
                getProductByCategory();
                break;
            case ApplicationData.TRACK_ALERT_LOGIN_AS_GUEST_REQUIRED:
                prefsValues.setCustomerId(0);
                prefsValues.setIsGuestCustomer(true);
                Intent cartActivityIntent = new Intent(this, CartActivity.class);
                startActivity(cartActivityIntent);
                this.finish();
                break;
            default:
                break;
        }
    }
}