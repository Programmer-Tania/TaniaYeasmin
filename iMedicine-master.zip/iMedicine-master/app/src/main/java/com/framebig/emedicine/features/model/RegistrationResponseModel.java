package com.framebig.emedicine.features.model;

/**
 * Created by Shihab on 2/22/2018.
 */

public class RegistrationResponseModel
{

    /*{
        "response_code":200,
        "response":"Registration is successful",
        "status":"success"}
    }
    {
        "response_code":410,
        "response":"This ID (Email) already exists.",
        "status":"failed"}
    */

    private int response_code;
    private Response response;
    private String status;

    public int getResponse_code()
    {
        return response_code;
    }

    public void setResponse_code(int response_code)
    {
        this.response_code = response_code;
    }

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

    public Response getResponse()
    {
        return response;
    }

    public void setResponse(Response response)
    {
        this.response = response;
    }

    public class Response
    {

        String msg;

        public String getMsg()
        {
            return msg;
        }

    }
}
