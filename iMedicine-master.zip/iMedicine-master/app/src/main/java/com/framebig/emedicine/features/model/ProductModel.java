package com.framebig.emedicine.features.model;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by User on 1/3/2018.
 */
@Entity(tableName = "product")
public class ProductModel
{
    @NonNull
    @PrimaryKey
    private int ProductId;
    private String productName;
    private String productQuantity;

    @TypeConverters(StringListConverter.class)
    private List<String> imageList;

    private String productDescription;
    private String productUnit;
    private String productShotName;
    private String categoryId;
    private String minOnlineUnitSellingCost;
    private int response_code;
    private String maxBuyingCost;
    private String minBuyingCost;
    private String maxRetailCost;
    private String minRetailCost;
    private String maxWholeSaleCost;
    private String minWholeSaleCost;
    private String maxOnlineCost;
    private String minOnlineCost;
    private String maxStrikeCost;
    private String minStrikeCost;
    private boolean isRecentlyViewed;
    private String discountedPrice;
    private int discountedPercentage;
    private String currentStock;
    private String pendingOrderStock;
    private String imageUrl;
    private String totalQuantitySold;

    @SerializedName("response")
    @Expose
    @TypeConverters(DataConverter.class)
    private ArrayList<ProductModel> productModelArrayList = new ArrayList<>();

    public String getMinRetailCost()
    {
        return minRetailCost;
    }

    public void setMinRetailCost(String minRetailCost)
    {
        this.minRetailCost = minRetailCost;
    }

    public String getMaxRetailCost()
    {
        return maxRetailCost;
    }

    public void setMaxRetailCost(String maxRetailCost)
    {
        this.maxRetailCost = maxRetailCost;
    }

    public String getMaxWholeSaleCost()
    {
        return maxWholeSaleCost;
    }

    public void setMaxWholeSaleCost(String maxWholeSaleCost)
    {
        this.maxWholeSaleCost = maxWholeSaleCost;
    }

    public String getMinWholeSaleCost()
    {
        return minWholeSaleCost;
    }

    public void setMinWholeSaleCost(String minWholeSaleCost)
    {
        this.minWholeSaleCost = minWholeSaleCost;
    }

    public String getMinOnlineCost()
    {
        return minOnlineCost;
    }

    public void setMinOnlineCost(String minOnlineCost)
    {
        this.minOnlineCost = minOnlineCost;
    }

    public String getMaxStrikeCost()
    {
        return maxStrikeCost;
    }

    public void setMaxStrikeCost(String maxStrikeCost)
    {
        this.maxStrikeCost = maxStrikeCost;
    }

    public String getMinStrikeCost()
    {
        return minStrikeCost;
    }

    public void setMinStrikeCost(String minStrikeCost)
    {
        this.minStrikeCost = minStrikeCost;
    }

    public String getProductName()
    {
        return productName;
    }

    public void setProductName(String productName)
    {
        this.productName = productName;
    }

    public String getProductQuantity()
    {
        return productQuantity;
    }

    public void setProductQuantity(String productQuantity)
    {
        this.productQuantity = productQuantity;
    }

    public List<String> getImageList()
    {
        return imageList;
    }

    public void setImageList(List<String> imageList)
    {
        this.imageList = imageList;
    }

    public String getProductDescription()
    {
        return productDescription;
    }

    public void setProductDescription(String productDescription)
    {
        this.productDescription = productDescription;
    }

    public String getProductUnit()
    {
        return productUnit;
    }

    public void setProductUnit(String productUnit)
    {
        this.productUnit = productUnit;
    }

    public int getProductId()
    {
        return ProductId;
    }

    public void setProductId(int productId)
    {
        ProductId = productId;
    }

    public String getProductShotName()
    {
        return productShotName;
    }

    public void setProductShotName(String productShotName)
    {
        this.productShotName = productShotName;
    }

    public String getCategoryId()
    {
        return categoryId;
    }

    public void setCategoryId(String categoryId)
    {
        this.categoryId = categoryId;
    }

    public ArrayList<ProductModel> getProductModelArrayList()
    {
        return productModelArrayList;
    }

    public void setProductModelArrayList(ArrayList<ProductModel> productModelArrayList)
    {
        this.productModelArrayList = productModelArrayList;
    }

    public int getResponse_code()
    {
        return response_code;
    }

    public void setResponse_code(int response_code)
    {
        this.response_code = response_code;
    }

    public String getMaxOnlineCost()
    {
        return maxOnlineCost;
    }

    public void setMaxOnlineCost(String maxOnlineCost)
    {
        this.maxOnlineCost = maxOnlineCost;
    }

    public String getMinOnlineUnitSellingCost()
    {
        return minOnlineUnitSellingCost;
    }

    public void setMinOnlineUnitSellingCost(String minOnlineUnitSellingCost)
    {
        this.minOnlineUnitSellingCost = minOnlineUnitSellingCost;
    }

    public boolean isRecentlyViewed()
    {
        return isRecentlyViewed;
    }

    public void setRecentlyViewed(boolean recentlyViewed)
    {
        isRecentlyViewed = recentlyViewed;
    }

    public String getDiscountedPrice()
    {
        return discountedPrice;
    }

    public void setDiscountedPrice(String discountedPrice)
    {
        this.discountedPrice = discountedPrice;
    }

    public int getDiscountedPercentage()
    {
        return discountedPercentage;
    }

    public void setDiscountedPercentage(int discountedPercentage)
    {
        this.discountedPercentage = discountedPercentage;
    }

    public String getMaxBuyingCost()
    {
        return maxBuyingCost;
    }

    public void setMaxBuyingCost(String maxBuyingCost)
    {
        this.maxBuyingCost = maxBuyingCost;
    }

    public String getMinBuyingCost()
    {
        return minBuyingCost;
    }

    public void setMinBuyingCost(String minBuyingCost)
    {
        this.minBuyingCost = minBuyingCost;
    }

    public String getCurrentStock()
    {
        return currentStock;
    }

    public void setCurrentStock(String currentStock)
    {
        this.currentStock = currentStock;
    }

    public String getPendingOrderStock()
    {
        return pendingOrderStock;
    }

    public void setPendingOrderStock(String pendingOrderStock)
    {
        this.pendingOrderStock = pendingOrderStock;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getTotalQuantitySold() {
        return totalQuantitySold;
    }

    public void setTotalQuantitySold(String totalQuantitySold) {
        this.totalQuantitySold = totalQuantitySold;
    }
}
