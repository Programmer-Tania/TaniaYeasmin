package com.framebig.emedicine.features.discounted_products;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DiscountResponseItem implements Serializable
{

    @SerializedName("maxRetailCost")
    @Expose
    private String maxRetailCost;
    @SerializedName("maxWholeSaleCost")
    @Expose
    private String maxWholeSaleCost;
    @SerializedName("isSizeMaintained")
    @Expose
    private String isSizeMaintained;
    @SerializedName("minStrikeCost")
    @Expose
    private String minStrikeCost;
    @SerializedName("discountValidTill")
    @Expose
    private String discountValidTill;
    @SerializedName("ProductId")
    @Expose
    private int productId;
    @SerializedName("productUnit")
    @Expose
    private String productUnit;
    @SerializedName("discountedPercentage")
    @Expose
    private int discountedPercentage;
    @SerializedName("productName")
    @Expose
    private String productName;
    @SerializedName("minWholeSaleCost")
    @Expose
    private String minWholeSaleCost;
    @SerializedName("productShotName")
    @Expose
    private String productShotName;
    @SerializedName("maxOnlineCost")
    @Expose
    private String maxOnlineCost;
    @SerializedName("isColorMaintained")
    @Expose
    private String isColorMaintained;
    @SerializedName("discountedPrice")
    @Expose
    private double discountedPrice;
    @SerializedName("discountValidFrom")
    @Expose
    private String discountValidFrom;
    @SerializedName("minRetailCost")
    @Expose
    private String minRetailCost;
    @SerializedName("currentStock")
    @Expose
    private double currentStock;
    @SerializedName("maxStrikeCost")
    @Expose
    private String maxStrikeCost;
    @SerializedName("minOnlineCost")
    @Expose
    private String minOnlineCost;
    @SerializedName("imageList")
    @Expose
    private List<String> imageList = null;
    @SerializedName("productDescription")
    @Expose
    private String productDescription;
    private final static long serialVersionUID = -2529300194852427331L;

    /**
     * No args constructor for use in serialization
     */
    public DiscountResponseItem()
    {
    }

    /**
     * @param maxRetailCost
     * @param maxWholeSaleCost
     * @param isSizeMaintained
     * @param productId
     * @param minStrikeCost
     * @param discountValidTill
     * @param productUnit
     * @param discountedPercentage
     * @param productName
     * @param minWholeSaleCost
     * @param productShotName
     * @param maxOnlineCost
     * @param isColorMaintained
     * @param discountedPrice
     * @param discountValidFrom
     * @param minRetailCost
     * @param currentStock
     * @param maxStrikeCost
     * @param minOnlineCost
     * @param imageList
     * @param productDescription
     */
    public DiscountResponseItem(
            String maxRetailCost,
            String maxWholeSaleCost,
            String isSizeMaintained,
            String minStrikeCost,
            String discountValidTill,
            int productId,
            String productUnit,
            int discountedPercentage,
            String productName,
            String minWholeSaleCost,
            String productShotName,
            String maxOnlineCost,
            String isColorMaintained,
            int discountedPrice,
            String discountValidFrom,
            String minRetailCost,
            int currentStock,
            String maxStrikeCost,
            String minOnlineCost,
            List<String> imageList,
            String productDescription)
    {
        super();
        this.maxRetailCost = maxRetailCost;
        this.maxWholeSaleCost = maxWholeSaleCost;
        this.isSizeMaintained = isSizeMaintained;
        this.minStrikeCost = minStrikeCost;
        this.discountValidTill = discountValidTill;
        this.productId = productId;
        this.productUnit = productUnit;
        this.discountedPercentage = discountedPercentage;
        this.productName = productName;
        this.minWholeSaleCost = minWholeSaleCost;
        this.productShotName = productShotName;
        this.maxOnlineCost = maxOnlineCost;
        this.isColorMaintained = isColorMaintained;
        this.discountedPrice = discountedPrice;
        this.discountValidFrom = discountValidFrom;
        this.minRetailCost = minRetailCost;
        this.currentStock = currentStock;
        this.maxStrikeCost = maxStrikeCost;
        this.minOnlineCost = minOnlineCost;
        this.imageList = imageList;
        this.productDescription = productDescription;
    }

    public String getMaxRetailCost()
    {
        return maxRetailCost;
    }

    public void setMaxRetailCost(String maxRetailCost)
    {
        this.maxRetailCost = maxRetailCost;
    }

    public String getMaxWholeSaleCost()
    {
        return maxWholeSaleCost;
    }

    public void setMaxWholeSaleCost(String maxWholeSaleCost)
    {
        this.maxWholeSaleCost = maxWholeSaleCost;
    }

    public String getIsSizeMaintained()
    {
        return isSizeMaintained;
    }

    public void setIsSizeMaintained(String isSizeMaintained)
    {
        this.isSizeMaintained = isSizeMaintained;
    }

    public String getMinStrikeCost()
    {
        return minStrikeCost;
    }

    public void setMinStrikeCost(String minStrikeCost)
    {
        this.minStrikeCost = minStrikeCost;
    }

    public String getDiscountValidTill()
    {
        return discountValidTill;
    }

    public void setDiscountValidTill(String discountValidTill)
    {
        this.discountValidTill = discountValidTill;
    }

    public int getProductId()
    {
        return productId;
    }

    public void setProductId(int productId)
    {
        this.productId = productId;
    }

    public String getProductUnit()
    {
        return productUnit;
    }

    public void setProductUnit(String productUnit)
    {
        this.productUnit = productUnit;
    }

    public int getDiscountedPercentage()
    {
        return discountedPercentage;
    }

    public void setDiscountedPercentage(int discountedPercentage)
    {
        this.discountedPercentage = discountedPercentage;
    }

    public String getProductName()
    {
        return productName;
    }

    public void setProductName(String productName)
    {
        this.productName = productName;
    }

    public String getMinWholeSaleCost()
    {
        return minWholeSaleCost;
    }

    public void setMinWholeSaleCost(String minWholeSaleCost)
    {
        this.minWholeSaleCost = minWholeSaleCost;
    }

    public String getProductShotName()
    {
        return productShotName;
    }

    public void setProductShotName(String productShotName)
    {
        this.productShotName = productShotName;
    }

    public String getMaxOnlineCost()
    {
        return maxOnlineCost;
    }

    public void setMaxOnlineCost(String maxOnlineCost)
    {
        this.maxOnlineCost = maxOnlineCost;
    }

    public String getIsColorMaintained()
    {
        return isColorMaintained;
    }

    public void setIsColorMaintained(String isColorMaintained)
    {
        this.isColorMaintained = isColorMaintained;
    }

    public double getDiscountedPrice()
    {
        return discountedPrice;
    }

    public void setDiscountedPrice(double discountedPrice)
    {
        this.discountedPrice = discountedPrice;
    }

    public String getDiscountValidFrom()
    {
        return discountValidFrom;
    }

    public void setDiscountValidFrom(String discountValidFrom)
    {
        this.discountValidFrom = discountValidFrom;
    }

    public String getMinRetailCost()
    {
        return minRetailCost;
    }

    public void setMinRetailCost(String minRetailCost)
    {
        this.minRetailCost = minRetailCost;
    }

    public double getCurrentStock()
    {
        return currentStock;
    }

    public void setCurrentStock(double currentStock)
    {
        this.currentStock = currentStock;
    }

    public String getMaxStrikeCost()
    {
        return maxStrikeCost;
    }

    public void setMaxStrikeCost(String maxStrikeCost)
    {
        this.maxStrikeCost = maxStrikeCost;
    }

    public String getMinOnlineCost()
    {
        return minOnlineCost;
    }

    public void setMinOnlineCost(String minOnlineCost)
    {
        this.minOnlineCost = minOnlineCost;
    }

    public List<String> getImageList()
    {
        return imageList;
    }

    public void setImageList(List<String> imageList)
    {
        this.imageList = imageList;
    }

    public String getProductDescription()
    {
        return productDescription;
    }

    public void setProductDescription(String productDescription)
    {
        this.productDescription = productDescription;
    }

}