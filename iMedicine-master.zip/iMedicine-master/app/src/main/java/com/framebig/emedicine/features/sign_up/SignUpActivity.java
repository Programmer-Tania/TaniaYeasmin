package com.framebig.emedicine.features.sign_up;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.databinding.DataBindingUtil;

import com.framebig.emedicine.R;
import com.framebig.emedicine.databinding.ActivitySignUpBinding;
import com.framebig.emedicine.features.BaseActivity;
import com.framebig.emedicine.features.model.RegistrationResponseModel;
import com.framebig.emedicine.features.sign_in.SignInActivity;
import com.framebig.emedicine.retrofit.ApiClient;
import com.framebig.emedicine.utility.ApplicationData;
import com.framebig.emedicine.utility.Connectivity;
import com.framebig.emedicine.utility.FrameBigApp;
import com.framebig.emedicine.utility.LogMe;
import com.framebig.emedicine.utility.PrefsValues;

import org.json.JSONObject;

import java.net.URLEncoder;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignUpActivity extends BaseActivity implements View.OnClickListener
{

    private String TAG = SignInActivity.class.getName();
    PrefsValues prefsValues;
    ActivitySignUpBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_sign_up);

        setSupportActionBar(binding.toolbar);

        getSupportActionBar().setTitle(getString(R.string.sign_up));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        prefsValues = FrameBigApp.getDefaultSharePreference();
        binding.content.buttonSignUp.setOnClickListener(this);
    }

    public void submit()
    {

        if (binding.content.editTextFullName.getText().toString().trim().isEmpty())
        {
            showToastMessage(getString(R.string.enter_full_name));
            return;
        }

        if (binding.content.editTextLoginId.getText().toString().trim().isEmpty())
        {
            showToastMessage(getString(R.string.enter_email));
            return;
        }

        if (binding.content.inputPassword.getText().toString().trim().isEmpty())
        {
            showToastMessage(getString(R.string.enter_password));
            return;
        }

        if (binding.content.inputRetypePassword.getText().toString().trim().isEmpty())
        {
            showToastMessage(getString(R.string.enter_repeat_password));
            return;
        }
        if (!binding.content.inputRetypePassword.getText().toString().trim().
                equalsIgnoreCase(binding.content.inputPassword.getText().toString().trim()))
        {
            showToastMessage(getString(R.string.password_do_not_match));
            return;
        }
        callRegistrationApi();
        prefsValues.setIsGuestCustomer(false);
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
    }

    private void callRegistrationApi()
    {

        final String fullName = binding.content.editTextFullName.getText().toString();
        final String loginId = binding.content.editTextLoginId.getText().toString();
        final String password = binding.content.inputPassword.getText().toString();

        try
        {
            if (Connectivity.isConnected(SignUpActivity.this))
            {

                showProgressDialog();
                String registrationData = prepareRegistrationData(fullName, loginId, password);

                ApiClient.getApiInterface().registration(ApplicationData.ACCESS_TOKEN, registrationData, ApplicationData.isTestDb()).

                        enqueue(new Callback<RegistrationResponseModel>()
                        {
                            @Override
                            public void onResponse(
                                    Call<RegistrationResponseModel> call,
                                    Response<RegistrationResponseModel> response)
                            {

                                try
                                {

                                    hideProgressDialog();

                                    RegistrationResponseModel registrationResponseModel = response.body();
                                    if (registrationResponseModel != null && registrationResponseModel.getResponse_code() == ApplicationData.SUCCESS_RESPONSE_CODE)
                                    {

                                        showToastMessage("Registration is successful");
                                        goToSignInActiviy(loginId);
                                        finish();

                                    }
                                    else
                                    {
                                        showToastMessage(registrationResponseModel.getResponse().getMsg());
                                    }

                                }
                                catch (Exception e)
                                {
                                    LogMe.e(TAG, e.toString());
                                }
                            }

                            @Override
                            public void onFailure(
                                    Call<RegistrationResponseModel> call,
                                    Throwable t)
                            {
                                hideProgressDialog();
                                LogMe.e(TAG, t.toString());
                                showToastMessage(t.toString());
                            }
                        });
            }
            else
            {
                showToastMessage(getString(R.string.no_internet_connection));
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    private void goToSignInActiviy(String loginId)
    {
        Intent intent = new Intent(SignUpActivity.this, SignInActivity.class);
        intent.putExtra("loginId", loginId);
        intent.putExtra("parentActivity", "SignUpActivity");
        startActivity(intent);
    }

    private String prepareRegistrationData(
            String fullName,
            String loginId,
            String password)
    {

        try
        {
            JSONObject json = new JSONObject();
            json.put("loginId", loginId);
            json.put("fullName", fullName);
            json.put("password", password);
            json.put("branchId", ApplicationData.getBranchID());
            json.put("companyId", ApplicationData.getCompanyID());
            json.put("originatingApp", "ORDER APP");
            json.put("operatingSystem", "ANDROID");
            String encodedJsonString = URLEncoder.encode(json.toString(), "UTF-8");
            return encodedJsonString;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return "";
        }
    }

    @Override
    public void onClick(View v)
    {
        if (v == binding.content.buttonSignUp)
        {
            submit();
        }
    }
}
