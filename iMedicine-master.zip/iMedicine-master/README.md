# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

* Quick summary
* Version
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### How do I get set up? ###

Changes in SIAS ERP

* Image upload option in product type and product setup
* Modify the existing UI to view client orders with client name, order date, order amount and order status. 
* Modify the existing UI to view order details. User can update Order status(Delivered, Paid etc.) here.
* Implement push notification for receiving or updating each order.

Framebig Order App

* A new project has to be created
* The registration number of  the company from sias erp has to store in a global static variable. For each company this registration number will be changed. For each company there will be a customized Order App also.
* User registration - email repeat email, password, repeat password.
* User login - Email, password, forgot password - reuse code from sias erp
* Password retrieve - email id
* Change password - current password, new password repeat new password - reuse code from sias erp
* User profile - Family name/last name, first name, salutation, mobile number, education, email (comes from registration data), Billing address (flat no, floor no, house no, road no, postal code , pouroshova/thana, district), delivery address (same options as billing address)
* The home page should display product category in card view. These category data will come from sias erp api. User can search a product here (autocomplete). If user clicks on any product after search the product detail page will be displayed.
* User can see all products under each category when he clicks the category tile. All product info will come from sias erp api.
* User can see product details if he clicks on a product. Here he can see all available info about the product. Client may also see/provide his review/feedback about the product here. He may add the product in the basket from this page. Product details info will come from sias erp api.
* User can checkout his basket and review it. He can confirm the order here. He may change/update  the delivery address here.
* User can see all his order history.
* User gets push notification when order status is changed in sias erp.
* Contact seller - email or phone call - reuse from sias erp

## Release Management ##

* Change app name in Manifest
* change app launcher icons by replacing all mipmap folders

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Git Brancing and Commit Message ###

* always create a new branch for each /feature/bug/hotfix
* the feature branch should be like feature/feature-name number (e.g. feature/registration)
* the bugfix branch should be like bugfix/bugfix-name (e.g. bugfix/registration)
* always add the Bitbucket Issue number with a hastag (Very important) in your git commit message like #2 - your commit message
* we merge the featues branches with development in every 7 days

### Who do I talk to? ###

* Repo owner or admin
* Other community or team contact
